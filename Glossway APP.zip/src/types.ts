export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  createdAt: number;
  streak: number;
  lastActiveDate?: string; // YYYY-MM-DD
  wordsLearned: number;
  sessions: number;
  level: number;
  xp: number;
  studyTime?: number; // total study time in seconds
  dailyGoalMinutes?: number; // daily study goal in minutes
  languages: {
    [key: string]: {
      name: string;
      levelName: string;
      progress: number; // e.g., 78
      speaking?: number; // e.g., 65
      grammar?: number; // e.g., 82
    }
  };
  premium?: boolean;
  planId?: string;
  completedDates?: string[];
  recentSearches?: string[];
  notificationsEnabled?: boolean;
  reminderTime?: string; // e.g. "19:00"
  studyTimeSlots?: string[]; // e.g. ["09:00", "14:00"]
}

export interface ChatMessage {
  id: string;
  userId: string;
  text: string;
  sender: 'ai' | 'user';
  createdAt: number;
}

export interface Flashcard {
  id: string;
  word: string;
  translation: string;
  pronunciation: string;
  exampleSentence: string;
  exampleTranslation: string;
  examplePronunciation?: string;
  language: string;
  level: string; // Intermediate, Beginner, etc.
  custom?: boolean;
  starred?: boolean;
}

export interface QuizQuestion {
  id: string;
  challengeType: string; // "VOCABULARY CHALLENGE"
  question: string;
  imageUrl?: string;
  options: {
    letter: 'A' | 'B' | 'C' | 'D';
    text: string;
  }[];
  correctAnswer: 'A' | 'B' | 'C' | 'D';
}

export interface LessonHistory {
  date: string; // YYYY-MM-DD
  completed: boolean;
}
