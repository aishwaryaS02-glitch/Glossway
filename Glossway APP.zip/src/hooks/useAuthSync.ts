import { useState, useEffect } from "react";
import { auth, db } from "../firebase";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { doc, onSnapshot, setDoc, updateDoc, arrayUnion, arrayRemove, getDocFromServer } from "firebase/firestore";
import { UserProfile } from "../types";

export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// CRITICAL CONSTRAINT: Test database connection on boot
async function testConnection() {
  try {
    await getDocFromServer(doc(db, "test", "connection"));
  } catch (error) {
    if (error instanceof Error && error.message.includes("the client is offline")) {
      console.warn("Please check your Firebase configuration or internet connection.");
    }
  }
}
testConnection();

// Dynamically calculate the active study streak based on completed dates
export function calculateStreak(dates: string[]): number {
  if (!dates || dates.length === 0) return 0;
  
  const uniqueDates = new Set(dates);
  
  // Format helper for YYYY-MM-DD in local time
  const formatDate = (d: Date) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  const today = new Date();
  const todayStr = formatDate(today);
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = formatDate(yesterday);

  // If neither today nor yesterday is completed, the streak is 0
  if (!uniqueDates.has(todayStr) && !uniqueDates.has(yesterdayStr)) {
    return 0;
  }

  let streak = 0;
  let currentCheck = new Date(); // start at today

  while (true) {
    const dateStr = formatDate(currentCheck);
    if (uniqueDates.has(dateStr)) {
      streak++;
      currentCheck.setDate(currentCheck.getDate() - 1);
    } else {
      // If we are checking today and today is not completed, we can slide back to yesterday.
      // But if we've already checked yesterday (or earlier) and it's missing, the streak is broken.
      if (dateStr === todayStr) {
        currentCheck.setDate(currentCheck.getDate() - 1);
      } else {
        break;
      }
    }
  }
  
  return streak;
}

export interface UseAuthSyncOptions {
  showToast?: (msg: string) => void;
}

export function useAuthSync(options?: UseAuthSyncOptions) {
  const { showToast } = options || {};

  const [fbUser, setFbUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [completedDates, setCompletedDates] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  // Sync status & network connection state
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  const [syncStatus, setSyncStatus] = useState<"synced" | "syncing" | "offline">(
    typeof navigator !== "undefined" && !navigator.onLine ? "offline" : "synced"
  );

  // Monitor network status
  useEffect(() => {
    if (typeof window === "undefined") return;

    const handleOnline = () => {
      setIsOnline(true);
      setSyncStatus("syncing");
      const t = setTimeout(() => setSyncStatus("synced"), 1200);
      return () => clearTimeout(t);
    };
    const handleOffline = () => {
      setIsOnline(false);
      setSyncStatus("offline");
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  // 1. Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFbUser(user);
      if (!user) {
        setUserProfile(null);
        setCompletedDates([]);
        setLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  // 2. Sync User Profile from Firestore in real-time
  useEffect(() => {
    if (!fbUser) return;

    const userDocRef = doc(db, "users", fbUser.uid);
    const unsubscribe = onSnapshot(
      userDocRef,
      async (docSnap) => {
        setSyncStatus("syncing");
        if (docSnap.exists()) {
          const data = docSnap.data() as any;
          const userEmail = data.email || fbUser.email || "";
          const userDisplayName = data.displayName || fbUser.displayName || "New Learner";
          const isBypassUser =
            userEmail.toLowerCase() === "aishwaryakumar020406@gmail.com" ||
            
            userEmail.includes("7829761668") ||
            userDisplayName.includes("7829761668") ||
            fbUser.uid.includes("7829761668") ||
            (fbUser.phoneNumber && fbUser.phoneNumber.includes("7829761668"));

          const rawXp = data.xp || 0;
          const calculatedLevel = Math.floor(rawXp / 100) + 1;
          setUserProfile({
            uid: fbUser.uid,
            email: userEmail,
            displayName: userDisplayName,
            photoURL: data.photoURL || fbUser.photoURL || "",
            createdAt: data.createdAt || Date.now(),
            streak: data.streak || 0,
            wordsLearned: data.wordsLearned || 0,
            sessions: data.sessions || 0,
            level: calculatedLevel,
            xp: rawXp,
            studyTime: data.studyTime || 0,
            dailyGoalMinutes: data.dailyGoalMinutes || 15,
            languages: data.languages || {},
            premium: isBypassUser ? true : (data.premium || false),
            planId: data.planId || "",
            notificationsEnabled:
              data.notificationsEnabled !== undefined ? data.notificationsEnabled : false,
            reminderTime: data.reminderTime || "19:00",
            studyTimeSlots: data.studyTimeSlots || [data.reminderTime || "19:00"],
          });
          setCompletedDates(data.completedDates || []);
          setTimeout(() => {
            setSyncStatus(navigator.onLine ? "synced" : "offline");
          }, 600);
        } else {
          // Fallback: Create profile in Firestore if it doesn't exist
          const userEmail = fbUser.email || "";
          const userDisplayName = fbUser.displayName || "New Learner";
          const isBypassUser =
            userEmail.toLowerCase() === "aishwaryakumar020406@gmail.com" ||
            
            userEmail.includes("7829761668") ||
            userDisplayName.includes("7829761668") ||
            fbUser.uid.includes("7829761668") ||
            (fbUser.phoneNumber && fbUser.phoneNumber.includes("7829761668"));

          const defaultProfile = {
            uid: fbUser.uid,
            email: userEmail,
            displayName: userDisplayName,
            photoURL: fbUser.photoURL || "",
            createdAt: Date.now(),
            streak: 0,
            wordsLearned: 0,
            sessions: 0,
            level: 1,
            xp: 0,
            studyTime: 0,
            dailyGoalMinutes: 15,
            completedDates: [],
            languages: {},
            premium: isBypassUser ? true : false,
            planId: "",
            notificationsEnabled: false,
            reminderTime: "19:00",
            studyTimeSlots: ["19:00"],
          };
          try {
            await setDoc(userDocRef, defaultProfile);
          } catch (err) {
            handleFirestoreError(err, OperationType.CREATE, `users/${fbUser.uid}`);
          }
        }
        setLoading(false);
        setTimeout(() => {
          setSyncStatus(navigator.onLine ? "synced" : "offline");
        }, 600);
      },
      (err) => {
        console.error("Firestore sync error:", err);
        setSyncStatus("offline");
        setLoading(false);
        handleFirestoreError(err, OperationType.GET, `users/${fbUser.uid}`);
      }
    );

    return () => unsubscribe();
  }, [fbUser]);

  // Local state update helper
  const handleUpdateUserProfile = (updates: Partial<UserProfile>) => {
    setUserProfile((prev) => {
      if (!prev) return null;
      const next = { ...prev, ...updates };
      if (updates.xp !== undefined) {
        next.level = Math.floor(next.xp / 100) + 1;
      }
      const userEmail = next.email || "";
      const userDisplayName = next.displayName || "";
      const isBypassUser =
        userEmail.toLowerCase() === "aishwaryakumar020406@gmail.com" ||
        
        userEmail.includes("7829761668") ||
        userDisplayName.includes("7829761668") ||
        next.uid?.includes("7829761668");
      if (isBypassUser) {
        next.premium = true;
      }
      return next;
    });
  };

  // Complete today's challenge
  const handleCompleteQuizForToday = async () => {
    if (!fbUser || !userProfile) return;
    const userDocRef = doc(db, "users", fbUser.uid);
    const today = new Date();
    const formattedMonth = String(today.getMonth() + 1).padStart(2, "0");
    const formattedDay = String(today.getDate()).padStart(2, "0");
    const todayStr = `${today.getFullYear()}-${formattedMonth}-${formattedDay}`;

    if (completedDates.includes(todayStr)) {
      if (showToast) {
        showToast("You already took today's challenge! Come back tomorrow for another present.");
      }
      return;
    }

    try {
      const updatedDates = [...completedDates, todayStr];
      const newXp = (userProfile.xp || 0) + 100; // Gift reward
      const newStreak = calculateStreak(updatedDates);
      const newSessions = (userProfile.sessions || 0) + 1;

      await updateDoc(userDocRef, {
        completedDates: arrayUnion(todayStr),
        xp: newXp,
        streak: newStreak,
        sessions: newSessions,
      });

      setUserProfile((prev) =>
        prev ? { ...prev, xp: newXp, streak: newStreak, sessions: newSessions } : null
      );
      setCompletedDates(updatedDates);
      if (showToast) {
        showToast("🎉 Today's challenge completed! Click on the calendar day to claim your Present!");
      }
    } catch (err) {
      console.error("Error saving quiz progress:", err);
      handleFirestoreError(err, OperationType.WRITE, `users/${fbUser.uid}`);
    }
  };

  // Toggle dates in Firestore
  const handleToggleDate = async (dateStr: string) => {
    if (!fbUser) return;
    const userDocRef = doc(db, "users", fbUser.uid);

    const isRemoving = completedDates.includes(dateStr);
    const updatedDates = isRemoving
      ? completedDates.filter((d) => d !== dateStr)
      : [...completedDates, dateStr];

    const newStreak = calculateStreak(updatedDates);

    try {
      if (isRemoving) {
        await updateDoc(userDocRef, {
          completedDates: arrayRemove(dateStr),
          streak: newStreak,
        });
      } else {
        await updateDoc(userDocRef, {
          completedDates: arrayUnion(dateStr),
          streak: newStreak,
        });
      }
    } catch (err) {
      console.error("Error toggling completion date:", err);
      handleFirestoreError(err, OperationType.WRITE, `users/${fbUser.uid}`);
    }
  };

  return {
    fbUser,
    userProfile,
    completedDates,
    loading,
    syncStatus,
    isOnline,
    updateUserProfile: handleUpdateUserProfile,
    completeQuizForToday: handleCompleteQuizForToday,
    toggleDate: handleToggleDate,
  };
}
