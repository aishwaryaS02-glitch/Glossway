// Unified API Fetching wrapper with automatic retry, exponential backoff, and global error dispatching
export interface ApiFetchOptions extends RequestInit {
  retryAction?: () => Promise<any> | any;
  actionName?: string;
  skipGlobalToast?: boolean;
  retries?: number;
  delayMs?: number;
}

// Custom event name for API errors
export const GEMINI_API_ERROR_EVENT = "gemini-api-error";

export interface GeminiApiErrorDetail {
  message: string;
  actionName?: string;
  onRetry: () => Promise<void> | void;
}

// Helper to trigger the global error toast/banner
export function triggerGlobalErrorToast(message: string, onRetry: () => Promise<void> | void, actionName?: string) {
  const detail: GeminiApiErrorDetail = { message, actionName, onRetry };
  const event = new CustomEvent(GEMINI_API_ERROR_EVENT, { detail });
  window.dispatchEvent(event);
}

export async function apiFetch(
  url: string,
  options: ApiFetchOptions = {}
): Promise<Response> {
  const {
    retryAction,
    actionName = "AI Request",
    skipGlobalToast = false,
    retries = 3,
    delayMs = 1000,
    ...fetchOptions
  } = options;

  try {
    const res = await fetch(url, fetchOptions);

    // If it's a transient status (503 Service Unavailable, 429 Too Many Requests, or 502/504 Bad Gateway/Gateway Timeout)
    const isTransient = res.status === 503 || res.status === 429 || res.status === 502 || res.status === 504;

    if (!res.ok && isTransient && retries > 0) {
      console.warn(`Transient API error (${res.status}) on ${url}. Retrying in ${delayMs}ms... (${retries} retries left)`);
      await new Promise((resolve) => setTimeout(resolve, delayMs));
      return apiFetch(url, {
        ...options,
        retries: retries - 1,
        delayMs: delayMs * 2, // Exponential backoff
      });
    }

    if (!res.ok) {
      // Parse error body if possible
      let errorMessage = `API Request failed with status ${res.status}`;
      try {
        const text = await res.clone().text();
        if (text) {
          try {
            const body = JSON.parse(text);
            if (body && body.error) {
              errorMessage = body.error;
            } else if (body && body.message) {
              errorMessage = body.message;
            } else {
              errorMessage = text.substring(0, 200);
            }
          } catch (_) {
            errorMessage = text.substring(0, 200);
          }
        }
      } catch (_) {
        // Fallback to text status
      }


      // If we still fail with 503/429/etc, notify user via global event
      if (!skipGlobalToast && retryAction && (res.status === 503 || res.status === 429 || res.status === 500)) {
        triggerGlobalErrorToast(errorMessage, retryAction, actionName);
      }
      
      return res;
    }

    return res;
  } catch (err: any) {
    if (retries > 0) {
      console.warn(`Network/Transient error on ${url}. Retrying in ${delayMs}ms... (${retries} retries left)`, err);
      await new Promise((resolve) => setTimeout(resolve, delayMs));
      return apiFetch(url, {
        ...options,
        retries: retries - 1,
        delayMs: delayMs * 2,
      });
    }

    const errorMsg = err?.message || String(err) || "Network connection error";
    if (!skipGlobalToast && retryAction) {
      triggerGlobalErrorToast(errorMsg, retryAction, actionName);
    }
    throw err;
  }
}
