import { apiFetch } from "./api";

export interface HighThinkingChatParams {
  prompt: string;
  history: any[];
  language: string;
}

export interface TranscribeAudioParams {
  audioBase64: string;
  mimeType: string;
  promptContext?: string;
}

export interface GenerateImageParams {
  prompt: string;
  aspectRatio: string;
  imageSize: string;
  quality: string;
}

export interface GenerateVideoParams {
  prompt: string;
  aspectRatio: string;
}

export interface VideoStatusParams {
  operationName: string;
}

export interface VideoDownloadParams {
  operationName: string;
}

export interface AnalyzeImageParams {
  imageBase64: string;
  mimeType: string;
  prompt: string;
}

export interface GenerateMusicParams {
  prompt: string;
  model: string;
}

export interface ExpandWordsParams {
  languageId: string;
  languageName: string;
  levelName: string;
}

export interface DictionaryParams {
  word: string;
  targetLanguage: string;
}

export interface QuickAddParseParams {
  textList: string;
  targetLanguage: string;
}

export interface CompositionCritiqueParams {
  text: string;
  targetLanguage: string;
}

export interface ChatParams {
  prompt: string;
  modelType?: string;
  language?: string;
  isFlashcardGenerator?: boolean;
}

export interface SpeakParams {
  text: string;
  language: string;
}

export interface MentorSuggestionsParams {
  todaySeconds: number;
  wordsLearned: number;
  activeLanguages: any;
}

export const apiService = {
  /**
   * Post reasoning chat prompt to high thinking reasoning endpoint
   */
  async highThinkingChat(params: HighThinkingChatParams, retryAction: () => void) {
    const res = await apiFetch("/api/high-thinking-chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "Linguistic Reasoning Chat",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Reasoning search engine failed.");
    }
    return res.json();
  },

  /**
   * Transcribe recorded audio with custom prompt contextual feedback
   */
  async transcribeAudio(params: TranscribeAudioParams, retryAction: () => void, customActionName = "Audio Pronunciation Coach") {
    const res = await apiFetch("/api/transcribe-audio", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: customActionName,
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Audio analysis request failed.");
    }
    return res.json();
  },

  /**
   * Generate an image for visual study aids (flashcards)
   */
  async generateImage(params: GenerateImageParams, retryAction: () => void) {
    const res = await apiFetch("/api/generate-image", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "AI Flashcard Image Generator",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Failed to generate image.");
    }
    return res.json();
  },

  /**
   * Generate high-quality learning video utilizing Veo
   */
  async generateVideo(params: GenerateVideoParams, retryAction: () => void) {
    const res = await apiFetch("/api/generate-video", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "AI Cinema Video Generator",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Video generation request failed.");
    }
    return res.json();
  },

  /**
   * Poll video rendering state
   */
  async videoStatus(params: VideoStatusParams) {
    const res = await apiFetch("/api/video-status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      skipGlobalToast: true,
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Failed to check video status.");
    }
    return res.json();
  },

  /**
   * Download the finalized video binary
   */
  async videoDownload(params: VideoDownloadParams) {
    const res = await apiFetch("/api/video-download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      skipGlobalToast: true,
    });
    if (!res.ok) {
      throw new Error("Download pipeline failed.");
    }
    return res.blob();
  },

  /**
   * Analyze uploaded study photo or infographic
   */
  async analyzeImage(params: AnalyzeImageParams, retryAction: () => void) {
    const res = await apiFetch("/api/analyze-image", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "Visual Vocabulary Scanner",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Image analysis query failed.");
    }
    return res.json();
  },

  /**
   * Generate lofi background focus music via Lyria
   */
  async generateMusic(params: GenerateMusicParams, retryAction: () => void) {
    const res = await apiFetch("/api/generate-music", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "Lofi Focus Beat Generator",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Ambient focus generation pipeline failed.");
    }
    return res.json();
  },

  /**
   * Expand beginner, intermediate, or pro vocabulary sets dynamically
   */
  async expandWords(params: ExpandWordsParams, retryAction: () => void) {
    const res = await apiFetch("/api/expand-words", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "Vocabulary Sandbox Expander",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Failed to load more vocabulary.");
    }
    return res.json();
  },

  /**
   * Fetch thorough translations, dictionary meanings, romanizations, and examples
   */
  async dictionary(params: DictionaryParams, retryAction: () => void) {
    const res = await apiFetch("/api/dictionary", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "Linguistic Scholar Dictionary",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Failed to fetch dictionary definition.");
    }
    return res.json();
  },

  /**
   * Bulk-compile text lists into structured vocab flashcards
   */
  async quickAddParse(params: QuickAddParseParams, retryAction: () => void) {
    const res = await apiFetch("/api/quick-add-parse", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "Interactive Quick Add Compiler",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Failed to compile the quick-add list.");
    }
    return res.json();
  },

  /**
   * Critique user creative language compositions
   */
  async compositionCritique(params: CompositionCritiqueParams, retryAction: () => void) {
    const res = await apiFetch("/api/composition-critique", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "Creative Composition Analyst",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Failed to analyze composition.");
    }
    return res.json();
  },

  /**
   * Main language assistant conversational chat / thematic generator
   */
  async chat(params: ChatParams, retryAction: () => void, customActionName = "Linguistic Example Framer") {
    const res = await apiFetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: customActionName,
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "AI request failed.");
    }
    return res.json();
  },

  /**
   * Synthesize natural pronunciation audio (TTS)
   */
  async speak(params: SpeakParams, retryAction: () => void) {
    const res = await apiFetch("/api/speak", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "Voice Synth",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Voice speech synthesis failed.");
    }
    return res.json();
  },

  /**
   * Get smart study insights and daily encouragement suggestions
   */
  async mentorSuggestions(params: MentorSuggestionsParams, retryAction: () => void) {
    const res = await apiFetch("/api/mentor-suggestions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
      retryAction,
      actionName: "Linguistic Mentor Suggestions",
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || "Failed to fetch mentor suggestions.");
    }
    return res.json();
  }
};
