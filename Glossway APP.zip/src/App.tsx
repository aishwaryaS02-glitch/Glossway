import { AILearningAgent } from "./components/AILearningAgent";
import { useState, useEffect, useRef } from "react";
import { useAuthSync } from "./hooks/useAuthSync";
import AuthView from "./components/AuthView";
import AuthActionView from "./components/AuthActionView";
import Dashboard from "./components/Dashboard";
import FlashcardsView from "./components/FlashcardsView";
import QuizView from "./components/QuizView";
import ProfileView from "./components/ProfileView";
import LearningPortal from "./components/LearningPortal";
import WorldDictionary from "./components/WorldDictionary";
import PricingModal from "./components/PricingModal";
import LevelUpCelebrationModal from "./components/LevelUpCelebrationModal";
import confetti from "canvas-confetti";
import {
  Compass,
  Award,
  Flame,
  Search,
  Bell,
  Languages,
  User as UserIcon,
  Home,
  BookOpen,
  Cloud,
  CloudOff,
  Sun,
  Moon,
  ArrowLeft,
  RefreshCw,
} from "lucide-react";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<string>("dashboard");
  const [showPricingModal, setShowPricingModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [geminiApiError, setGeminiApiError] = useState<{ message: string; actionName?: string; onRetry: () => void } | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [actionParams, setActionParams] = useState<{ mode: string; oobCode: string } | null>(null);
  const [selectedLanguageId, setSelectedLanguageId] = useState<string>("kannada");
  const [showNotifications, setShowNotifications] = useState(false);
  const [showStreakDetails, setShowStreakDetails] = useState(false);
  const [showMobileSearch, setShowMobileSearch] = useState(false);

  const notificationsRef = useRef<HTMLDivElement>(null);
  const streakRef = useRef<HTMLDivElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  useEffect(() => {
    const handleGeminiApiError = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail) {
        setGeminiApiError({
          message: detail.message,
          actionName: detail.actionName,
          onRetry: detail.onRetry,
        });
      }
    };

    window.addEventListener("gemini-api-error", handleGeminiApiError);
    return () => {
      window.removeEventListener("gemini-api-error", handleGeminiApiError);
    };
  }, []);

  const {
    fbUser,
    userProfile,
    completedDates,
    loading,
    syncStatus,
    updateUserProfile,
    completeQuizForToday,
    toggleDate,
  } = useAuthSync({
    showToast,
  });

  // Light vs Dark Theme state
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    if (typeof window !== "undefined") {
      return (localStorage.getItem("glossway-theme") as "light" | "dark") || "light";
    }
    return "light";
  });

  useEffect(() => {
    localStorage.setItem("glossway-theme", theme);
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  // Close menus when clicking outside or pressing Escape key
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
      if (streakRef.current && !streakRef.current.contains(event.target as Node)) {
        setShowStreakDetails(false);
      }
    }

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setShowNotifications(false);
        setShowStreakDetails(false);
        setShowMobileSearch(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  // Background loop to trigger study slot push notifications
  useEffect(() => {
    if (!userProfile?.notificationsEnabled) return;

    const checkSlotsAndNotify = () => {
      try {
        const slots = userProfile.studyTimeSlots || [userProfile.reminderTime || "19:00"];
        if (slots.length === 0) return;

        const now = new Date();
        const currentHour = String(now.getHours()).padStart(2, "0");
        const currentMin = String(now.getMinutes()).padStart(2, "0");
        const currentTimeStr = `${currentHour}:${currentMin}`;
        const todayStr = now.toISOString().split("T")[0];

        // Check if any slot matches the current time (exact HH:MM matching)
        if (slots.includes(currentTimeStr)) {
          const notifiedKey = `glossway_slot_notified_${todayStr}_${currentTimeStr}`;
          
          if (localStorage.getItem(notifiedKey) !== "true") {
            // Mark as notified immediately to prevent re-triggering during the same minute
            localStorage.setItem(notifiedKey, "true");

            // 1. Trigger System Push Notification
            if ("Notification" in window && Notification.permission === "granted") {
              try {
                const n = new Notification("Glossway Study Reminder 🎯", {
                  body: `It's time for your scheduled study slot (${currentTimeStr})! Tap to keep your streak!`,
                  icon: "/favicon.ico",
                  tag: `glossway-reminder-${currentTimeStr}`,
                });
                n.onclick = () => {
                  window.focus();
                  setCurrentScreen("dashboard");
                };
              } catch (e) {
                console.error("HTML5 Notification creation failed:", e);
              }
            }

            // 2. Trigger In-App Notification (so it works inside iframe perfectly)
            showToast(`🔔 Scheduled Study Slot (${currentTimeStr}) is active! Let's study!`);
          }
        }
      } catch (err) {
        console.error("Error in study slots checker loop:", err);
      }
    };

    // Check immediately and then every 15 seconds
    checkSlotsAndNotify();
    const intervalId = setInterval(checkSlotsAndNotify, 15000);

    return () => clearInterval(intervalId);
  }, [userProfile?.notificationsEnabled, userProfile?.studyTimeSlots, userProfile?.reminderTime]);

  // Level Up Celebration State
  const [lastSeenLevel, setLastSeenLevel] = useState<number | null>(null);
  const [showLevelUpModal, setShowLevelUpModal] = useState(false);
  const [levelUpData, setLevelUpData] = useState<{
    oldLevel: number;
    newLevel: number;
    xp: number;
    words: number;
    streak: number;
    sessions: number;
  } | null>(null);

  // Monitor userProfile level changes to trigger celebration
  useEffect(() => {
    if (userProfile && userProfile.level !== undefined) {
      if (lastSeenLevel !== null && userProfile.level > lastSeenLevel) {
        setLevelUpData({
          oldLevel: lastSeenLevel,
          newLevel: userProfile.level,
          xp: userProfile.xp || 0,
          words: userProfile.wordsLearned || 0,
          streak: userProfile.streak || 0,
          sessions: userProfile.sessions || 0,
        });
        setShowLevelUpModal(true);
      }
      setLastSeenLevel(userProfile.level);
    }
  }, [userProfile?.level, lastSeenLevel]);

  // Check URL parameters for Firebase Auth Actions on mount
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const mode = urlParams.get("mode");
    const oobCode = urlParams.get("oobCode");
    if (mode && oobCode) {
      setActionParams({ mode, oobCode });
    }
  }, []);

  // Hook/Effect for Web Speech API Voice Selection and Accent Synchronization
  useEffect(() => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;

    const langMap: Record<string, string> = {
      english: "en-GB", // Oxford UK standard accent
      spanish: "es-ES", // Castilian Spanish accent
      french: "fr-FR",  // Paris accent
      german: "de-DE",  // German accent
      mandarin: "zh-CN", // Mandarin standard accent
      japanese: "ja-JP", // Japanese accent
      hindi: "hi-IN",   // New Delhi fluent accent
      russian: "ru-RU",  // Russian accent
      arabic: "ar-SA",   // Arabic accent
      kannada: "kn-IN",  // Kannada fluent accent
    };

    const targetLangTag = langMap[selectedLanguageId] || "en-US";
    (window as any).__activeLanguageTag = targetLangTag;

    const updateVoiceSelection = () => {
      const voices = window.speechSynthesis.getVoices();
      if (!voices || voices.length === 0) return;

      // 1. Try to find exact match for regional accent (e.g., hi-IN or kn-IN)
      let selectedVoice = voices.find(
        (voice) => voice.lang.toLowerCase() === targetLangTag.toLowerCase() ||
                   voice.lang.toLowerCase().replace("_", "-") === targetLangTag.toLowerCase()
      );

      // 2. If no exact match, try matching by prefix (e.g., hi or kn or es)
      if (!selectedVoice) {
        const prefix = targetLangTag.split("-")[0].toLowerCase();
        selectedVoice = voices.find((voice) =>
          voice.lang.toLowerCase().startsWith(prefix)
        );
      }

      // 3. Fallback to any English or first voice if none
      if (!selectedVoice) {
        selectedVoice = voices.find((voice) =>
          voice.lang.toLowerCase().startsWith("en")
        );
      }

      if (selectedVoice) {
        (window as any).__activeVoice = selectedVoice;
      }
    };

    updateVoiceSelection();
    
    // Web Speech API loads voices asynchronously in some environments
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = updateVoiceSelection;
    }

    return () => {
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, [selectedLanguageId]);

  const handleUpgradeToPlus = () => {
    setShowPricingModal(true);
  };

  // Render Firebase Auth Action Handler if URL parameters are detected
  if (actionParams) {
    return (
      <AuthActionView
        mode={actionParams.mode}
        oobCode={actionParams.oobCode}
        onClearAction={() => {
          // Clear query parameters from URL without reloading
          const url = new URL(window.location.href);
          url.searchParams.delete("mode");
          url.searchParams.delete("oobCode");
          window.history.replaceState({}, "", url.toString());
          setActionParams(null);
        }}
      />
    );
  }

  // Render Loader
  if (loading && fbUser) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center font-sans">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 bg-surface shadow-neo rounded-full animate-spin border-4 border-t-primary border-r-transparent border-b-transparent border-l-transparent"></div>
          <p className="text-on-surface font-bold text-sm tracking-wide">Synchronizing with Glossway...</p>
        </div>
      </div>
    );
  }

  // Not Authenticated
  if (!fbUser) {
    return <AuthView />;
  }

  // Screen Switching router
  const renderScreen = () => {
    switch (currentScreen) {
      case "dashboard":
        return (
          <Dashboard
            userProfile={userProfile}
            onUpdateUserProfile={updateUserProfile}
            onNavigate={setCurrentScreen}
            completedDates={completedDates}
            onToggleDate={toggleDate}
            onSelectLanguage={setSelectedLanguageId}
            showToast={showToast}
          />
        );
      case "cards":
        return (
          <FlashcardsView
            userProfile={userProfile}
            onUpdateUserProfile={updateUserProfile}
            onNavigate={setCurrentScreen}
          />
        );
      case "quiz":
        return (
          <QuizView
            userProfile={userProfile}
            onUpdateUserProfile={updateUserProfile}
            onNavigate={setCurrentScreen}
            onCompleteQuiz={completeQuizForToday}
            selectedLanguageId={selectedLanguageId}
          />
        );
      case "profile":
        return (
          <ProfileView
            userProfile={userProfile}
            onUpdateUserProfile={updateUserProfile}
            onNavigate={setCurrentScreen}
            onOpenBilling={() => setShowPricingModal(true)}
          />
        );
      case "learning":
        return (
          <LearningPortal
            userProfile={userProfile}
            onUpdateUserProfile={updateUserProfile}
            onNavigate={setCurrentScreen}
            onOpenBilling={() => setShowPricingModal(true)}
            selectedLanguageId={selectedLanguageId}
            onSelectLanguage={setSelectedLanguageId}
          />
        );
      case "dictionary":
        return (
          <WorldDictionary
            userProfile={userProfile}
            onNavigate={setCurrentScreen}
            selectedLanguageId={selectedLanguageId}
            onSelectLanguage={setSelectedLanguageId}
            onUpdateUserProfile={updateUserProfile}
            searchQuery={searchQuery}
            onSearchQueryChange={setSearchQuery}
          />
        );
      default:
        return (
          <Dashboard
            userProfile={userProfile}
            onNavigate={setCurrentScreen}
            completedDates={completedDates}
            onToggleDate={toggleDate}
            onSelectLanguage={setSelectedLanguageId}
            showToast={showToast}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#f3f7f5] font-sans text-black flex overflow-x-hidden">
      {/* 1. Left Sidebar Navigation (Desktop only) */}
      <nav className="h-screen w-64 fixed left-0 top-0 bg-[#e8f0eb] flex flex-col py-8 px-6 gap-6 z-40 border-r border-[#0f241d15] hidden md:flex">
        <div className="mb-6 px-2 flex flex-col gap-1 items-start">
          <span className="font-sans font-semibold tracking-tight text-3xl font-semibold tracking-tight text-black">
            Glossway
          </span>
          <span className="text-[9px] font-mono tracking-[0.25em] uppercase text-[#0f241d60] mt-0.5">
            Language Journal
          </span>
        </div>

        {/* Sidebar Menu options */}
        <div className="flex flex-col gap-2 flex-grow mt-4">
          <button
            onClick={() => setCurrentScreen("dashboard")}
            className={`flex items-center gap-4 px-4 py-3 text-xs font-mono uppercase tracking-wider transition-all duration-200 cursor-pointer ${
              currentScreen === "dashboard" || currentScreen === "quiz"
                ? "text-[#f3f7f5] bg-[#0f241d] border border-[#0f241d]"
                : "text-[#0f241d80] hover:text-black hover:bg-[#0f241d05] border border-transparent"
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setCurrentScreen("learning")}
            className={`flex items-center gap-4 px-4 py-3 text-xs font-mono uppercase tracking-wider transition-all duration-200 cursor-pointer ${
              currentScreen === "learning"
                ? "text-[#f3f7f5] bg-[#0f241d] border border-[#0f241d]"
                : "text-[#0f241d80] hover:text-black hover:bg-[#0f241d05] border border-transparent"
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Learning Portal</span>
          </button>

          <button
            onClick={() => setCurrentScreen("dictionary")}
            className={`flex items-center gap-4 px-4 py-3 text-xs font-mono uppercase tracking-wider transition-all duration-200 cursor-pointer ${
              currentScreen === "dictionary"
                ? "text-[#f3f7f5] bg-[#0f241d] border border-[#0f241d]"
                : "text-[#0f241d80] hover:text-black hover:bg-[#0f241d05] border border-transparent"
            }`}
          >
            <Languages className="w-4 h-4" />
            <span>World Dictionary</span>
          </button>

          <button
            onClick={() => setCurrentScreen("cards")}
            className={`flex items-center gap-4 px-4 py-3 text-xs font-mono uppercase tracking-wider transition-all duration-200 cursor-pointer ${
              currentScreen === "cards"
                ? "text-[#f3f7f5] bg-[#0f241d] border border-[#0f241d]"
                : "text-[#0f241d80] hover:text-black hover:bg-[#0f241d05] border border-transparent"
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Cards</span>
          </button>

          <button
            onClick={() => setCurrentScreen("profile")}
            className={`flex items-center gap-4 px-4 py-3 text-xs font-mono uppercase tracking-wider transition-all duration-200 cursor-pointer ${
              currentScreen === "profile"
                ? "text-[#f3f7f5] bg-[#0f241d] border border-[#0f241d]"
                : "text-[#0f241d80] hover:text-black hover:bg-[#0f241d05] border border-transparent"
            }`}
          >
            <UserIcon className="w-4 h-4" />
            <span>Progress</span>
          </button>
        </div>

        {/* Sidebar Bottom widgets */}
        <div className="mt-auto space-y-3 pt-4 border-t border-[#0f241d10]">
          {/* Theme Selector Widget */}
          <div className="flex items-center justify-between p-2.5 bg-white border border-[#0f241d10]">
            <span className="text-[9px] font-mono uppercase tracking-wider text-[#0f241d60] select-none">
              Evening Study Mode
            </span>
            <button
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              className="p-1.5 bg-[#f3f7f5] border border-[#0f241d15] text-[#0f241d80] hover:text-black transition-colors cursor-pointer rounded-full flex items-center justify-center"
              title={theme === "light" ? "Switch to Evening Dark Mode" : "Switch to Editorial Light Mode"}
            >
              {theme === "light" ? (
                <Moon className="w-3.5 h-3.5" />
              ) : (
                <Sun className="w-3.5 h-3.5 text-[#2d7a64]" />
              )}
            </button>
          </div>

          <button
            onClick={handleUpgradeToPlus}
            className="w-full bg-[#0f241d] hover:bg-[#25332e] hover:text-white text-[#f3f7f5] font-mono text-[10px] uppercase tracking-widest py-3 border border-[#0f241d] transition-all duration-150 cursor-pointer"
          >
            Upgrade to Plus
          </button>
          <div
            onClick={() => setCurrentScreen("profile")}
            className="flex items-center gap-3 p-3 bg-white border border-[#0f241d10] cursor-pointer hover:bg-[#f3f7f5] transition-colors"
          >
            <div className="w-8 h-8 rounded-full overflow-hidden bg-white border border-[#0f241d15] flex items-center justify-center">
              {userProfile?.photoURL ? (
                <img src={userProfile.photoURL} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <UserIcon className="w-4 h-4 text-black" />
              )}
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-semibold text-black leading-tight select-none">
                {userProfile ? userProfile.displayName : "Alex Rivera"}
              </span>
              <span className="text-[9px] font-mono text-[#0f241d60] uppercase tracking-wider leading-none mt-0.5">
                Lvl {userProfile ? userProfile.level : 1} Explorer
              </span>
            </div>
          </div>
        </div>
      </nav>

      {/* 2. Top Header Navigation (Responsive layout) */}
      <header className="fixed top-0 right-0 w-full md:w-[calc(100%-16rem)] bg-[#f3f7f5]/95 border-b border-[#0f241d10] backdrop-blur-sm flex justify-between items-center h-20 px-4 sm:px-8 z-30 md:ml-64 transition-all">
        {showMobileSearch ? (
          <div className="flex items-center gap-3 w-full animate-in fade-in slide-in-from-top-2 duration-150">
            <button
              type="button"
              onClick={() => setShowMobileSearch(false)}
              className="p-2 bg-[#f3f7f5] border border-[#0f241d15] text-black transition-colors cursor-pointer"
              title="Cancel search"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (searchQuery.trim()) {
                  setCurrentScreen("dictionary");
                  setShowMobileSearch(false);
                }
              }}
              className="relative flex-1"
            >
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0f241d60]" />
              <input
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => {
                  const query = e.target.value;
                  setSearchQuery(query);
                  if (query.trim() && currentScreen !== "dictionary" && currentScreen !== "quiz" && currentScreen !== "cards") {
                    setCurrentScreen("dictionary");
                  }
                }}
                placeholder="Search words, phrases..."
                className="w-full bg-[#f3f7f5] border border-[#0f241d15] py-2 pl-10 pr-4 text-xs font-mono uppercase tracking-wider text-black outline-none transition-all focus:border-[#0f241d] placeholder:text-[#0f241d80]"
              />
            </form>
          </div>
        ) : (
          <>
            {/* Sidebar Toggle or Branding for mobile */}
            <div className="flex items-center gap-2 md:hidden">
              <span className="font-sans font-semibold tracking-tight text-xl font-bold text-black">
                Glossway
              </span>
            </div>

            {/* Search bar (Desktop only) */}
            <div className="flex-1 max-w-sm hidden sm:block">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (searchQuery.trim()) {
                    setCurrentScreen("dictionary");
                  }
                }}
                className="relative"
              >
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0f241d60]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    const query = e.target.value;
                    setSearchQuery(query);
                    if (query.trim() && currentScreen !== "dictionary" && currentScreen !== "quiz" && currentScreen !== "cards") {
                      setCurrentScreen("dictionary");
                    }
                  }}
                  placeholder="Search words, phrases..."
                  className="w-full bg-[#f3f7f5] border border-[#0f241d15] py-2 pl-10 pr-4 text-xs font-mono uppercase tracking-wider text-black outline-none transition-all focus:border-[#0f241d] placeholder:text-[#0f241d80]"
                />
              </form>
            </div>

            {/* Top bar Actions */}
            <div className="flex items-center gap-2 sm:gap-4">
              {/* Cloud DB Connection indicator */}
              <div className="flex items-center gap-2 px-2.5 py-1.5 border border-[#0f241d10] bg-white select-none rounded-xs" title="Cloud Database Connection and Save Status">
                {syncStatus === "syncing" && (
                  <>
                    <div className="relative flex items-center justify-center">
                      <Cloud className="w-3.5 h-3.5 text-[#2d7a64] animate-pulse" />
                      <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping"></span>
                    </div>
                    <span className="text-[9px] font-mono uppercase tracking-wider text-[#0f241d60] hidden md:inline">
                      Syncing...
                    </span>
                  </>
                )}
                {syncStatus === "synced" && (
                  <>
                    <Cloud className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-[9px] font-mono uppercase tracking-wider text-[#0f241d80] hidden md:inline">
                      Synced
                    </span>
                  </>
                )}
                {syncStatus === "offline" && (
                  <>
                    <CloudOff className="w-3.5 h-3.5 text-rose-500" />
                    <span className="text-[9px] font-mono uppercase tracking-wider text-rose-500 font-semibold hidden md:inline">
                      Offline
                    </span>
                  </>
                )}
              </div>

              {/* Mobile Search Toggle Button */}
              <button
                onClick={() => {
                  setShowMobileSearch(true);
                  setShowNotifications(false);
                  setShowStreakDetails(false);
                }}
                className="p-2.5 bg-[#f3f7f5] border border-[#0f241d15] text-[#0f241d60] hover:text-black hover:border-[#0f241d] transition-colors cursor-pointer sm:hidden"
                title="Search Words"
              >
                <Search className="w-4 h-4" />
              </button>

              {/* Bell Notifications Button & Panel */}
              <div className="relative" ref={notificationsRef}>
                <button
                  onClick={() => {
                    setShowNotifications(!showNotifications);
                    setShowStreakDetails(false); // Close other dropdown
                  }}
                  className={`p-2.5 bg-[#f3f7f5] border text-black transition-colors cursor-pointer relative ${
                    showNotifications ? "border-[#0f241d] bg-[#e8f0eb]" : "border-[#0f241d15] hover:border-[#0f241d]"
                  }`}
                  title="Notifications & Achievements"
                >
                  <Bell className="w-4 h-4" />
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#2d7a64] animate-pulse"></span>
                </button>

                {/* Notifications Popover */}
                {showNotifications && (
                  <div className="absolute right-0 top-12 w-80 max-w-[calc(100vw-2rem)] bg-white border border-[#0f241d] shadow-xl p-5 z-50 text-left font-sans space-y-4 rounded-xs animate-in fade-in slide-in-from-top-4 duration-200">
                    <div className="flex justify-between items-center pb-2 border-b border-[#0f241d10]">
                      <h4 className="font-sans font-semibold tracking-tight font-medium text-black">Notifications</h4>
                      <button
                        onClick={() => setShowNotifications(false)}
                        className="text-[9px] font-mono uppercase text-[#0f241d90] hover:text-black tracking-wider cursor-pointer"
                      >
                        Close [X]
                      </button>
                    </div>

                    {/* Reminder Toggle */}
                    <div className="flex items-center justify-between p-3 bg-[#f3f7f5] border border-[#0f241d08]">
                      <div className="space-y-0.5">
                        <p className="text-[10px] font-mono uppercase tracking-wider font-semibold text-black">Daily Reminders</p>
                        <p className="text-[9px] text-[#0f241d90]">Push study alerts</p>
                      </div>
                      <button
                        onClick={() => {
                          const nextVal = !userProfile?.notificationsEnabled;
                          updateUserProfile({ notificationsEnabled: nextVal });
                          showToast(nextVal ? "🔔 Daily reminders enabled!" : "🔕 Daily reminders disabled.");
                        }}
                        type="button"
                        className={`px-3 py-1 text-[9px] font-mono uppercase tracking-wider border cursor-pointer transition-all ${
                          userProfile?.notificationsEnabled
                            ? "bg-black text-white border-black"
                            : "bg-transparent text-[#0f241d90] border-[#0f241d20] hover:border-black hover:text-black"
                        }`}
                      >
                        {userProfile?.notificationsEnabled ? "ON" : "OFF"}
                      </button>
                    </div>

                    {/* Notification items list */}
                    <div className="space-y-2.5 max-h-56 overflow-y-auto">
                      <div className="p-2.5 border border-[#0f241d05] bg-[#f3f7f5] text-xs space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="font-mono text-[9px] uppercase text-[#2d7a64] tracking-wider font-semibold">Welcome Notification</span>
                          <span className="text-[9px] font-mono text-neutral-400">System</span>
                        </div>
                        <p className="text-black font-semibold font-sans font-semibold tracking-tight text-[11px]">Welcome to Glossway!</p>
                        <p className="text-[#0f241d70] text-[10px] leading-relaxed">Start practicing interactive quizzes to level up and build streak days.</p>
                      </div>

                      <div className="p-2.5 border border-[#0f241d05] bg-[#f3f7f5] text-xs space-y-1.5">
                        <div className="flex justify-between items-center">
                          <span className="font-mono text-[9px] uppercase text-[#2d7a64] tracking-wider font-semibold">Confetti Trigger</span>
                          <span className="text-[9px] font-mono text-neutral-400">Milestone</span>
                        </div>
                        <p className="text-black font-medium text-[11px]">Test your milestone celebrations!</p>
                        <button
                          onClick={() => {
                            confetti({
                              particleCount: 150,
                              spread: 85,
                              origin: { y: 0.6 },
                              colors: ["#2d7a64", "#FFD700", "#FFDF00", "#0f241d", "#E5A93B"]
                            });
                            showToast("✨ Golden particles triggered successfully!");
                          }}
                          type="button"
                          className="w-full py-1.5 bg-white border border-[#0f241d15] hover:border-[#0f241d] font-mono text-[9px] uppercase tracking-wider text-black text-center cursor-pointer transition-colors font-semibold"
                        >
                          Shoot Confetti 🎉
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <button className="p-2.5 bg-[#f3f7f5] border border-[#0f241d15] text-[#0f241d60] hover:text-black hover:border-[#0f241d] transition-colors cursor-pointer">
                <Languages className="w-4 h-4" />
              </button>
              <button
                onClick={() => setTheme(theme === "light" ? "dark" : "light")}
                className="p-2.5 bg-[#f3f7f5] border border-[#0f241d15] text-[#0f241d60] hover:text-black hover:border-[#0f241d] transition-colors cursor-pointer"
                title={theme === "light" ? "Switch to Evening Dark Mode" : "Switch to Editorial Light Mode"}
              >
                {theme === "light" ? (
                  <Moon className="w-4 h-4" />
                ) : (
                  <Sun className="w-4 h-4 text-[#2d7a64]" />
                )}
              </button>
              <div className="h-6 w-[1px] bg-[#0f241d15] mx-2 hidden sm:block"></div>

              {/* Day Streak Button & Panel */}
              <div className="relative" ref={streakRef}>
                <button
                  onClick={() => {
                    setShowStreakDetails(!showStreakDetails);
                    setShowNotifications(false); // Close other dropdown
                  }}
                  className={`flex items-center gap-2 px-3 py-1.5 border font-mono text-[10px] tracking-wider uppercase cursor-pointer select-none transition-colors ${
                    showStreakDetails 
                      ? "bg-[#f3f7f5] border-[#0f241d] text-black" 
                      : "bg-[#f3f7f5] border-[#0f241d15] hover:border-[#0f241d] text-black"
                  }`}
                  title="Active Streak Calendar Details"
                >
                  <Flame className={`w-4 h-4 ${userProfile?.streak && userProfile.streak > 0 ? "text-amber-500 animate-bounce" : "text-black"}`} />
                  <span className="font-bold hidden sm:inline">
                    {userProfile ? userProfile.streak : 0} Day Streak
                  </span>
                  <span className="font-bold inline sm:hidden">
                    {userProfile ? userProfile.streak : 0}d
                  </span>
                </button>

                {/* Streak Calendar Popover */}
                {showStreakDetails && (
                  <div className="absolute right-0 top-12 w-80 max-w-[calc(100vw-2rem)] bg-white border border-[#0f241d] shadow-xl p-5 z-50 text-left font-sans space-y-4 rounded-xs animate-in fade-in slide-in-from-top-4 duration-200">
                    <div className="flex justify-between items-center pb-2 border-b border-[#0f241d10]">
                      <div className="flex items-center gap-1.5 text-black">
                        <Flame className="w-4 h-4 text-amber-500" />
                        <h4 className="font-sans font-semibold tracking-tight font-medium text-black">Streak & Habits</h4>
                      </div>
                      <button
                        onClick={() => setShowStreakDetails(false)}
                        className="text-[9px] font-mono uppercase text-[#0f241d90] hover:text-black tracking-wider cursor-pointer"
                      >
                        Close [X]
                      </button>
                    </div>

                    <div className="p-3 bg-[#f3f7f5] border border-[#0f241d08] space-y-1">
                      <div className="flex justify-between items-baseline">
                        <span className="text-[10px] font-mono uppercase text-[#0f241d60] tracking-wider">Active Streak</span>
                        <span className="text-xl font-sans font-semibold tracking-tight font-bold text-black">{userProfile?.streak || 0} Days</span>
                      </div>
                      <p className="text-[10px] text-[#0f241d90] leading-relaxed">
                        Study daily to preserve your streak! Click any day in the past 2 weeks below to manually check-off or repair dates:
                      </p>
                    </div>

                    {/* 14-day Calendar Grid */}
                    <div className="space-y-2">
                      <p className="text-[9px] font-mono uppercase tracking-wider text-[#0f241d80] font-bold">Past 14 Days Activity</p>
                      <div className="grid grid-cols-7 gap-1.5">
                        {Array.from({ length: 14 }).map((_, idx) => {
                          const d = new Date();
                          d.setDate(d.getDate() - (13 - idx)); // past 14 days up to today
                          const year = d.getFullYear();
                          const month = String(d.getMonth() + 1).padStart(2, "0");
                          const day = String(d.getDate()).padStart(2, "0");
                          const dateStr = `${year}-${month}-${day}`;
                          const isCompleted = completedDates.includes(dateStr);
                          const dayName = d.toLocaleString("default", { weekday: "short" }).substring(0, 2);
                          const isToday = idx === 13;

                          return (
                            <button
                              key={dateStr}
                              onClick={() => {
                                toggleDate(dateStr);
                                showToast(isCompleted ? `Removed study record for ${month}/${day}` : `Logged study record for ${month}/${day}!`);
                              }}
                              type="button"
                              className={`flex flex-col items-center justify-center p-1.5 border transition-all cursor-pointer relative ${
                                isCompleted
                                  ? "bg-black text-white border-black hover:bg-neutral-800"
                                  : "bg-transparent text-[#0f241d90] border-[#0f241d10] hover:border-[#0f241d50] hover:text-black"
                              } ${isToday ? "ring-2 ring-[#2d7a64] ring-offset-1" : ""}`}
                              title={isCompleted ? `Completed on ${dateStr} - Click to toggle` : `Not completed - Click to toggle`}
                            >
                              <span className="text-[7px] font-mono uppercase tracking-wider block opacity-70">{dayName}</span>
                              <span className="text-xs font-mono font-bold block leading-tight mt-0.5">{d.getDate()}</span>
                              {isCompleted && (
                                <span className="absolute bottom-0.5 right-0.5 w-1 h-1 rounded-full bg-emerald-400"></span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Celebrate Button */}
                    <button
                      onClick={() => {
                        confetti({
                          particleCount: 150,
                          spread: 85,
                          origin: { y: 0.6 },
                          colors: ["#2d7a64", "#FFD700", "#FFDF00", "#0f241d", "#E5A93B"]
                        });
                        showToast("🎉 Celebrating your daily streak and progress!");
                      }}
                      type="button"
                      className="w-full py-2 bg-black hover:bg-[#25332e] text-white font-mono text-[10px] uppercase tracking-widest font-bold text-center cursor-pointer transition-all border border-black"
                    >
                      Celebrate Streak 🎉
                    </button>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </header>

      {/* 3. Main Frame Area */}
      <main className="flex-1 min-h-screen pt-24 pb-28 md:pb-12 px-8 ml-0 md:ml-64 w-full">
        <div className="max-w-[900px] mx-auto">
          {renderScreen()}
        </div>
      </main>

      {/* 4. Bottom Navigation Bar (Mobile only) */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#f3f7f5] border-t border-[#0f241d15] flex justify-around items-center px-4 py-2 md:hidden">
        <button
          onClick={() => setCurrentScreen("dashboard")}
          className={`flex flex-col items-center justify-center transition-all p-2 cursor-pointer ${
            currentScreen === "dashboard" || currentScreen === "quiz"
              ? "text-black font-semibold"
              : "text-[#0f241d90] hover:text-black"
          }`}
        >
          <Home className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-mono uppercase tracking-wider">Home</span>
        </button>

        <button
          onClick={() => setCurrentScreen("learning")}
          className={`flex flex-col items-center justify-center transition-all p-2 cursor-pointer ${
            currentScreen === "learning"
              ? "text-black font-semibold"
              : "text-[#0f241d90] hover:text-black"
          }`}
        >
          <BookOpen className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-mono uppercase tracking-wider">Portal</span>
        </button>

        <button
          onClick={() => setCurrentScreen("dictionary")}
          className={`flex flex-col items-center justify-center transition-all p-2 cursor-pointer ${
            currentScreen === "dictionary"
              ? "text-black font-semibold"
              : "text-[#0f241d90] hover:text-black"
          }`}
        >
          <Languages className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-mono uppercase tracking-wider">Lexicon</span>
        </button>

        <button
          onClick={() => setCurrentScreen("cards")}
          className={`flex flex-col items-center justify-center transition-all p-2 cursor-pointer ${
            currentScreen === "cards"
              ? "text-black font-semibold"
              : "text-[#0f241d90] hover:text-black"
          }`}
        >
          <Award className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-mono uppercase tracking-wider">Cards</span>
        </button>

        <button
          onClick={() => setCurrentScreen("profile")}
          className={`flex flex-col items-center justify-center transition-all p-2 cursor-pointer ${
            currentScreen === "profile"
              ? "text-black font-semibold"
              : "text-[#0f241d90] hover:text-black"
          }`}
        >
          <UserIcon className="w-4 h-4 mb-0.5" />
          <span className="text-[9px] font-mono uppercase tracking-wider">Profile</span>
        </button>
      </nav>

      {/* 5. Toast alert banner */}
      {toastMessage && (
        <div className="fixed bottom-24 md:bottom-8 right-8 z-50 bg-[#0f241d] text-white border border-white/10 px-6 py-3 shadow-2xl flex items-center gap-3 font-mono text-xs uppercase tracking-wider">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Gemini API High Demand Unified Retry Banner */}
      {geminiApiError && (
        <div className="fixed bottom-24 md:bottom-8 left-4 right-4 md:left-auto md:right-8 md:max-w-md z-50 bg-[#f3f7f5] text-black border border-[#0f241d15] p-4 shadow-2xl flex flex-col gap-3 rounded-sm font-mono text-xs transition-all animate-in fade-in slide-in-from-bottom-5">
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center text-red-600 mt-0.5 shrink-0 border border-red-200">
              ⚠️
            </div>
            <div className="flex-1">
              <p className="font-bold uppercase tracking-wider text-black flex flex-wrap items-center gap-1.5">
                <span>API Notification</span>
                {geminiApiError.actionName && (
                  <span className="text-[9px] font-semibold bg-[#0f241d10] text-[#0f241d80] px-2 py-0.5 rounded-sm tracking-normal border border-[#0f241d10]">
                    {geminiApiError.actionName}
                  </span>
                )}
              </p>
              <p className="text-[11px] text-[#0f241d70] mt-1 font-sans normal-case leading-relaxed">
                {geminiApiError.message || "The AI model is experiencing heavy traffic. Would you like to try again?"}
              </p>
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-1.5 border-t border-[#0f241d10] pt-2.5">
            <button
              onClick={() => setGeminiApiError(null)}
              className="px-3 py-1.5 text-[#0f241d60] hover:text-black hover:bg-[#0f241d05] font-semibold rounded transition cursor-pointer"
            >
              Dismiss
            </button>
            <button
              onClick={() => {
                const retryFn = geminiApiError.onRetry;
                setGeminiApiError(null);
                if (retryFn) {
                  retryFn();
                }
              }}
              className="px-3.5 py-1.5 bg-[#0f241d] text-[#f3f7f5] font-bold rounded-sm hover:bg-neutral-800 flex items-center gap-1.5 transition shadow-sm cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry Request</span>
            </button>
          </div>
        </div>
      )}

      {/* 6. Pricing Modal (Indian Currency Bread Plan) */}
      {showPricingModal && (
        <PricingModal
          userProfile={userProfile}
          onUpdateUserProfile={updateUserProfile}
          onClose={() => setShowPricingModal(false)}
          showToast={showToast}
        />
      )}

      {/* 8. AI Learning Agent Widget */}
      <AILearningAgent userProfile={userProfile} />

      {/* 7. Level Up Celebration Modal */}
      {showLevelUpModal && levelUpData && (
        <LevelUpCelebrationModal
          isOpen={showLevelUpModal}
          data={levelUpData}
          onClose={() => setShowLevelUpModal(false)}
        />
      )}
    </div>
  );
}
