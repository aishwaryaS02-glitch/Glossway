import { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Trophy, Crown } from "lucide-react";

interface MilestoneCelebrationProps {
  milestone: {
    id: string;
    title: string;
    description: string;
    icon: any;
    color: string;
  } | null;
  onClose: () => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  rotation: number;
  rotationSpeed: number;
  shape: "circle" | "square" | "triangle" | "star";
  opacity: number;
}

export default function MilestoneCelebration({ milestone, onClose }: MilestoneCelebrationProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!canvasRef.current || !milestone) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    // Palettes for premium gold-tinted look
    const goldPalette = [
      "#FFD700", // Gold
      "#DAA520", // Goldenrod
      "#FFDF00", // Imperial Gold
      "#F4C430", // Saffron
      "#E5A93B", // Antique Gold
      "#FFFDD0", // Cream
      "#0f241d", // Shimmering White
    ];

    const particles: Particle[] = [];

    // Create initial burst
    const createParticle = (x: number, y: number, isInitialBurst = false): Particle => {
      const angle = Math.random() * Math.PI * 2;
      const speed = isInitialBurst ? Math.random() * 8 + 4 : Math.random() * 4 + 1;
      const shapes: ("circle" | "square" | "triangle" | "star")[] = ["circle", "square", "star", "triangle"];
      return {
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - (isInitialBurst ? Math.random() * 5 + 3 : 0), // Upward bias for burst
        size: Math.random() * 6 + 4,
        color: goldPalette[Math.floor(Math.random() * goldPalette.length)],
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.2,
        shape: shapes[Math.floor(Math.random() * shapes.length)],
        opacity: 1,
      };
    };

    // Spawn initial burst of particles from the bottom-left and bottom-right corners, and the center
    for (let i = 0; i < 60; i++) {
      particles.push(createParticle(width * 0.2, height, true));
      particles.push(createParticle(width * 0.8, height, true));
      particles.push(createParticle(width * 0.5, height * 0.6, true));
    }

    // Continuous trickle of gentle gold glitter falling from the top
    const trickleInterval = setInterval(() => {
      if (particles.length < 150) {
        particles.push({
          x: Math.random() * width,
          y: -10,
          vx: (Math.random() - 0.5) * 1.5,
          vy: Math.random() * 2 + 1.5,
          size: Math.random() * 4 + 2,
          color: goldPalette[Math.floor(Math.random() * goldPalette.length)],
          rotation: Math.random() * Math.PI * 2,
          rotationSpeed: (Math.random() - 0.5) * 0.1,
          shape: "star",
          opacity: Math.random() * 0.5 + 0.5,
        });
      }
    }, 60);

    const drawStar = (cx: number, cy: number, spikes: number, outerRadius: number, innerRadius: number, fillStyle: string) => {
      if (!ctx) return;
      let rot = (Math.PI / 2) * 3;
      let x = cx;
      let y = cy;
      const step = Math.PI / spikes;

      ctx.beginPath();
      ctx.moveTo(cx, cy - outerRadius);
      for (let i = 0; i < spikes; i++) {
        x = cx + Math.cos(rot) * outerRadius;
        y = cy + Math.sin(rot) * outerRadius;
        ctx.lineTo(x, y);
        rot += step;

        x = cx + Math.cos(rot) * innerRadius;
        y = cy + Math.sin(rot) * innerRadius;
        ctx.lineTo(x, y);
        rot += step;
      }
      ctx.lineTo(cx, cy - outerRadius);
      ctx.closePath();
      ctx.fillStyle = fillStyle;
      ctx.fill();
    };

    const updateAndDraw = () => {
      ctx.clearRect(0, 0, width, height);

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];

        // Physics updates
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.12; // Gravity
        p.vx *= 0.98; // Air resistance
        p.rotation += p.rotationSpeed;

        // Fade out as they fall or age
        if (p.y > height) {
          p.opacity -= 0.05;
        } else {
          p.opacity -= 0.004; // Gentle lifetime fade
        }

        if (p.opacity <= 0) {
          particles.splice(i, 1);
          continue;
        }

        // Draw particle
        ctx.save();
        ctx.globalAlpha = p.opacity;
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);

        ctx.fillStyle = p.color;

        if (p.shape === "circle") {
          ctx.beginPath();
          ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.shape === "square") {
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        } else if (p.shape === "triangle") {
          ctx.beginPath();
          ctx.moveTo(0, -p.size / 2);
          ctx.lineTo(p.size / 2, p.size / 2);
          ctx.lineTo(-p.size / 2, p.size / 2);
          ctx.closePath();
          ctx.fill();
        } else if (p.shape === "star") {
          ctx.restore();
          ctx.save();
          ctx.globalAlpha = p.opacity;
          drawStar(p.x, p.y, 5, p.size, p.size / 2, p.color);
        }

        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(updateAndDraw);
    };

    updateAndDraw();

    return () => {
      cancelAnimationFrame(animationFrameId);
      clearInterval(trickleInterval);
      window.removeEventListener("resize", handleResize);
    };
  }, [milestone]);

  if (!milestone) return null;

  const MilestoneIcon = milestone.icon || Trophy;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-hidden">
        {/* Deep Ambient Golden Glow Overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-[#0c0a05]/90 backdrop-blur-md cursor-pointer transition-all duration-700"
        />

        {/* Real-time High Performance Canvas Emitter */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 pointer-events-none z-10 w-full h-full"
        />

        {/* Celebratory Content Card */}
        <motion.div
          id="milestone-celebration-card"
          initial={{ opacity: 0, scale: 0.85, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ type: "spring", damping: 25, stiffness: 120 }}
          className="relative bg-white border border-[#2d7a64]/50 max-w-lg w-full p-8 md:p-10 text-center space-y-8 z-20 shadow-[0_0_80px_rgba(197,168,128,0.25)] rounded-sm overflow-hidden"
        >
          {/* Subtle Golden Ray/Conic Background Glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-radial from-[#2d7a64]/12 to-transparent rounded-full pointer-events-none blur-3xl" />

          {/* Golden Corner Accents to emphasize Swiss / Modern Craftsmanship */}
          <div className="absolute top-4 left-4 w-6 h-6 border-t border-l border-[#2d7a64]/40 pointer-events-none" />
          <div className="absolute top-4 right-4 w-6 h-6 border-t border-r border-[#2d7a64]/40 pointer-events-none" />
          <div className="absolute bottom-4 left-4 w-6 h-6 border-b border-l border-[#2d7a64]/40 pointer-events-none" />
          <div className="absolute bottom-4 right-4 w-6 h-6 border-b border-r border-[#2d7a64]/40 pointer-events-none" />

          <div className="space-y-4">
            {/* Crown or Scholar Label */}
            <div className="flex items-center justify-center gap-1 text-[#2d7a64] font-mono text-[9px] uppercase tracking-[0.3em] font-bold">
              <Crown className="w-3.5 h-3.5 text-[#2d7a64]" />
              <span>Academic Distinction Bestowed</span>
            </div>

            {/* Glowing Icon Roundel */}
            <div className="flex justify-center pt-2">
              <motion.div
                initial={{ rotate: -15, scale: 0.5 }}
                animate={{ rotate: 0, scale: 1 }}
                transition={{ type: "spring", delay: 0.2, damping: 12 }}
                className="w-24 h-24 rounded-full bg-gradient-to-b from-[#f3f7f5] to-[#e8f0eb] border-2 border-[#2d7a64] flex items-center justify-center relative shadow-[0_0_30px_rgba(197,168,128,0.3)] group"
              >
                {/* Embedded animated ring */}
                <div className="absolute inset-0 rounded-full border border-dashed border-[#2d7a64]/40 animate-spin [animation-duration:20s]" />
                
                <MilestoneIcon
                  className="w-11 h-11 transition-transform duration-500 group-hover:scale-110"
                  style={{ color: "#2d7a64" }}
                />
              </motion.div>
            </div>
          </div>

          <div className="space-y-3">
            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="font-sans font-semibold tracking-tight text-3xl font-bold text-[#0f241d] tracking-tight leading-tight"
            >
              {milestone.title}
            </motion.h2>
            
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-xs text-[#0f241d60] leading-relaxed max-w-sm mx-auto font-sans font-semibold tracking-tight"
            >
              "{milestone.description}"
            </motion.p>
          </div>

          {/* Premium Reward Block */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            className="bg-[#f3f7f5] border border-[#2d7a64]/20 p-4 max-w-xs mx-auto flex items-center justify-around rounded-xs"
          >
            <div className="text-center">
              <span className="text-[9px] font-mono text-[#0f241d40] uppercase tracking-wider block">Bonus Reward</span>
              <span className="text-lg font-mono font-bold text-[#2d7a64]">+100 XP</span>
            </div>
            <div className="h-8 w-px bg-[#0f241d10]" />
            <div className="text-center">
              <span className="text-[9px] font-mono text-[#0f241d40] uppercase tracking-wider block">Scholar Status</span>
              <span className="text-xs font-mono font-bold text-[#0f241d] uppercase tracking-wider">Ascended</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="pt-2"
          >
            <button
              id="claim-honors-btn"
              onClick={onClose}
              className="w-full bg-[#0f241d] hover:bg-[#2d7a64] hover:text-[#0f241d] text-white border border-[#0f241d] hover:border-[#2d7a64] py-4 text-xs font-mono uppercase tracking-widest font-semibold transition-all duration-300 cursor-pointer shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]"
            >
              Claim Scholar Honors &rarr;
            </button>
          </motion.div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
