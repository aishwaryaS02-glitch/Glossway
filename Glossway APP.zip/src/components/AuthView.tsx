import { useState } from "react";
import { auth, db } from "../firebase";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail,
} from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { Sparkles, Mail, Lock, User, ArrowLeft, CheckCircle } from "lucide-react";

export default function AuthView() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (isForgotPassword) {
        if (!email.trim()) {
          throw new Error("Please enter your email address");
        }
        await sendPasswordResetEmail(auth, email);
        setResetSent(true);
      } else if (isSignUp) {
        if (!displayName.trim()) {
          throw new Error("Please enter your name");
        }
        // Sign up
        const userCredential = await createUserWithEmailAndPassword(
          auth,
          email,
          password
        );
        const user = userCredential.user;

        // Update profile
        await updateProfile(user, {
          displayName: displayName,
        });

        // Initialize user record in Firestore
        const userProfile = {
          uid: user.uid,
          email: user.email,
          displayName: displayName,
          createdAt: Date.now(),
          streak: 1, // Start with streak of 1!
          lastActiveDate: new Date().toISOString().split("T")[0],
          wordsLearned: 0,
          sessions: 0,
          level: 1,
          xp: 0,
          languages: {
            spanish: {
              name: "Spanish",
              levelName: "Intermediate",
              progress: 78,
              speaking: 65,
              grammar: 82,
            },
            japanese: {
              name: "Japanese",
              levelName: "Beginner",
              progress: 32,
            },
          },
        };

        await setDoc(doc(db, "users", user.uid), userProfile);
      } else {
        // Sign in
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to authenticate");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f3f7f5] flex flex-col items-center justify-center p-6 font-sans text-[#0f241d]">
      {/* Branding */}
      <div className="mb-10 text-center flex flex-col items-center gap-1.5">
        <div className="w-12 h-12 border border-[#0f241d15] bg-[#e8f0eb] flex items-center justify-center text-[#0f241d] mb-3">
          <Sparkles className="w-5 h-5 text-[#2d7a64]" />
        </div>
        <h1 className="font-sans font-semibold tracking-tight text-4xl font-semibold text-[#0f241d] tracking-tight">
          Glossway
        </h1>
        <span className="text-[9px] font-mono tracking-[0.25em] uppercase text-[#0f241d60] mt-0.5">
          Your path to language fluency
        </span>
      </div>

      {/* Auth Card */}
      <div className="w-full max-w-md bg-white p-8 border border-[#0f241d15]">
        {isForgotPassword ? (
          resetSent ? (
            <div className="space-y-6 text-center animate-fade-in">
              <div className="w-12 h-12 bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto text-emerald-600">
                <CheckCircle className="w-6 h-6" />
              </div>
              <div className="space-y-2">
                <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d]">
                  Check Your Inbox
                </h2>
                <p className="text-xs text-[#0f241d60] leading-relaxed">
                  We have sent a secure password reset link to <strong className="text-[#0f241d]">{email}</strong>. Please follow the instructions in the email to restore your access.
                </p>
              </div>
              <button
                onClick={() => {
                  setIsForgotPassword(false);
                  setResetSent(false);
                  setError("");
                }}
                className="w-full bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest py-3.5 border border-[#0f241d] transition-colors cursor-pointer"
              >
                Back to Sign In
              </button>
            </div>
          ) : (
            <div className="space-y-6 animate-fade-in">
              <div className="text-center">
                <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d]">
                  Reset Password
                </h2>
                <p className="text-xs text-[#0f241d60] mt-1.5 leading-relaxed">
                  Enter your email address below, and we will send you a secure link to reset your password.
                </p>
              </div>

              {error && (
                <div className="p-3 border border-red-200 bg-red-50 text-red-700 text-xs font-mono uppercase tracking-wider">
                  {error}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-semibold text-[#0f241d60] uppercase tracking-widest block pl-0.5">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0f241d40]" />
                    <input
                      type="email"
                      required
                      placeholder="alex@glossway.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#f3f7f5] border border-[#0f241d15] py-2.5 pl-10 pr-4 text-xs font-mono uppercase tracking-wider text-[#0f241d] outline-none transition-all focus:border-[#0f241d] placeholder:text-[#0f241d30]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest py-3.5 border border-[#0f241d] transition-colors disabled:opacity-50 cursor-pointer"
                >
                  {loading ? "Sending..." : "Send Reset Link"}
                </button>
              </form>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsForgotPassword(false);
                    setError("");
                  }}
                  className="text-xs font-mono uppercase tracking-wider text-[#0f241d60] hover:text-[#0f241d] hover:underline flex items-center justify-center gap-1.5 mx-auto"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Cancel and Sign In
                </button>
              </div>
            </div>
          )
        ) : (
          <>
            <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-center mb-6 text-[#0f241d]">
              {isSignUp ? "Create an Account" : "Welcome Back"}
            </h2>

            {error && (
              <div className="mb-6 p-4 border border-red-200 bg-red-50 text-red-700 text-xs font-mono uppercase tracking-wider">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {isSignUp && (
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono font-semibold text-[#0f241d60] uppercase tracking-widest block pl-0.5">
                    Name
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0f241d40]" />
                    <input
                      type="text"
                      required
                      placeholder="Alex Rivera"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="w-full bg-[#f3f7f5] border border-[#0f241d15] py-2.5 pl-10 pr-4 text-xs font-mono uppercase tracking-wider text-[#0f241d] outline-none transition-all focus:border-[#0f241d] placeholder:text-[#0f241d30]"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-semibold text-[#0f241d60] uppercase tracking-widest block pl-0.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0f241d40]" />
                  <input
                    type="email"
                    required
                    placeholder="alex@glossway.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#f3f7f5] border border-[#0f241d15] py-2.5 pl-10 pr-4 text-xs font-mono uppercase tracking-wider text-[#0f241d] outline-none transition-all focus:border-[#0f241d] placeholder:text-[#0f241d30]"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between items-center pl-0.5">
                  <label className="text-[10px] font-mono font-semibold text-[#0f241d60] uppercase tracking-widest block">
                    Password
                  </label>
                  {!isSignUp && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsForgotPassword(true);
                        setError("");
                      }}
                      className="text-[9px] font-mono uppercase tracking-widest text-[#2d7a64] hover:text-[#0f241d] hover:underline"
                    >
                      Forgot Password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0f241d40]" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-[#f3f7f5] border border-[#0f241d15] py-2.5 pl-10 pr-4 text-xs font-mono uppercase tracking-wider text-[#0f241d] outline-none transition-all focus:border-[#0f241d] placeholder:text-[#0f241d30]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest py-3.5 border border-[#0f241d] transition-colors disabled:opacity-50 mt-6 cursor-pointer"
              >
                {loading ? "Processing..." : isSignUp ? "Sign Up" : "Sign In"}
              </button>
            </form>

            <div className="mt-8 text-center">
              <button
                type="button"
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-xs font-mono uppercase tracking-wider text-[#0f241d60] hover:text-[#0f241d] hover:underline"
              >
                {isSignUp
                  ? "Already have an account? Sign In"
                  : "Don't have an account? Sign Up"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
