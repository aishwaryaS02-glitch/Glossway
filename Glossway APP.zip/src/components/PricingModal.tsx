import { useState } from "react";
import { UserProfile } from "../types";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";
import {
  CreditCard,
  Check,
  Sparkles,
  Smartphone,
  ShieldCheck,
  Building,
  Globe,
} from "lucide-react";

interface PricingModalProps {
  userProfile: UserProfile | null;
  onUpdateUserProfile: (updates: Partial<UserProfile>) => void;
  onClose: () => void;
  showToast: (msg: string) => void;
}

interface Plan {
  id: string;
  name: string;
  priceINR: string;
  priceUSD: string;
  period: string;
  features: string[];
  recommended?: boolean;
}

const DYNAMIC_PLANS: Plan[] = [
  {
    id: "beginner",
    name: "Beginner",
    priceINR: "₹50",
    priceUSD: "$0.99",
    period: "10 Days Free, then ₹50",
    features: [
      "Access to Beginner Words & Meanings",
      "Standard parts of speech & noun/pronoun classifications",
      "Pronunciation audio guide",
    ],
  },
  {
    id: "middleware",
    name: "Middleware",
    priceINR: "₹200",
    priceUSD: "$2.99",
    period: "lifetime",
    features: [
      "Everything in Beginner + sentence framing",
      "Interactive multiple-word contextual dialogues",
      "Daily Quiz Streak Challenge",
    ],
  },
  {
    id: "pro",
    name: "Pro Level",
    priceINR: "₹400",
    priceUSD: "$4.99",
    period: "lifetime",
    recommended: true,
    features: [
      "Unrestricted access to all 10 Languages",
      "Advanced sentence framing & complex conjugations",
      "Unlimited AI Chat Tutor conversations",
    ],
  },
];

export default function PricingModal({
  userProfile,
  onUpdateUserProfile,
  onClose,
  showToast,
}: PricingModalProps) {
  const [currency, setCurrency] = useState<"INR" | "USD">("INR");
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [step, setStep] = useState<"plans" | "checkout" | "success">("plans");
  const [paymentMethod, setPaymentMethod] = useState<"upi" | "card" | "netbanking">("upi");
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [selectedBank, setSelectedBank] = useState("");
  const [processing, setProcessing] = useState(false);

  const handleSelectPlan = (plan: Plan) => {
    setSelectedPlan(plan);
    
    if (userProfile?.email === "aishwaryakumar020406@gmail.com") {
      showToast("Free access granted for Admin!");
      onUpdateUserProfile({
        premium: true,
        planId: plan.id,
      });
      setStep("success");
      return;
    }

    // Auto-detect payment portal based on currency
    if (currency === "USD") {
      setPaymentMethod("card"); // Force card payment for USD
    } else {
      setPaymentMethod("upi");
    }
    setStep("checkout");
  };

  const handleProcessPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);

    const priceLabel = currency === "INR" ? selectedPlan?.priceINR : selectedPlan?.priceUSD;

    // Simulate network delay for verification and processing
    setTimeout(async () => {
      try {
        if (userProfile?.uid) {
          const userDocRef = doc(db, "users", userProfile.uid);
          await updateDoc(userDocRef, {
            premium: true,
            planId: selectedPlan?.id,
            wordsLearned: (userProfile.wordsLearned || 0) + 150, // Bonus XP/words for subscribing!
            xp: (userProfile.xp || 0) + 500,
          });

          onUpdateUserProfile({
            ...userProfile,
            premium: true,
            planId: selectedPlan?.id,
            wordsLearned: (userProfile.wordsLearned || 0) + 150,
            xp: (userProfile.xp || 0) + 500,
          } as any);
        }

        setStep("success");
        showToast(`Payment of ${priceLabel} processed successfully! Enjoy Pro Access.`);
      } catch (err) {
        console.error("Failed to save premium status:", err);
        showToast("Payment processed, but failed to sync premium status online.");
      } finally {
        setProcessing(false);
      }
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-[#0f241d70] backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in font-sans">
      <div className="bg-white border border-[#0f241d] max-w-4xl w-full p-8 md:p-10 space-y-6 max-h-[90vh] overflow-y-auto shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-6 right-6 font-mono text-xs uppercase tracking-widest hover:text-red-600 transition-colors cursor-pointer text-[#0f241d60]"
        >
          [ Close ]
        </button>

        {/* STEP 1: PLANS OVERVIEW */}
        {step === "plans" && (
          <div className="space-y-8">
            <div className="text-center space-y-3">
              <div className="inline-flex items-center gap-2 text-[#2d7a64] mx-auto bg-[#f3f7f5] border border-[#0f241d10] px-4 py-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-bold">
                  Glossway Bread Plans
                </span>
              </div>
              <h2 className="font-sans font-semibold tracking-tight font-medium text-3xl text-[#0f241d] leading-tight">
                Unlock Your Fluency Tier
              </h2>
              <p className="text-xs text-[#0f241d50] max-w-lg mx-auto">
                Study vocabulary, practice pronunciation, watch video guides, and utilize AI tutors. Unlocked tiers align to your goals.
              </p>

              {/* Currency Toggle Switch */}
              <div className="flex items-center justify-center gap-3 pt-3">
                <span className={`text-[10px] font-mono uppercase tracking-wider ${currency === "INR" ? "text-[#0f241d] font-bold" : "text-[#0f241d50]"}`}>
                  Indian Rupee (₹)
                </span>
                <button
                  onClick={() => setCurrency(currency === "INR" ? "USD" : "INR")}
                  className="w-12 h-6 rounded-full bg-[#0f241d15] p-0.5 transition-colors duration-200 relative focus:outline-hidden"
                  aria-label="Toggle Currency"
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-[#0f241d] shadow-md transform transition-transform duration-200 ${
                      currency === "USD" ? "translate-x-6" : "translate-x-0"
                    }`}
                  />
                </button>
                <span className={`text-[10px] font-mono uppercase tracking-wider ${currency === "USD" ? "text-[#0f241d] font-bold" : "text-[#0f241d50]"}`}>
                  US Dollar ($)
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
              {DYNAMIC_PLANS.map((plan) => {
                const priceText = currency === "INR" ? plan.priceINR : plan.priceUSD;

                return (
                  <div
                    key={plan.id}
                    className={`border p-6 flex flex-col justify-between space-y-6 relative transition-all ${
                      plan.recommended
                        ? "border-[#0f241d] bg-[#f3f7f5] shadow-md border-t-4 border-t-[#2d7a64]"
                        : "border-[#0f241d15] bg-white hover:border-[#0f241d]"
                    }`}
                  >
                    {plan.recommended && (
                      <span className="absolute -top-3 left-4 bg-[#2d7a64] text-white text-[8px] font-mono uppercase tracking-widest px-2.5 py-1 font-bold">
                        Best Value
                      </span>
                    )}

                    <div className="space-y-4">
                      <div>
                        <h3 className="font-sans font-semibold tracking-tight font-bold text-lg text-[#0f241d]">
                          {plan.name}
                        </h3>
                        <div className="flex items-baseline gap-1 mt-2">
                          <span className="font-mono text-3xl font-bold text-[#0f241d]">
                            {priceText}
                          </span>
                          <span className="font-mono text-[10px] text-[#0f241d50] uppercase">
                            / {plan.period}
                          </span>
                        </div>
                      </div>

                      <ul className="space-y-2.5 pt-4 border-t border-[#0f241d08]">
                        {plan.features.map((feat, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-xs text-[#0f241d70]">
                            <Check className="w-3.5 h-3.5 text-[#2d7a64] shrink-0 mt-0.5" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <button
                      onClick={() => handleSelectPlan(plan)}
                      className={`w-full py-2.5 text-xs font-mono uppercase tracking-widest transition-all cursor-pointer border ${
                        plan.recommended
                          ? "bg-[#0f241d] text-white border-[#0f241d] hover:bg-neutral-800"
                          : "bg-white text-[#0f241d] border-[#0f241d20] hover:border-[#0f241d]"
                      }`}
                    >
                      {plan.id === "beginner_free" ? "Free Access" : "Upgrade Now"}
                    </button>
                  </div>
                );
              })}
            </div>

            <div className="text-center pt-4 border-t border-[#0f241d10]">
              <p className="text-[10px] font-mono text-[#0f241d50] uppercase tracking-wider flex items-center justify-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" /> Secure checkout. Unsubscribe or switch tiers anytime in App Settings.
              </p>
            </div>
          </div>
        )}

        {/* STEP 2: CHECKOUT */}
        {step === "checkout" && selectedPlan && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left: Summary */}
            <div className="lg:col-span-5 bg-[#f3f7f5] border border-[#0f241d08] p-6 space-y-6">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#0f241d50] block">
                Order Summary
              </span>
              <div className="space-y-4">
                <div>
                  <h3 className="font-sans font-semibold tracking-tight font-semibold text-lg text-[#0f241d]">
                    {selectedPlan.name}
                  </h3>
                  <span className="text-[10px] font-mono text-[#0f241d40] uppercase block">
                    Access tier validation
                  </span>
                </div>

                <div className="space-y-2 pt-4 border-t border-[#0f241d10]">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-[#0f241d60]">Subtotal:</span>
                    <span className="font-bold">{currency === "INR" ? selectedPlan.priceINR : selectedPlan.priceUSD}</span>
                  </div>
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-[#0f241d60]">Taxes & Fees:</span>
                    <span className="font-bold text-emerald-600">0.00 (Inclusive)</span>
                  </div>
                  <div className="flex justify-between text-sm font-mono pt-2 border-t border-dashed border-[#0f241d15]">
                    <span className="text-[#0f241d] font-semibold">Total Amount:</span>
                    <span className="font-bold text-[#2d7a64]">{currency === "INR" ? selectedPlan.priceINR : selectedPlan.priceUSD}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-white border border-[#0f241d10] space-y-2 pt-3">
                <span className="text-[9px] font-mono text-emerald-700 uppercase font-bold flex items-center gap-1">
                  ★ Subscriber Perks
                </span>
                <p className="text-[10px] text-[#0f241d60] leading-relaxed">
                  Earn an immediate <strong className="text-[#0f241d]">500 XP</strong> and <strong className="text-[#0f241d]">150 words</strong> added to your profile stats as a welcome package!
                </p>
              </div>
            </div>

            {/* Right: Payment Forms */}
            <form onSubmit={handleProcessPayment} className="lg:col-span-7 space-y-6">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#0f241d50] block">
                Choose Payment Portal ({currency === "INR" ? "INR Gateway" : "International Card Gateway"})
              </span>

              {/* Payment Methods Tab */}
              {currency === "INR" ? (
                <div className="grid grid-cols-3 gap-2 bg-[#e8f0eb] p-1 border border-[#0f241d10]">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod("upi")}
                    className={`py-2 text-center text-[9px] font-mono uppercase tracking-wider cursor-pointer transition-colors ${
                      paymentMethod === "upi"
                        ? "bg-white text-[#0f241d] font-bold shadow-xs"
                        : "text-[#0f241d50]"
                    }`}
                  >
                    UPI (GPay/UPI)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod("card")}
                    className={`py-2 text-center text-[9px] font-mono uppercase tracking-wider cursor-pointer transition-colors ${
                      paymentMethod === "card"
                        ? "bg-white text-[#0f241d] font-bold shadow-xs"
                        : "text-[#0f241d50]"
                    }`}
                  >
                    Debit/Credit Card
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod("netbanking")}
                    className={`py-2 text-center text-[9px] font-mono uppercase tracking-wider cursor-pointer transition-colors ${
                      paymentMethod === "netbanking"
                        ? "bg-white text-[#0f241d] font-bold shadow-xs"
                        : "text-[#0f241d50]"
                    }`}
                  >
                    Net Banking
                  </button>
                </div>
              ) : (
                <div className="p-3 bg-[#f3f7f5] border border-[#0f241d10] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-[#2d7a64]" />
                    <span className="text-[10px] font-mono uppercase tracking-wider font-bold">International Visa / Mastercard</span>
                  </div>
                  <span className="text-[9px] font-mono text-[#0f241d40] uppercase">Card Gateway Active</span>
                </div>
              )}

              {/* UPI INPUTS */}
              {currency === "INR" && paymentMethod === "upi" && (
                <div className="space-y-4 p-4 bg-[#f3f7f5] border border-[#0f241d08] flex flex-col items-center text-center">
                  <div className="flex items-center justify-center gap-2 text-[#2d7a64] w-full pb-2 border-b border-[#0f241d10]">
                    <Smartphone className="w-4 h-4" />
                    <span className="text-[9px] font-mono uppercase tracking-wider font-bold">BHIM UPI / Google Pay / PhonePe</span>
                  </div>
                  <div className="p-2 bg-white border border-[#0f241d15] shadow-xs">
                    <img src="/scanner.jpg" alt="UPI QR Scanner" className="w-48 h-48 object-cover mx-auto" onError={(e) => { e.currentTarget.src = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=dummy@upi&pn=Admin'; e.currentTarget.alt = 'Placeholder Scanner'; }} />
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-mono uppercase font-bold text-[#0f241d]">Scan & Pay {selectedPlan.priceINR}</p>
                    <p className="text-[9px] text-[#0f241d50] leading-relaxed">
                      Please scan this QR code directly with your PhonePe or any UPI app to attach it to the bank. 
                      After successful payment, click "Confirm Payment" below.
                    </p>
                  </div>
                </div>
              )}

              {/* CARD INPUTS */}
              {(currency === "USD" || paymentMethod === "card") && (
                <div className="space-y-4 p-4 bg-[#f3f7f5] border border-[#0f241d08]">
                  <div className="flex items-center gap-2 text-[#2d7a64]">
                    <CreditCard className="w-4 h-4" />
                    <span className="text-[9px] font-mono uppercase tracking-wider font-bold">Card Details</span>
                  </div>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-mono uppercase text-[#0f241d60] block">
                        Card Number
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={19}
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        placeholder="4111 2222 3333 4444"
                        className="w-full bg-white border border-[#0f241d15] px-3 py-2.5 text-xs font-mono outline-hidden focus:border-[#0f241d]"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-mono uppercase text-[#0f241d60] block">
                          Expiry Date
                        </label>
                        <input
                          type="text"
                          required
                          maxLength={5}
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          placeholder="MM/YY"
                          className="w-full bg-white border border-[#0f241d15] px-3 py-2.5 text-xs font-mono outline-hidden focus:border-[#0f241d]"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-mono uppercase text-[#0f241d60] block">
                          CVV Code
                        </label>
                        <input
                          type="password"
                          required
                          maxLength={3}
                          value={cardCvv}
                          onChange={(e) => setCardCvv(e.target.value)}
                          placeholder="•••"
                          className="w-full bg-white border border-[#0f241d15] px-3 py-2.5 text-xs font-mono outline-hidden focus:border-[#0f241d]"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* NET BANKING INPUTS */}
              {currency === "INR" && paymentMethod === "netbanking" && (
                <div className="space-y-4 p-4 bg-[#f3f7f5] border border-[#0f241d08]">
                  <div className="flex items-center gap-2 text-[#2d7a64]">
                    <Building className="w-4 h-4" />
                    <span className="text-[9px] font-mono uppercase tracking-wider font-bold">Select Indian Bank</span>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono uppercase text-[#0f241d60] block">
                      Choose Your Banking Institution
                    </label>
                    <select
                      required
                      value={selectedBank}
                      onChange={(e) => setSelectedBank(e.target.value)}
                      className="w-full bg-white border border-[#0f241d15] px-3 py-2.5 text-xs font-mono outline-hidden focus:border-[#0f241d]"
                    >
                      <option value="">-- Select Bank --</option>
                      <option value="sbi">State Bank of India (SBI)</option>
                      <option value="hdfc">HDFC Bank</option>
                      <option value="icici">ICICI Bank</option>
                      <option value="axis">Axis Bank</option>
                      <option value="pnb">Punjab National Bank</option>
                      <option value="kotak">Kotak Mahindra Bank</option>
                    </select>
                  </div>
                </div>
              )}

              <div className="flex gap-3 pt-4 border-t border-[#0f241d10]">
                <button
                  type="button"
                  onClick={() => setStep("plans")}
                  className="flex-1 bg-[#f3f7f5] hover:bg-[#e8f0eb] border border-[#0f241d15] hover:border-[#0f241d] text-[#0f241d] py-3 text-xs font-mono uppercase tracking-widest cursor-pointer transition-colors"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={processing}
                  className="flex-1 bg-[#0f241d] hover:bg-neutral-800 text-white py-3 text-xs font-mono uppercase tracking-widest cursor-pointer transition-colors disabled:opacity-50"
                >
                  {processing ? "Validating Securely..." : (currency === "INR" && paymentMethod === "upi") ? `Confirm Payment of ${selectedPlan.priceINR}` : `Pay ${currency === "INR" ? selectedPlan.priceINR : selectedPlan.priceUSD}`}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* STEP 3: SUCCESS CELEBRATION */}
        {step === "success" && selectedPlan && (
          <div className="text-center py-12 space-y-6">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>

            <div className="space-y-2">
              <span className="text-[10px] font-mono uppercase text-[#2d7a64] tracking-[0.25em] font-bold block">
                Payment Completed Successfully
              </span>
              <h3 className="font-sans font-semibold tracking-tight font-medium text-3xl text-[#0f241d]">
                Fluency Tier Activated
              </h3>
              <p className="text-xs text-[#0f241d50] max-w-md mx-auto leading-relaxed font-sans font-semibold tracking-tight">
                Your payment for <strong className="text-black">{selectedPlan.name}</strong> was validated. We added <strong className="text-black">+500 XP</strong> and <strong className="text-black">+150 words</strong> learned to your dashboard stats!
              </p>
            </div>

            <div className="bg-[#f3f7f5] p-4 max-w-sm mx-auto border border-[#0f241d08] text-xs font-mono">
              <div className="flex justify-between py-1 text-[#0f241d60]">
                <span>Transaction Ref:</span>
                <span className="font-bold uppercase text-black">GLS-{Math.floor(Math.random() * 900000 + 100000)}</span>
              </div>
              <div className="flex justify-between py-1 text-[#0f241d60]">
                <span>Amount Charged:</span>
                <span className="font-bold text-black">{currency === "INR" ? selectedPlan.priceINR : selectedPlan.priceUSD}</span>
              </div>
              <div className="flex justify-between py-1 text-[#0f241d60]">
                <span>Status:</span>
                <span className="font-bold text-emerald-600 uppercase">Active • Tier Unlocked</span>
              </div>
            </div>

            <div className="pt-6">
              <button
                onClick={onClose}
                className="bg-[#0f241d] hover:bg-neutral-800 text-white px-8 py-3 text-xs font-mono uppercase tracking-widest cursor-pointer transition-colors"
              >
                Launch Tier Experience
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
