import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { UserProfile } from "../types";
import { MULTILINGUAL_DATA } from "../data/multilingualHubData";
import {
  Layers,
  Sparkles,
  Eye,
  Check,
  FastForward,
} from "lucide-react";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";

interface SrsItem {
  id: string;
  text: string;
  translation: string;
  pronunciation: string;
  languageName: string;
  box: number; // 1 to 5
  nextReview: number; // timestamp ms
  lastReviewed?: number; // timestamp ms
}

interface SrsReviewDashboardProps {
  userProfile: UserProfile | null;
  onUpdateUserProfile: (updates: Partial<UserProfile>) => void;
}

const BOX_INTERVALS_MS = [
  0, // unused index
  4 * 60 * 60 * 1000, // Box 1: 4 hours
  24 * 60 * 60 * 1000, // Box 2: 1 day
  3 * 24 * 60 * 60 * 1000, // Box 3: 3 days
  7 * 24 * 60 * 60 * 1000, // Box 4: 7 days
  14 * 24 * 60 * 60 * 1000, // Box 5: 14 days
];

const BOX_NAMES = [
  "",
  "Active Learning",
  "Familiar Recall",
  "Retained",
  "Mastered",
  "Archived / Long-Term",
];

const BOX_COLORS = [
  "",
  "bg-rose-500",
  "bg-amber-500",
  "bg-emerald-500",
  "bg-emerald-500",
  "bg-purple-500",
];

export default function SrsReviewDashboard({
  userProfile,
  onUpdateUserProfile,
}: SrsReviewDashboardProps) {
  const [srsItems, setSrsItems] = useState<SrsItem[]>([]);
  const [activeReviewItem, setActiveReviewItem] = useState<SrsItem | null>(null);
  const [revealAnswer, setRevealAnswer] = useState(false);
  const [reviewSuccessMsg, setReviewSuccessMsg] = useState<string | null>(null);
  const [xpGranted, setXpGranted] = useState(0);

  // Load and synchronize SRS items from local storage & marked words
  useEffect(() => {
    // 1. Check if there's already SRS data
    let storedSrs: SrsItem[] = [];
    try {
      const saved = localStorage.getItem("glossway_srs_reviews");
      if (saved) {
        storedSrs = JSON.parse(saved);
      }
    } catch (e) {
      console.error("Failed to parse stored SRS records:", e);
    }

    // 2. Load current marked learned words
    let learnedKeys: Record<string, boolean> = {};
    try {
      const saved = localStorage.getItem("glossway_marked_learned_words");
      if (saved) {
        learnedKeys = JSON.parse(saved);
      }
    } catch (e) {
      console.error("Failed to parse marked learned words:", e);
    }

    const updatedSrs: SrsItem[] = [...storedSrs];
    let itemsAdded = false;

    // 3. Sync any newly marked words that don't exist in our SRS array yet
    MULTILINGUAL_DATA.forEach((lang) => {
      // Beginner Words
      lang.beginner.forEach((vocab, idx) => {
        const key = `${lang.id}_beg_${idx}`;
        if (learnedKeys[key] && !updatedSrs.some((item) => item.id === key)) {
          updatedSrs.push({
            id: key,
            text: vocab.word,
            translation: vocab.translation,
            pronunciation: vocab.pronunciation,
            languageName: lang.name,
            box: 1,
            nextReview: Date.now(), // Due immediately
          });
          itemsAdded = true;
        }
      });

      // Middleware Phrases
      lang.middleware.forEach((phrase, idx) => {
        const key = `${lang.id}_mid_${idx}`;
        if (learnedKeys[key] && !updatedSrs.some((item) => item.id === key)) {
          updatedSrs.push({
            id: key,
            text: phrase.phrase,
            translation: phrase.translation,
            pronunciation: phrase.pronunciation,
            languageName: lang.name,
            box: 1,
            nextReview: Date.now(),
          });
          itemsAdded = true;
        }
      });
    });

    // 4. Seed fallback items if everything is empty to ensure user has a live playground immediately!
    if (updatedSrs.length === 0) {
      // Seed some standard Kannada / Spanish / French words
      const defaultLanguage = MULTILINGUAL_DATA[0]; // Kannada
      const fallbackVocabs = defaultLanguage.beginner.slice(0, 3);
      fallbackVocabs.forEach((vocab, idx) => {
        const key = `${defaultLanguage.id}_beg_${idx}`;
        updatedSrs.push({
          id: key,
          text: vocab.word,
          translation: vocab.translation,
          pronunciation: vocab.pronunciation,
          languageName: defaultLanguage.name,
          box: 1,
          nextReview: Date.now(),
        });
      });
      itemsAdded = true;
    }

    if (itemsAdded || storedSrs.length === 0) {
      localStorage.setItem("glossway_srs_reviews", JSON.stringify(updatedSrs));
    }
    setSrsItems(updatedSrs);
  }, []);

  // Save changes helper
  const saveSrsItems = (items: SrsItem[]) => {
    setSrsItems(items);
    localStorage.setItem("glossway_srs_reviews", JSON.stringify(items));
  };

  // Calculate stats
  const now = Date.now();
  const dueItems = srsItems.filter((item) => item.nextReview <= now);

  const boxCounts = [0, 0, 0, 0, 0, 0]; // Box 1 to 5
  srsItems.forEach((item) => {
    if (item.box >= 1 && item.box <= 5) {
      boxCounts[item.box] += 1;
    }
  });

  const totalCards = srsItems.length;

  // Handle flashcard recall scoring
  const handleReviewScore = async (remembered: boolean) => {
    if (!activeReviewItem) return;

    let newBox = activeReviewItem.box;
    if (remembered) {
      // Advance to next box
      newBox = Math.min(5, activeReviewItem.box + 1);
    } else {
      // Reset to Box 1 for reinforcement
      newBox = 1;
    }

    const interval = BOX_INTERVALS_MS[newBox];
    const updatedItem: SrsItem = {
      ...activeReviewItem,
      box: newBox,
      lastReviewed: Date.now(),
      nextReview: Date.now() + interval,
    };

    const newSrsItems = srsItems.map((item) =>
      item.id === activeReviewItem.id ? updatedItem : item
    );

    saveSrsItems(newSrsItems);

    // Grant small studying reward!
    const earnedXp = remembered ? 10 : 5;
    setXpGranted(earnedXp);
    setReviewSuccessMsg(
      remembered
        ? `Splendid recollection! Advanced to Box ${newBox} (${BOX_NAMES[newBox]})`
        : `No worries! Practice makes perfect. Card returned to Box 1`
    );

    if (userProfile) {
      const currentXp = userProfile.xp || 0;
      const newXp = currentXp + earnedXp;
      const newLevel = Math.floor(newXp / 100) + 1;
      onUpdateUserProfile({ xp: newXp, level: newLevel });

      if (userProfile.uid) {
        try {
          const userRef = doc(db, "users", userProfile.uid);
          await updateDoc(userRef, { xp: newXp, level: newLevel });
        } catch (e) {
          console.error("Failed to update Firestore SRS XP:", e);
        }
      }
    }

    setTimeout(() => {
      setReviewSuccessMsg(null);
      setRevealAnswer(false);
      // Auto-grab next due item if available
      const remainingDue = newSrsItems.filter((item) => item.nextReview <= Date.now());
      if (remainingDue.length > 0) {
        // Grab another one that is not the current one
        const nextOne = remainingDue.find((x) => x.id !== activeReviewItem.id) || remainingDue[0];
        setActiveReviewItem(nextOne);
      } else {
        setActiveReviewItem(null);
      }
    }, 2500);
  };

  // Simulation Cheat: Fast forward time to test SRS behavior!
  const handleFastForwardTime = (hours: number) => {
    const shiftMs = hours * 60 * 60 * 1000;
    const modified = srsItems.map((item) => ({
      ...item,
      nextReview: item.nextReview - shiftMs,
    }));
    saveSrsItems(modified);

    // Reset active review if needed to pick up newly due items
    setActiveReviewItem(null);
    setRevealAnswer(false);
  };

  // Start due review
  const handleStartReview = () => {
    if (dueItems.length > 0) {
      setActiveReviewItem(dueItems[0]);
      setRevealAnswer(false);
    }
  };

  return (
    <div className="bg-white border border-[#0f241d15] p-6 space-y-6">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-[#0f241d08]">
        <div>
          <div className="flex items-center gap-1.5 text-[#2d7a64]">
            <Layers className="w-4 h-4 animate-bounce" />
            <span className="text-[10px] font-mono uppercase tracking-[0.12em] font-semibold">
              Spaced Repetition Engine
            </span>
          </div>
          <h3 className="text-xl font-sans font-semibold tracking-tight font-medium text-[#0f241d]">
            Vocabulary Retention & SRS Matrix
          </h3>
          <p className="text-[10px] font-mono uppercase text-[#0f241d50] tracking-wider mt-0.5">
            Scientific retention tracking utilizing adaptive interval Leitner Boxes
          </p>
        </div>

        {/* TIME CONTROLS FOR TESTING */}
        <div className="flex items-center gap-2">
          <span className="text-[8px] font-mono text-[#0f241d40] uppercase">SRS Debug:</span>
          <button
            onClick={() => handleFastForwardTime(24)}
            className="px-2.5 py-1.5 border border-[#0f241d10] hover:border-black hover:bg-[#f3f7f5] text-[9px] font-mono uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-colors"
            title="Simulate 24 hours passing to make flashcards due for review"
          >
            <FastForward className="w-3 h-3 text-[#2d7a64]" /> +24 Hours
          </button>
          <button
            onClick={() => handleFastForwardTime(72)}
            className="px-2.5 py-1.5 border border-[#0f241d10] hover:border-black hover:bg-[#f3f7f5] text-[9px] font-mono uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-colors"
            title="Simulate 3 days passing"
          >
            <FastForward className="w-3 h-3 text-[#2d7a64]" /> +3 Days
          </button>
        </div>
      </div>

      {/* SRS VISUAL METRICS */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* LEFT CARD: LEITNER BOX MATRIX DISPLAY */}
        <div className="md:col-span-7 bg-[#f3f7f5] border border-[#0f241d05] p-5 space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-mono uppercase text-[#0f241d50] tracking-wider">
              Leitner Interval Boxes Distribution
            </span>
            <span className="text-[10px] font-mono font-bold text-[#0f241d]">
              {totalCards} Total Enrolled Cards
            </span>
          </div>

          {/* Stacking Bar Visual representation */}
          <div className="h-6 w-full bg-[#0f241d08] flex overflow-hidden rounded-xs">
            {[1, 2, 3, 4, 5].map((boxNum) => {
              const count = boxCounts[boxNum];
              const percentage = totalCards > 0 ? (count / totalCards) * 100 : 0;
              if (percentage === 0) return null;
              return (
                <div
                  key={boxNum}
                  style={{ width: `${percentage}%` }}
                  className={`${BOX_COLORS[boxNum]} h-full transition-all hover:opacity-90 flex items-center justify-center`}
                  title={`${BOX_NAMES[boxNum]}: ${count} words (${Math.round(percentage)}%)`}
                >
                  {percentage > 10 && (
                    <span className="text-[9px] font-mono font-bold text-white leading-none">
                      B{boxNum}
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {/* Detail Columns */}
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5 pt-2">
            {[1, 2, 3, 4, 5].map((boxNum) => {
              const count = boxCounts[boxNum];
              const label = BOX_NAMES[boxNum];
              return (
                <div
                  key={boxNum}
                  className="bg-white border border-[#0f241d05] p-2.5 text-center space-y-1"
                >
                  <div className="flex items-center justify-center gap-1 mx-auto">
                    <span className={`w-2 h-2 rounded-full ${BOX_COLORS[boxNum]}`} />
                    <span className="text-[8px] font-mono font-bold text-[#0f241d40]">BOX {boxNum}</span>
                  </div>
                  <h4 className="text-sm font-mono font-bold text-[#0f241d]">
                    {count}
                  </h4>
                  <p className="text-[7px] font-mono text-[#0f241d40] leading-none uppercase tracking-tight truncate" title={label}>
                    {label.split(" ")[0]}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT CARD: CORE RETENTION METRIC PILLS */}
        <div className="md:col-span-5 grid grid-cols-2 gap-4">
          
          <div className="bg-white border border-[#0f241d08] p-5 flex flex-col justify-between space-y-4">
            <div>
              <span className="text-[8px] font-mono text-[#0f241d40] uppercase tracking-wider block">Currently Due</span>
              <h3 className={`text-3xl font-sans font-semibold tracking-tight font-bold ${dueItems.length > 0 ? "text-rose-600" : "text-emerald-600"}`}>
                {dueItems.length}
              </h3>
            </div>
            <p className="text-[9px] font-mono text-[#0f241d40] leading-tight uppercase">
              {dueItems.length > 0 ? "⚠️ Retention review recommended" : "🎉 Up to date!"}
            </p>
          </div>

          <div className="bg-white border border-[#0f241d08] p-5 flex flex-col justify-between space-y-4">
            <div>
              <span className="text-[8px] font-mono text-[#0f241d40] uppercase tracking-wider block">SRS Mastery Rate</span>
              <h3 className="text-3xl font-sans font-semibold tracking-tight font-bold text-[#0f241d]">
                {totalCards > 0
                  ? Math.round(((boxCounts[4] + boxCounts[5]) / totalCards) * 100)
                  : 0}
                %
              </h3>
            </div>
            <p className="text-[9px] font-mono text-[#0f241d40] leading-tight uppercase">
              Cards in Box 4 & 5
            </p>
          </div>

        </div>

      </div>

      {/* ACTIVE REVIEW STUDY AREA */}
      <div className="border-t border-[#0f241d08] pt-6">
        
        {!activeReviewItem ? (
          <div className="bg-[#f3f7f5] border border-[#0f241d05] p-8 text-center space-y-4.5">
            <div className="w-12 h-12 rounded-full border border-dashed border-[#2d7a64] flex items-center justify-center bg-white text-[#2d7a64] mx-auto">
              <Check className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h4 className="font-sans font-semibold tracking-tight font-bold text-lg text-black">
                {dueItems.length > 0 ? "Review Cards Awaiting Recall" : "Perfect Recall State Achieved!"}
              </h4>
              <p className="text-xs text-[#0f241d50] max-w-sm mx-auto leading-relaxed">
                {dueItems.length > 0
                  ? `You have ${dueItems.length} card${dueItems.length > 1 ? "s" : ""} due for periodic review. Regular intervals reinforce memory path synapses.`
                  : "All of your learned cards are currently fully retained! Come back later, or fast forward the timer to simulate spaced interval leakage."}
              </p>
            </div>

            {dueItems.length > 0 && (
              <button
                onClick={handleStartReview}
                className="px-6 py-3 bg-[#0f241d] hover:bg-[#2d7a64] text-white hover:text-[#0f241d] font-mono text-xs uppercase tracking-widest cursor-pointer transition-colors"
              >
                Commence Review session ({dueItems.length} Cards)
              </button>
            )}
          </div>
        ) : (
          
          <div className="bg-[#f3f7f5] border border-[#2d7a64]/30 p-6 space-y-6 relative overflow-hidden">
            
            {/* SUCCESS BANNER */}
            <AnimatePresence>
              {reviewSuccessMsg && (
                <motion.div
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="absolute inset-x-0 top-0 bg-emerald-50 border-b border-emerald-100 p-4 text-center z-20 flex items-center justify-center gap-2 text-emerald-800 text-xs font-mono font-bold uppercase tracking-wide"
                >
                  <Sparkles className="w-4 h-4 text-emerald-600 animate-pulse" />
                  {reviewSuccessMsg} (+{xpGranted} XP)
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex justify-between items-center text-[9px] font-mono text-[#0f241d40] uppercase">
              <span>Recall Challenge • Box {activeReviewItem.box}</span>
              <span>Target: {activeReviewItem.languageName}</span>
            </div>

            {/* THE CARD SHIELD */}
            <div className="min-h-[160px] bg-white border border-[#0f241d08] flex flex-col items-center justify-center text-center p-6 space-y-4">
              
              {/* FRONT OF CARD */}
              <div className="space-y-1">
                <span className="text-[8px] font-mono text-[#2d7a64] uppercase tracking-widest block">Front (Recall target)</span>
                <h2 className="text-3xl font-sans font-semibold tracking-tight font-bold text-[#0f241d]">
                  {activeReviewItem.text}
                </h2>
              </div>

              {/* REVEAL BAR OR THE BACK OF CARD */}
              {!revealAnswer ? (
                <button
                  onClick={() => setRevealAnswer(true)}
                  className="px-5 py-2.5 border border-[#0f241d] hover:bg-[#f3f7f5] font-mono text-[9px] uppercase tracking-widest cursor-pointer flex items-center gap-1.5 transition-all text-[#0f241d]"
                >
                  <Eye className="w-3.5 h-3.5" /> Reveal translation & phonetic key
                </button>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="pt-4 border-t border-dashed border-[#0f241d10] w-full max-w-md space-y-3"
                >
                  <div className="space-y-1 select-all">
                    <span className="text-[8px] font-mono text-[#0f241d30] uppercase tracking-widest block">Back (Details)</span>
                    <h3 className="font-sans font-semibold tracking-tight font-bold text-xl text-[#2d7a64]">
                      "{activeReviewItem.translation}"
                    </h3>
                    <p className="text-[10px] font-mono text-[#0f241d40]">
                      Pronunciation: <strong className="text-black font-semibold">[{activeReviewItem.pronunciation}]</strong>
                    </p>
                  </div>

                  {/* ACTION CONTROLS */}
                  <div className="pt-4 flex justify-center gap-3">
                    <button
                      onClick={() => handleReviewScore(false)}
                      className="px-4 py-2.5 bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 font-mono text-[9px] uppercase tracking-widest cursor-pointer transition-colors"
                    >
                      ❌ Forgot / Hard
                    </button>
                    <button
                      onClick={() => handleReviewScore(true)}
                      className="px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 font-mono text-[9px] uppercase tracking-widest cursor-pointer transition-colors font-bold"
                    >
                      ✅ Remembered
                    </button>
                  </div>
                </motion.div>
              )}

            </div>

            {/* FOOTER CONTROLS */}
            <div className="flex justify-between items-center text-[10px] font-mono">
              <button
                onClick={() => setActiveReviewItem(null)}
                className="text-[#0f241d50] hover:text-[#0f241d] transition-colors cursor-pointer"
              >
                ← Quit session
              </button>
              <span className="text-[#0f241d30]">
                {dueItems.filter((x) => x.id !== activeReviewItem.id).length} other items left in due queue
              </span>
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
