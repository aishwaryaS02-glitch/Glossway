import { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Award, Flame, BookOpen, Layers, Check, Sparkles, Trophy, ArrowRight } from "lucide-react";

interface LevelUpCelebrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: {
    oldLevel: number;
    newLevel: number;
    xp: number;
    words: number;
    streak: number;
    sessions: number;
  };
}

export default function LevelUpCelebrationModal({ isOpen, onClose, data }: LevelUpCelebrationModalProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Active Canvas Confetti Engine
  useEffect(() => {
    if (!isOpen || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Array<{
      x: number;
      y: number;
      size: number;
      color: string;
      speedX: number;
      speedY: number;
      rotation: number;
      rotationSpeed: number;
      shape: "circle" | "square" | "triangle";
      opacity: number;
    }> = [];

    const colors = ["#2d7a64", "#0f241d", "#E5C294", "#E8D8C8", "#10B981", "#3B82F6"];

    // Resize canvas
    const resizeCanvas = () => {
      canvas.width = canvas.parentElement?.clientWidth || window.innerWidth;
      canvas.height = canvas.parentElement?.clientHeight || window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // Seed particles
    const particleCount = 100;
    const originX = canvas.width / 2;
    const originY = canvas.height / 2 - 80;

    for (let i = 0; i < particleCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 8 + 4;
      particles.push({
        x: originX,
        y: originY,
        size: Math.random() * 6 + 4,
        color: colors[Math.floor(Math.random() * colors.length)],
        speedX: Math.cos(angle) * speed,
        speedY: Math.sin(angle) * speed - Math.random() * 3, // slightly upward blast bias
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.15,
        shape: ["circle", "square", "triangle"][Math.floor(Math.random() * 3)] as any,
        opacity: 1,
      });
    }

    // Animation Loop
    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      let alive = false;
      particles.forEach((p) => {
        if (p.opacity <= 0) return;
        alive = true;

        // Apply physics
        p.x += p.speedX;
        p.y += p.speedY;
        p.speedY += 0.12; // gravity
        p.speedX *= 0.98; // air resistance
        p.rotation += p.rotationSpeed;
        
        // Slow fade-out after falling past origin
        if (p.speedY > 1) {
          p.opacity -= 0.008;
        }

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.globalAlpha = Math.max(0, p.opacity);
        ctx.fillStyle = p.color;

        ctx.beginPath();
        if (p.shape === "circle") {
          ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.shape === "square") {
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        } else if (p.shape === "triangle") {
          ctx.moveTo(0, -p.size / 2);
          ctx.lineTo(p.size / 2, p.size / 2);
          ctx.lineTo(-p.size / 2, p.size / 2);
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();
      });

      if (alive) {
        animationFrameId = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", resizeCanvas);
    };
  }, [isOpen]);

  // Next level targets
  const currentLevelMinXp = (data.newLevel - 1) * 100;
  const currentXpInLevel = data.xp - currentLevelMinXp;
  const xpPercentageOfNextLevel = Math.min(100, Math.max(0, (currentXpInLevel / 100) * 100));

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop Blur Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#0f241d75] backdrop-blur-md"
          />

          {/* Celebration Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ type: "spring", duration: 0.55, bounce: 0.2 }}
            className="relative w-full max-w-lg bg-[#f3f7f5] border border-[#0f241d15] shadow-2xl overflow-hidden rounded-xs z-10"
          >
            {/* Celebration Canvas for Confetti Overlay */}
            <canvas
              ref={canvasRef}
              className="absolute inset-0 pointer-events-none z-0"
              style={{ width: "100%", height: "100%" }}
            />

            {/* Content Container */}
            <div className="relative z-10 p-8 sm:p-10 flex flex-col items-center text-center space-y-6">
              
              {/* Header Badge */}
              <div className="relative">
                <div className="absolute -inset-2 bg-[#2d7a64]/10 rounded-full blur-xl animate-pulse" />
                <div className="w-20 h-20 bg-[#0f241d] border-2 border-[#2d7a64] flex items-center justify-center relative rounded-full">
                  <Trophy className="w-8 h-8 text-[#2d7a64]" />
                  <div className="absolute -bottom-1 -right-1 bg-[#2d7a64] text-[#0f241d] text-[10px] font-mono font-bold w-6 h-6 rounded-full flex items-center justify-center shadow-md">
                    {data.newLevel}
                  </div>
                </div>
              </div>

              {/* Title & Subtitle */}
              <div className="space-y-1">
                <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-[#2d7a64] font-bold block">
                  XP Milestone Reached
                </span>
                <h2 className="font-sans font-semibold tracking-tight text-4xl text-[#0f241d] font-semibold tracking-tight">
                  Level Up!
                </h2>
                <p className="text-xs text-neutral-500 font-sans leading-relaxed max-w-sm">
                  Congratulations, you have ascended from <span className="font-bold text-[#0f241d]">Level {data.oldLevel}</span> to <span className="font-bold text-[#0f241d]">Level {data.newLevel}</span>! Your multilingual exploration grows ever deeper.
                </p>
              </div>

              <div className="w-16 h-[1px] bg-[#0f241d10]" />

              {/* Stats Summary Grid */}
              <div className="w-full grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white border border-[#0f241d08] p-4">
                <div className="flex flex-col items-center justify-center p-2">
                  <Layers className="w-4 h-4 text-[#2d7a64] mb-1" />
                  <span className="text-base font-sans font-semibold tracking-tight font-bold text-[#0f241d]">
                    {data.xp}
                  </span>
                  <span className="text-[8px] font-mono uppercase tracking-wider text-neutral-400">
                    Total XP
                  </span>
                </div>

                <div className="flex flex-col items-center justify-center p-2 border-l border-neutral-100">
                  <BookOpen className="w-4 h-4 text-[#2d7a64] mb-1" />
                  <span className="text-base font-sans font-semibold tracking-tight font-bold text-[#0f241d]">
                    {data.words}
                  </span>
                  <span className="text-[8px] font-mono uppercase tracking-wider text-neutral-400">
                    Words Learned
                  </span>
                </div>

                <div className="flex flex-col items-center justify-center p-2 border-l border-neutral-100">
                  <Flame className="w-4 h-4 text-[#2d7a64] mb-1" />
                  <span className="text-base font-sans font-semibold tracking-tight font-bold text-[#0f241d]">
                    {data.streak}d
                  </span>
                  <span className="text-[8px] font-mono uppercase tracking-wider text-neutral-400">
                    Streak
                  </span>
                </div>

                <div className="flex flex-col items-center justify-center p-2 border-l border-neutral-100">
                  <Award className="w-4 h-4 text-[#2d7a64] mb-1" />
                  <span className="text-base font-sans font-semibold tracking-tight font-bold text-[#0f241d]">
                    {data.sessions}
                  </span>
                  <span className="text-[8px] font-mono uppercase tracking-wider text-neutral-400">
                    Sessions
                  </span>
                </div>
              </div>

              {/* Progress towards Next Level */}
              <div className="w-full space-y-1.5 text-left">
                <div className="flex justify-between items-baseline text-[9px] font-mono uppercase tracking-wider">
                  <span className="text-neutral-400 font-bold">Progress To Level {data.newLevel + 1}</span>
                  <span className="text-[#0f241d] font-bold">{data.xp % 100} / 100 XP</span>
                </div>
                <div className="w-full h-1.5 bg-[#f3f7f5] border border-[#0f241d10] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${xpPercentageOfNextLevel}%` }}
                    transition={{ delay: 0.4, duration: 0.8, ease: "easeOut" }}
                    className="h-full bg-gradient-to-r from-[#2d7a64] to-[#0f241d]"
                  />
                </div>
              </div>

              {/* Unlocked Capabilities or Perks */}
              <div className="w-full text-left bg-[#e8f0eb] border border-[#0f241d08] p-4 space-y-2.5">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#2d7a64]" />
                  <span className="text-[9px] font-mono uppercase tracking-widest font-bold text-[#0f241d]">
                    Explorer Perks Unlocked
                  </span>
                </div>
                <ul className="space-y-1.5">
                  <li className="flex items-center gap-2 text-[11px] text-neutral-600 font-sans font-semibold tracking-tight">
                    <span className="w-3.5 h-3.5 rounded-full bg-white flex items-center justify-center border border-[#0f241d10] shrink-0">
                      <Check className="w-2.5 h-2.5 text-emerald-600 font-bold" />
                    </span>
                    <span>Advanced cognitive language exercises unlocked in Learning Portal</span>
                  </li>
                  <li className="flex items-center gap-2 text-[11px] text-neutral-600 font-sans font-semibold tracking-tight">
                    <span className="w-3.5 h-3.5 rounded-full bg-white flex items-center justify-center border border-[#0f241d10] shrink-0">
                      <Check className="w-2.5 h-2.5 text-emerald-600 font-bold" />
                    </span>
                    <span>ai mentor's AI feedback responses gain depth & reasoning density</span>
                  </li>
                </ul>
              </div>

              {/* Close Button */}
              <button
                onClick={onClose}
                className="w-full bg-[#0f241d] hover:bg-[#2d7a64] text-white hover:text-[#0f241d] py-4 px-8 text-xs font-mono uppercase tracking-widest font-semibold transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 border border-transparent shadow-md"
              >
                <span>Continue Journey</span>
                <ArrowRight className="w-4 h-4" />
              </button>

            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
