import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { UserProfile } from "../types";
import {
  Mic,
  Volume2,
  Sparkles,
  RefreshCw,
  Play,
  Square,
  CheckCircle2,
  AlertCircle,
  Trash2,
  PlusCircle,
  BookOpen,
  Zap,
} from "lucide-react";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";
import { apiFetch } from "../utils/api";

interface PronunciationPracticeProps {
  userProfile: UserProfile | null;
  onUpdateUserProfile: (updates: Partial<UserProfile>) => void;
  selectedLanguageId: string;
  activeLanguage: {
    id: string;
    name: string;
    flag: string;
    beginner: Array<{ word: string; translation: string; pronunciation: string; partOfSpeech?: string }>;
    middleware: Array<{ phrase: string; translation: string; pronunciation: string; context?: string }>;
  };
  handleSpeak: (text: string, langId: string, speedModifier?: number) => Promise<void>;
  activeTutor: {
    name: string;
    location: string;
    avatar: string;
    description: string;
    mouthPhonetics: string;
  };
}

interface PracticeItem {
  id: string;
  text: string;
  translation: string;
  pronunciation: string;
  difficulty: "beginner" | "middleware" | "custom";
}

export default function PronunciationPractice({
  userProfile,
  onUpdateUserProfile,
  selectedLanguageId,
  activeLanguage,
  handleSpeak,
  activeTutor,
}: PronunciationPracticeProps) {
  const [practiceList, setPracticeList] = useState<PracticeItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<PracticeItem | null>(null);
  const [customPhrase, setCustomPhrase] = useState("");
  const [customTranslation, setCustomTranslation] = useState("");

  // Audio Recording states
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [xpEarned, setXpEarned] = useState(false);

  // Audio Player states for user's recording
  const [isUserPlaying, setIsUserPlaying] = useState(false);

  // Refs
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const userAudioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize practice items list from active language
  useEffect(() => {
    const list: PracticeItem[] = [];

    // Pull beginner words
    if (activeLanguage.beginner && activeLanguage.beginner.length > 0) {
      activeLanguage.beginner.slice(0, 3).forEach((item, idx) => {
        list.push({
          id: `beg-${idx}`,
          text: item.word,
          translation: item.translation,
          pronunciation: item.pronunciation,
          difficulty: "beginner",
        });
      });
    }

    // Pull middleware phrases
    if (activeLanguage.middleware && activeLanguage.middleware.length > 0) {
      activeLanguage.middleware.slice(0, 3).forEach((item, idx) => {
        list.push({
          id: `mid-${idx}`,
          text: item.phrase,
          translation: item.translation,
          pronunciation: item.pronunciation,
          difficulty: "middleware",
        });
      });
    }

    setPracticeList(list);
    if (list.length > 0) {
      setSelectedItem(list[0]);
    }

    // Reset recording states on language shift
    setAudioBlob(null);
    setAudioUrl(null);
    setAnalysisResult(null);
    setXpEarned(false);
    setError(null);
  }, [activeLanguage]);

  // Handle Recording Timer
  useEffect(() => {
    if (isRecording) {
      setRecordingSeconds(0);
      timerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => {
          if (prev >= 15) {
            stopRecording();
            return 15;
          }
          return prev + 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRecording]);

  const handleSelectPracticeItem = (item: PracticeItem) => {
    setSelectedItem(item);
    setAudioBlob(null);
    setAudioUrl(null);
    setAnalysisResult(null);
    setXpEarned(false);
    setError(null);
  };

  const handleAddCustomPhrase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customPhrase.trim()) return;

    const newItem: PracticeItem = {
      id: `custom-${Date.now()}`,
      text: customPhrase.trim(),
      translation: customTranslation.trim() || "User custom phrase",
      pronunciation: "Custom phonetic guide",
      difficulty: "custom",
    };

    setPracticeList((prev) => [newItem, ...prev]);
    setSelectedItem(newItem);
    setCustomPhrase("");
    setCustomTranslation("");
    setAudioBlob(null);
    setAudioUrl(null);
    setAnalysisResult(null);
    setXpEarned(false);
    setError(null);
  };

  const handleDeleteItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setPracticeList((prev) => prev.filter((item) => item.id !== id));
    if (selectedItem?.id === id) {
      setSelectedItem(null);
      setAudioBlob(null);
      setAudioUrl(null);
      setAnalysisResult(null);
      setError(null);
    }
  };

  // Start microphone capture
  const startRecording = async () => {
    try {
      setError(null);
      setAnalysisResult(null);
      setAudioBlob(null);
      setAudioUrl(null);
      setXpEarned(false);

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        setAudioBlob(blob);
        setAudioUrl(URL.createObjectURL(blob));
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err: any) {
      console.error(err);
      setError(
        "Microphone access denied or unsupported in this browser environment. Please verify site permissions."
      );
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
    }
  };

  // Playback user's recorded audio
  const handlePlayUserRecording = () => {
    if (!audioUrl) return;

    if (userAudioRef.current) {
      userAudioRef.current.pause();
      userAudioRef.current = null;
      setIsUserPlaying(false);
      return;
    }

    const audio = new Audio(audioUrl);
    userAudioRef.current = audio;
    setIsUserPlaying(true);

    audio.onended = () => {
      setIsUserPlaying(false);
      userAudioRef.current = null;
    };

    audio.play().catch((err) => {
      console.error("Failed to play user recording:", err);
      setIsUserPlaying(false);
    });
  };

  // Call Gemini API to transcribe and analyze the audio
  const handleAnalyzePronunciation = async () => {
    if (!audioBlob || isAnalyzing || !selectedItem) return;

    setIsAnalyzing(true);
    setError(null);
    setAnalysisResult(null);

    try {
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(",")[1];

        // We can append specific guidance context based on target phrase to make Gemini feedback extraordinarily precise!
        const promptContext = `You are Priya Hegde, an accent coach from Bangalore, India.
You appear in Glossway as a warm, encouraging pronunciation guide for words and phrases with regional/regional pronunciation nuances.

PERSONA:
- Warm, patient, a little playful — like a friend teaching you a phrase before a trip.
- You occasionally share a one-line cultural note about the word/phrase (when culturally relevant), but keep it brief — 1 sentence max.
- Never robotic or clinical. Talk like a person, not a textbook.

YOUR TASK:
You will receive an audio recording of the user trying to say a target phrase.
- targetLanguage: ${activeLanguage.name}
- targetWord: ${selectedItem.text}
- targetIPA: ${selectedItem.pronunciation}
- meaning: ${selectedItem.translation}

Listen to the user's audio attempt and compare it to targetWord/targetIPA. Respond with:
1. One encouraging opening line (never skip this, even for a good attempt).
2. A gentle, specific note on what to adjust — described by FEEL, not IPA jargon (e.g. "try softening the 'ska' part, almost like 'ska' in 'scarf' but shorter").
3. Break the word into syllables and mark where to add slight stress if relevant.
4. End with an invitation to try again OR affirmation if it's close, never a pass/fail verdict.

TONE RULES (non-negotiable):
- NEVER say "wrong," "incorrect," "failed," or give a numeric score to the user.
- NEVER use punitive markers (X marks, red text, "try harder").
- If the audio is completely silent, unclear, or doesn't match at all, gently encourage them to try speaking a bit closer to the microphone.`;

        const res = await apiFetch("/api/transcribe-audio", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            audioBase64: base64Data,
            mimeType: "audio/webm",
            promptContext, // Pass down custom prompt instructions
          }),
          retryAction: () => handleAnalyzePronunciation(),
          actionName: "Pronunciation Practice Analyst"
        });

        if (!res.ok) {
          throw new Error("Generative transcription engine returned non-ok status.");
        }

        const data = await res.json();
        if (!data.text) {
          throw new Error("No feedback returned from the model.");
        }

        setAnalysisResult(data.text);
        setIsAnalyzing(false);

        // Extract score and award XP
        let score = 85; // Default score
        const match = data.text.match(/Fluency Score:\s*(\d+)/i);
        if (match && match[1]) {
          score = parseInt(match[1], 10);
        }

        // Award XP!
        if (userProfile && !xpEarned) {
          const awardXp = score >= 90 ? 25 : 15; // Higher XP for excellent attempts!
          const currentXp = userProfile.xp || 0;
          const newXp = currentXp + awardXp;
          const newLevel = Math.floor(newXp / 100) + 1;

          onUpdateUserProfile({
            xp: newXp,
            level: newLevel,
          });

          setXpEarned(true);

          if (userProfile.uid) {
            try {
              const userRef = doc(db, "users", userProfile.uid);
              await updateDoc(userRef, {
                xp: newXp,
                level: newLevel,
              });
            } catch (err) {
              console.error("Failed to sync pronunciation XP to database:", err);
            }
          }
        }
      };
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during pronunciation analysis.");
      setIsAnalyzing(false);
    }
  };

  // Helper to render segmented analysis feedback beautifully
  const renderFeedbackText = (text: string) => {
    // Separate out the score line from the rest of feedback
    const lines = text.split("\n");
    const feedbackLines = lines.filter((l) => !l.toLowerCase().includes("fluency score:"));
    const scoreLine = lines.find((l) => l.toLowerCase().includes("fluency score:"));

    let extractedScore = "";
    if (scoreLine) {
      const match = scoreLine.match(/(\d+)\/100/);
      if (match) extractedScore = match[1];
    }

    return (
      <div className="space-y-4">
        {extractedScore && (
          <div className="bg-[#f3f7f5] border border-[#2d7a64]/30 p-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full border-2 border-dashed border-[#2d7a64] flex items-center justify-center bg-white text-[#2d7a64] font-mono font-bold text-lg">
                {extractedScore}%
              </div>
              <div>
                <span className="text-[9px] font-mono text-[#0f241d50] uppercase block">Phonetic Integrity Score</span>
                <h4 className="font-sans font-semibold tracking-tight font-bold text-base text-[#0f241d]">
                  {parseInt(extractedScore, 10) >= 90
                    ? "Sublime Cadence!"
                    : parseInt(extractedScore, 10) >= 75
                    ? "Highly Intelligible Articulation"
                    : "Terrific Scholarly Attempt"}
                </h4>
              </div>
            </div>
            
            <div className="flex items-center gap-1.5 bg-emerald-50 text-emerald-700 text-[10px] font-mono font-bold uppercase tracking-wider px-3 py-1.5 rounded-xs border border-emerald-100 select-none">
              <Zap className="w-3.5 h-3.5 fill-current text-emerald-500 animate-bounce" />
              +{parseInt(extractedScore, 10) >= 90 ? "25" : "15"} XP Awarded
            </div>
          </div>
        )}

        <div className="bg-white border border-[#0f241d08] p-5 space-y-3.5">
          <div className="flex items-center gap-2 text-neutral-400">
            <CheckCircle2 className="w-4 h-4 text-[#2d7a64]" />
            <span className="text-[10px] font-mono uppercase tracking-[0.15em] font-semibold text-[#0f241d40]">Gemini Tutor Transcript & Feedback</span>
          </div>
          <div className="text-xs text-[#0f241d80] leading-relaxed font-sans font-semibold tracking-tight whitespace-pre-wrap space-y-3">
            {feedbackLines.map((line, idx) => {
              const cleanLine = line.replace(/^\*+/, "").replace(/\*+$/, ""); // Simple cleaner
              if (!cleanLine.trim()) return null;
              
              const isHeader = cleanLine.startsWith("###") || cleanLine.startsWith("##") || cleanLine.includes("Feedback:") || cleanLine.includes("Transcription:");
              return (
                <p key={idx} className={isHeader ? "font-sans font-bold text-black mt-3 pt-2 border-t border-[#0f241d05] first:border-0 first:pt-0" : ""}>
                  {cleanLine}
                </p>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* 1. TUTOR PROFILE & TIPS BAR */}
      <div className="bg-white border border-[#0f241d10] p-6 grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="flex items-center gap-4 border-b md:border-b-0 md:border-r border-[#0f241d10] pb-4 md:pb-0 md:pr-4">
          <div className="w-14 h-14 bg-[#e8f0eb] border border-[#0f241d15] flex items-center justify-center text-3xl select-none shrink-0">
            {activeTutor.avatar}
          </div>
          <div>
            <span className="text-[8px] font-mono text-[#2d7a64] uppercase tracking-wider font-bold">Accent Specialist</span>
            <h3 className="font-sans font-semibold tracking-tight text-base font-bold text-[#0f241d] leading-tight">{activeTutor.name}</h3>
            <p className="text-[10px] font-mono text-[#0f241d40]">{activeTutor.location}</p>
          </div>
        </div>
        
        <div className="md:col-span-3 flex flex-col justify-center space-y-1.5">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#2d7a64]" />
            <span className="text-[9px] font-mono text-[#2d7a64] uppercase tracking-widest font-semibold">Tutor Phonetic Wisdom</span>
          </div>
          <p className="text-xs text-[#0f241d70] font-sans font-semibold tracking-tight leading-relaxed">
            "{activeTutor.mouthPhonetics}"
          </p>
          <p className="text-[10px] text-[#0f241d40]">
            {activeTutor.description}
          </p>
        </div>
      </div>

      {/* MAIN PRACTICE SHELF & RECORDING WORKSPACE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: SPEECH PRACTICE TARGETS (Lg: 5/12 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="space-y-2">
            <div className="flex justify-between items-end">
              <h3 className="font-sans font-semibold tracking-tight text-lg font-medium text-[#0f241d]">
                Active Speech Targets
              </h3>
              <span className="text-[9px] font-mono text-[#0f241d40] uppercase">
                {practiceList.length} Items Available
              </span>
            </div>
            <p className="text-xs text-[#0f241d50]">
              Select a vocabulary word or phrase from the list below to practice, or create a completely custom target.
            </p>
          </div>

          <div className="space-y-2 max-h-[350px] overflow-y-auto pr-2 custom-scrollbar">
            {practiceList.map((item) => {
              const isSelected = selectedItem?.id === item.id;
              return (
                <div
                  key={item.id}
                  onClick={() => handleSelectPracticeItem(item)}
                  className={`p-4 border transition-all cursor-pointer flex justify-between items-center ${
                    isSelected
                      ? "bg-white border-[#2d7a64] shadow-xs"
                      : "bg-[#f3f7f5]/50 border-[#0f241d08] hover:border-[#0f241d15] hover:bg-[#f3f7f5]"
                  }`}
                >
                  <div className="space-y-1 select-none pr-4">
                    <div className="flex items-center gap-2">
                      <span className={`text-[8px] font-mono uppercase tracking-wider px-1.5 py-0.5 border ${
                        item.difficulty === "beginner"
                          ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                          : item.difficulty === "middleware"
                          ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                          : "bg-purple-50 text-purple-700 border-purple-100"
                      }`}>
                        {item.difficulty}
                      </span>
                      {isSelected && <span className="text-[8px] font-mono text-[#2d7a64] uppercase tracking-widest font-bold">● Active target</span>}
                    </div>
                    <h4 className="font-sans font-semibold tracking-tight font-bold text-base text-[#0f241d] truncate max-w-[200px]">
                      {item.text}
                    </h4>
                    <p className="text-[10px] font-mono text-[#0f241d40] truncate max-w-[200px]">
                      {item.translation}
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSpeak(item.text, selectedLanguageId);
                      }}
                      className="p-1.5 rounded-full hover:bg-[#0f241d05] text-[#0f241d50] hover:text-[#0f241d] transition-colors cursor-pointer"
                      title="Listen Standard Reference Voice"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>

                    {item.difficulty === "custom" && (
                      <button
                        type="button"
                        onClick={(e) => handleDeleteItem(item.id, e)}
                        className="p-1.5 rounded-full hover:bg-red-50 text-red-400 hover:text-red-600 transition-colors cursor-pointer"
                        title="Remove Target"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}

            {practiceList.length === 0 && (
              <div className="text-center py-12 border border-dashed border-[#0f241d10] bg-[#f3f7f5]/30">
                <BookOpen className="w-8 h-8 text-[#0f241d20] mx-auto mb-2" />
                <p className="text-xs text-[#0f241d40] font-mono">No practice targets available.</p>
              </div>
            )}
          </div>

          {/* CUSTOM PHRASE CREATOR */}
          <form onSubmit={handleAddCustomPhrase} className="bg-white border border-[#0f241d10] p-4 space-y-3">
            <span className="text-[8px] font-mono text-[#2d7a64] uppercase tracking-wider block font-bold">
              Add Custom Practice Target
            </span>
            <div className="space-y-2">
              <input
                type="text"
                value={customPhrase}
                onChange={(e) => setCustomPhrase(e.target.value)}
                placeholder={`Phrase in ${activeLanguage.name} (e.g. "Namaskara")`}
                className="w-full bg-[#f3f7f5] border border-[#0f241d10] px-3 py-2 text-xs font-mono focus:border-[#2d7a64] focus:outline-none"
                required
              />
              <input
                type="text"
                value={customTranslation}
                onChange={(e) => setCustomTranslation(e.target.value)}
                placeholder="English Translation"
                className="w-full bg-[#f3f7f5] border border-[#0f241d10] px-3 py-2 text-xs font-mono focus:border-[#2d7a64] focus:outline-none"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-[#0f241d] hover:bg-[#25332e] text-[#f3f7f5] text-xs font-mono uppercase tracking-wider cursor-pointer flex items-center justify-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4" /> Inject Phrase
            </button>
          </form>
        </div>

        {/* RIGHT COLUMN: REPLAY, MIC RECORDING, ANALYSIS RESULTS (Lg: 7/12 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {selectedItem ? (
            <div className="bg-white border border-[#0f241d10] p-6 space-y-6">
              
              {/* Target Banner */}
              <div className="border-b border-[#0f241d05] pb-5 space-y-2 relative">
                <span className="text-[9px] font-mono uppercase tracking-widest text-[#2d7a64]">Active Coaching Subject</span>
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="font-sans font-semibold tracking-tight font-bold text-2xl text-[#0f241d]">
                      {selectedItem.text}
                    </h2>
                    <p className="text-[10px] font-mono text-[#0f241d40] tracking-wide uppercase mt-0.5">
                      Phonetic pronunciation: <span className="text-[#2d7a64] font-semibold">[{selectedItem.pronunciation}]</span>
                    </p>
                  </div>

                  <button
                    onClick={() => handleSpeak(selectedItem.text, selectedLanguageId)}
                    className="p-3 bg-[#f3f7f5] border border-[#0f241d08] hover:border-[#0f241d20] rounded-full text-[#0f241d] hover:text-[#2d7a64] transition-colors cursor-pointer flex items-center justify-center"
                    title="Listen standard pronunciations"
                  >
                    <Volume2 className="w-5 h-5" />
                  </button>
                </div>
                <p className="text-xs text-[#0f241d60] font-sans font-semibold tracking-tight pt-1 border-t border-[#0f241d03]">
                  Translation: "{selectedItem.translation}"
                </p>
              </div>

              {/* RECORDING ENGINE INTERFACE */}
              <div className="flex flex-col items-center justify-center py-6 bg-[#f3f7f5]/50 border border-[#0f241d05] p-5 space-y-4">
                
                <div className="relative flex items-center justify-center">
                  <AnimatePresence>
                    {isRecording && (
                      <motion.div
                        className="absolute inset-0 rounded-full border-2 border-red-500/20"
                        initial={{ scale: 1, opacity: 0.8 }}
                        animate={{ scale: 1.5, opacity: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 1.5, repeat: Infinity, ease: "easeOut" }}
                      />
                    )}
                  </AnimatePresence>

                  <button
                    onClick={isRecording ? stopRecording : startRecording}
                    className={`w-16 h-16 rounded-full flex items-center justify-center border-4 border-white shadow-md transition-all cursor-pointer ${
                      isRecording ? "bg-red-600 text-white hover:bg-red-700" : "bg-[#0f241d] text-white hover:bg-[#25332e]"
                    }`}
                  >
                    {isRecording ? <Square className="w-6 h-6 animate-pulse" /> : <Mic className="w-6 h-6" />}
                  </button>
                </div>

                <div className="text-center space-y-1 select-none">
                  <h4 className="font-mono text-xs font-bold">
                    {isRecording ? (
                      <span className="text-red-600 uppercase tracking-widest flex items-center justify-center gap-1.5">
                        Recording... {recordingSeconds}s / 15s limit
                      </span>
                    ) : audioBlob ? (
                      <span className="text-[#2d7a64] uppercase tracking-widest flex items-center justify-center gap-1.5">
                        Attempt Recorded Successfully!
                      </span>
                    ) : (
                      <span className="text-[#0f241d50] uppercase tracking-widest">
                        Click microphone to record your attempt
                      </span>
                    )}
                  </h4>
                  <p className="text-[10px] text-[#0f241d40]">
                    Speak clearly. Click to stop recording when you are finished.
                  </p>
                </div>

                {/* Local audio playback for validation */}
                {audioUrl && (
                  <div className="pt-2 flex gap-3 w-full">
                    <button
                      onClick={handlePlayUserRecording}
                      className="flex-1 py-2.5 bg-white border border-[#0f241d15] hover:bg-neutral-50 text-neutral-800 font-mono text-[10px] uppercase tracking-wider cursor-pointer flex items-center justify-center gap-1.5 transition-colors"
                    >
                      {isUserPlaying ? (
                        <>
                          <Square className="w-3.5 h-3.5" /> Stop playback
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5" /> Listen to your recorded voice
                        </>
                      )}
                    </button>

                    <button
                      onClick={handleAnalyzePronunciation}
                      disabled={isAnalyzing}
                      className="flex-1 py-2.5 bg-[#2d7a64] hover:bg-[#B3966E] disabled:opacity-50 text-white font-mono text-[10px] uppercase tracking-wider cursor-pointer flex items-center justify-center gap-1.5 transition-colors"
                    >
                      {isAnalyzing ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Analyzing Phonemes...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5" /> Run AI Accent Coach Analysis
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {/* ERROR STATE */}
              {error && (
                <div className="bg-red-50 border border-red-100 p-4 flex gap-3 text-red-700 text-xs font-mono">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <p>{error}</p>
                </div>
              )}

              {/* LOADING SKELTON FOR AI ANALYSIS */}
              {isAnalyzing && (
                <div className="bg-[#f3f7f5]/40 border border-[#0f241d05] p-6 space-y-4 animate-pulse">
                  <div className="flex items-center gap-2.5">
                    <RefreshCw className="w-4 h-4 text-[#2d7a64] animate-spin" />
                    <span className="text-[9px] font-mono uppercase tracking-[0.15em] text-[#2d7a64] font-bold">Scanning pronunciation wave...</span>
                  </div>
                  <div className="h-4 bg-[#0f241d05] rounded-xs w-3/4"></div>
                  <div className="h-3 bg-[#0f241d05] rounded-xs w-5/6"></div>
                  <div className="h-3 bg-[#0f241d05] rounded-xs w-1/2"></div>
                </div>
              )}

              {/* ANALYSIS RESULTS SUMMARY */}
              {analysisResult && !isAnalyzing && renderFeedbackText(analysisResult)}

            </div>
          ) : (
            <div className="text-center py-20 border border-dashed border-[#0f241d10] bg-[#f3f7f5]/20">
              <Mic className="w-10 h-10 text-[#0f241d20] mx-auto mb-3" />
              <p className="text-sm text-[#0f241d50] font-sans font-semibold tracking-tight">Please select an active target from the shelf to commence pronunciation training.</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
