import { useState, useEffect, useMemo } from "react";
import { db } from "../firebase";
import {
  doc,
  updateDoc,
  increment,
  collection,
  onSnapshot,
  writeBatch,
  addDoc,
  deleteDoc,
} from "firebase/firestore";
import { UserProfile, Flashcard } from "../types";
import { MULTILINGUAL_DATA } from "../data/multilingualHubData";
import { apiFetch } from "../utils/api";
import {
  Volume2,
  ChevronLeft,
  ChevronRight,
  Shuffle,
  BookOpen,
  Sparkles,
  RefreshCw,
  Award,
  Plus,
  Trash2,
  Edit2,
  Search,
} from "lucide-react";

enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
  };
}


interface FlashcardsViewProps {
  userProfile: UserProfile | null;
  onUpdateUserProfile: (updates: Partial<UserProfile>) => void;
  onNavigate: (screen: string) => void;
}

export default function FlashcardsView({
  userProfile,
  onUpdateUserProfile,
  
}: FlashcardsViewProps) {
  // Error handler adhering to strict Firebase Integration spec
  const handleFirestoreError = (
    error: unknown,
    operationType: OperationType,
    path: string | null
  ) => {
    const errInfo: FirestoreErrorInfo = {
      error: error instanceof Error ? error.message : String(error),
      authInfo: {
        userId: userProfile?.uid,
      },
      operationType,
      path,
    };
    console.error("Firestore Error: ", JSON.stringify(errInfo));
    throw new Error(JSON.stringify(errInfo));
  };

  // Determine user's active language from profile
  const defaultLanguageId = useMemo(() => {
    if (userProfile && userProfile.languages && Object.keys(userProfile.languages).length > 0) {
      return Object.keys(userProfile.languages)[0];
    }
    return "kannada";
  }, [userProfile]);

  const [selectedLanguageId, setSelectedLanguageId] = useState<string>(defaultLanguageId);
  const [selectedLevel, setSelectedLevel] = useState<"all" | "Beginner" | "Intermediate" | "Advanced">("all");
  const [viewMode, setViewMode] = useState<"study" | "manage">("study");

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);

  // Firestore flashcards data states
  const [firestoreCards, setFirestoreCards] = useState<Flashcard[]>([]);
  const [loadingCards, setLoadingCards] = useState(true);
  const [isSeeding, setIsSeeding] = useState(false);

  // Form states for creating custom flashcards
  const [newWord, setNewWord] = useState("");
  const [newTranslation, setNewTranslation] = useState("");
  const [newPronunciation, setNewPronunciation] = useState("");
  const [newLevel, setNewLevel] = useState<string>("Beginner");
  const [manageSearch, setManageSearch] = useState("");

  // Editing card states
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [editWord, setEditWord] = useState("");
  const [editTranslation, setEditTranslation] = useState("");
  const [editPronunciation, setEditPronunciation] = useState("");
  const [editLevel, setEditLevel] = useState<string>("Beginner");

  // Example generation states
  const [isGeneratingExample, setIsGeneratingExample] = useState(false);
  const [generationError, setGenerationError] = useState("");

  // Get active language name (e.g. "Kannada", "Hindi") from selectedLanguageId
  const selectedLanguageName = useMemo(() => {
    const found = MULTILINGUAL_DATA.find((lang) => lang.id === selectedLanguageId);
    return found ? found.name : "Kannada";
  }, [selectedLanguageId]);

  // Sync / Listen to Firestore sub-collection of flashcards
  useEffect(() => {
    if (!userProfile?.uid) return;

    setLoadingCards(true);
    const flashcardsColRef = collection(db, "users", userProfile.uid, "flashcards");

    const unsubscribe = onSnapshot(
      flashcardsColRef,
      async (snapshot) => {
        const cardsList: any[] = [];
        snapshot.forEach((doc) => {
          cardsList.push({ id: doc.id, ...doc.data() });
        });

        // If the collection is empty and we are not already seeding, run automatic seeding
        if (snapshot.empty && !isSeeding) {
          setIsSeeding(true);
          try {
            const batch = writeBatch(db);
            let count = 0;

            for (const lang of MULTILINGUAL_DATA) {
              // Beginner cards
              lang.beginner.forEach((v, idx) => {
                const cardId = `vocab_${lang.id}_${idx}`;
                const docRef = doc(db, "users", userProfile.uid, "flashcards", cardId);
                batch.set(docRef, {
                  word: v.word,
                  translation: v.translation,
                  pronunciation: v.pronunciation,
                  exampleSentence: "",
                  exampleTranslation: "",
                  examplePronunciation: "",
                  language: lang.name,
                  level: "Beginner",
                  starred: false,
                  custom: false,
                  createdAt: Date.now() + count, // ensure slightly sorted order
                });
                count++;
              });

              // Intermediate cards
              lang.middleware.forEach((p, idx) => {
                const cardId = `phrase_${lang.id}_${idx}`;
                const docRef = doc(db, "users", userProfile.uid, "flashcards", cardId);
                batch.set(docRef, {
                  word: p.phrase,
                  translation: p.translation,
                  pronunciation: p.pronunciation,
                  exampleSentence: "",
                  exampleTranslation: "",
                  examplePronunciation: "",
                  language: lang.name,
                  level: "Intermediate",
                  starred: false,
                  custom: false,
                  createdAt: Date.now() + count,
                });
                count++;
              });

              // Advanced cards
              lang.pro.forEach((r, idx) => {
                const cardId = `pro_${lang.id}_${idx}`;
                const docRef = doc(db, "users", userProfile.uid, "flashcards", cardId);
                batch.set(docRef, {
                  word: r.ruleName,
                  translation: r.explanation,
                  pronunciation: r.structure,
                  exampleSentence: r.examples?.[0]?.native || "",
                  exampleTranslation: r.examples?.[0]?.translation || "",
                  examplePronunciation: r.examples?.[0]?.pronunciation || "",
                  language: lang.name,
                  level: "Advanced",
                  starred: false,
                  custom: false,
                  createdAt: Date.now() + count,
                });
                count++;
              });
            }

            if (count > 0) {
              await batch.commit();
            }
          } catch (err) {
            console.error("Error seeding flashcards:", err);
            handleFirestoreError(err, OperationType.WRITE, `users/${userProfile.uid}/flashcards`);
          } finally {
            setIsSeeding(false);
            setLoadingCards(false);
          }
        } else {
          // Sort cards by createdAt timestamp
          cardsList.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
          setFirestoreCards(cardsList);
          setLoadingCards(false);
        }
      },
      (error) => {
        setLoadingCards(false);
        handleFirestoreError(error, OperationType.LIST, `users/${userProfile.uid}/flashcards`);
      }
    );

    return () => unsubscribe();
  }, [userProfile?.uid]);

  // Construct deck dynamically from current Firestore cards filtered by selection
  const deck = useMemo(() => {
    const filtered = firestoreCards.filter(
      (card) => card.language.toLowerCase() === selectedLanguageName.toLowerCase()
    );

    if (selectedLevel === "all") {
      return filtered;
    }
    return filtered.filter((c) => c.level === selectedLevel);
  }, [firestoreCards, selectedLanguageName, selectedLevel]);

  // Reset index when changing deck filters
  useEffect(() => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setGenerationError("");
  }, [selectedLanguageId, selectedLevel]);

  const currentCard = deck[currentIndex] || null;

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const playPronunciation = (e: React.MouseEvent, text: string, langName: string) => {
    e.stopPropagation();
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);

      const langMap: Record<string, string> = {
        English: "en-US",
        Spanish: "es-ES",
        French: "fr-FR",
        German: "de-DE",
        Mandarin: "zh-CN",
        Japanese: "ja-JP",
        Hindi: "hi-IN",
        Russian: "ru-RU",
        Arabic: "ar-SA",
        Kannada: "kn-IN",
      };

      utterance.lang = langMap[langName] || "en-US";
      window.speechSynthesis.speak(utterance);
    } else {
    }
  };

  // Toggle star status in Firestore document
  const toggleStar = async (e: React.MouseEvent, card: any) => {
    e.stopPropagation();
    if (!userProfile?.uid || !card.id) return;

    try {
      const cardRef = doc(db, "users", userProfile.uid, "flashcards", card.id);
      await updateDoc(cardRef, {
        starred: !card.starred,
      });
    } catch (err) {
      console.error("Failed to toggle star:", err);
      handleFirestoreError(err, OperationType.UPDATE, `users/${userProfile.uid}/flashcards/${card.id}`);
    }
  };

  // Got It completion increases profile points
  const handleGotIt = async (e: React.MouseEvent) => {
    e.stopPropagation();

    if (userProfile?.uid) {
      try {
        const userDocRef = doc(db, "users", userProfile.uid);
        await updateDoc(userDocRef, {
          wordsLearned: increment(1),
          xp: increment(10),
        });

        onUpdateUserProfile({
          wordsLearned: userProfile.wordsLearned + 1,
          xp: userProfile.xp + 10,
        });
      } catch (err) {
        console.error("Failed to update user profile in Firestore:", err);
        handleFirestoreError(err, OperationType.UPDATE, `users/${userProfile.uid}`);
      }
    }

    nextCard();
  };

  const nextCard = () => {
    if (deck.length <= 1) return;
    setIsAnimating(true);
    setTimeout(() => {
      setIsFlipped(false);
      setGenerationError("");
      setCurrentIndex((prev) => (prev + 1) % deck.length);
      setIsAnimating(false);
    }, 200);
  };

  const prevCard = () => {
    if (deck.length <= 1) return;
    setIsAnimating(true);
    setTimeout(() => {
      setIsFlipped(false);
      setGenerationError("");
      setCurrentIndex((prev) => (prev - 1 + deck.length) % deck.length);
      setIsAnimating(false);
    }, 200);
  };

  const shuffleDeck = () => {
    if (deck.length <= 1) return;
    setCurrentIndex(Math.floor(Math.random() * deck.length));
    setIsFlipped(false);
    setGenerationError("");
  };

  // Generate Automatic AI Example and update Firestore document dynamically
  const handleGenerateAIExample = async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!currentCard || isGeneratingExample || !userProfile?.uid) return;

    setIsGeneratingExample(true);
    setGenerationError("");

    try {
      const response = await apiFetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: `Generate exactly one simple, highly practical example sentence in ${currentCard.language} using the word or phrase "${currentCard.word}" (translation: "${currentCard.translation}").
Also provide the English translation of the sentence and a simple translit/pronunciation guide in English.
Respond ONLY with a valid JSON object in the following format (do not wrap in markdown backticks, just raw JSON text):
{
  "sentence": "the example sentence",
  "translation": "English translation",
  "pronunciation": "pronunciation guide"
}`,
          modelType: "gemini",
          language: currentCard.language,
          isFlashcardGenerator: true,
        }),
        retryAction: () => handleGenerateAIExample(),
        actionName: "Linguistic Example Framer"
      });

      if (!response.ok) {
        let errMsg = "Linguistic service response error";
        try {
          const errData = await response.json();
          if (errData && errData.error) {
            errMsg = errData.error;
          }
        } catch (_) {}
        throw new Error(errMsg);
      }

      const data = await response.json();
      if (data && data.text) {
        let text = data.text.trim();
        if (text.includes("```")) {
          text = text.replace(/```json\s*/i, "").replace(/```/g, "").trim();
        }

        const parsed = JSON.parse(text);
        if (parsed.sentence && parsed.translation) {
          const cardDocRef = doc(db, "users", userProfile.uid, "flashcards", currentCard.id);
          await updateDoc(cardDocRef, {
            exampleSentence: parsed.sentence,
            exampleTranslation: parsed.translation,
            examplePronunciation: parsed.pronunciation || parsed.sentence,
          });
        } else {
          throw new Error("Missing properties in JSON payload");
        }
      } else {
        throw new Error("Empty response from language engine");
      }
    } catch (err: any) {
      console.error(err);
      setGenerationError("AI is calibrating. Click to retry generating example!");
    } finally {
      setIsGeneratingExample(false);
    }
  };

  // Create a new custom flashcard
  const handleCreateCard = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile?.uid || !newWord || !newTranslation) return;

    try {
      const flashcardsColRef = collection(db, "users", userProfile.uid, "flashcards");
      await addDoc(flashcardsColRef, {
        word: newWord.trim(),
        translation: newTranslation.trim(),
        pronunciation: newPronunciation.trim() || newWord.trim(),
        exampleSentence: "",
        exampleTranslation: "",
        examplePronunciation: "",
        language: selectedLanguageName,
        level: newLevel,
        starred: false,
        custom: true,
        createdAt: Date.now(),
      });

      // Clear form values
      setNewWord("");
      setNewTranslation("");
      setNewPronunciation("");
    } catch (err) {
      console.error("Failed to add custom flashcard:", err);
      handleFirestoreError(err, OperationType.CREATE, `users/${userProfile.uid}/flashcards`);
    }
  };

  // Update existing card details
  const handleUpdateCard = async (cardId: string) => {
    if (!userProfile?.uid) return;

    try {
      const cardDocRef = doc(db, "users", userProfile.uid, "flashcards", cardId);
      await updateDoc(cardDocRef, {
        word: editWord.trim(),
        translation: editTranslation.trim(),
        pronunciation: editPronunciation.trim(),
        level: editLevel,
      });

      setEditingCardId(null);
    } catch (err) {
      console.error("Failed to update flashcard:", err);
      handleFirestoreError(err, OperationType.UPDATE, `users/${userProfile.uid}/flashcards/${cardId}`);
    }
  };

  // Start editing mode for a card
  const startEditing = (card: any) => {
    setEditingCardId(card.id);
    setEditWord(card.word);
    setEditTranslation(card.translation);
    setEditPronunciation(card.pronunciation);
    setEditLevel(card.level);
  };

  // Delete card from Firestore
  const handleDeleteCard = async (cardId: string) => {
    if (!userProfile?.uid) return;

    try {
      const cardDocRef = doc(db, "users", userProfile.uid, "flashcards", cardId);
      await deleteDoc(cardDocRef);
    } catch (err) {
      console.error("Failed to delete flashcard:", err);
      handleFirestoreError(err, OperationType.DELETE, `users/${userProfile.uid}/flashcards/${cardId}`);
    }
  };

  // Filter firestore cards list for management interface
  const managedCardsList = useMemo(() => {
    return firestoreCards.filter((card) => {
      const matchesLanguage = card.language.toLowerCase() === selectedLanguageName.toLowerCase();
      const matchesSearch =
        manageSearch === "" ||
        card.word.toLowerCase().includes(manageSearch.toLowerCase()) ||
        card.translation.toLowerCase().includes(manageSearch.toLowerCase());
      return matchesLanguage && matchesSearch;
    });
  }, [firestoreCards, selectedLanguageName, manageSearch]);

  const activeCustomExample = currentCard && currentCard.exampleSentence ? {
    sentence: currentCard.exampleSentence,
    translation: currentCard.exampleTranslation,
    pronunciation: currentCard.examplePronunciation || currentCard.exampleSentence,
  } : null;

  return (
    <div className="max-w-[650px] mx-auto space-y-6 py-4 animate-fade-in font-sans">
      {/* 1. Header & Navigation info */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-[#0f241d10] pb-4 gap-3">
        <div>
          <h2 className="text-2xl font-sans font-semibold tracking-tight font-medium text-[#0f241d]">
            Vocabulary Cards
          </h2>
          <p className="text-[10px] font-mono uppercase tracking-wider text-[#0f241d50] mt-0.5">
            Dynamic Language Training • {firestoreCards.length} cards in cloud database
          </p>
        </div>

        {/* Study Mode vs Manage Deck toggles */}
        <div className="flex border border-[#0f241d15] bg-[#e8f0eb] p-0.5 font-mono text-[9px] uppercase tracking-wider">
          <button
            onClick={() => setViewMode("study")}
            className={`px-3 py-1 cursor-pointer transition-colors ${
              viewMode === "study" ? "bg-[#0f241d] text-white" : "text-[#0f241d60] hover:text-[#0f241d]"
            }`}
          >
            Study
          </button>
          <button
            onClick={() => setViewMode("manage")}
            className={`px-3 py-1 cursor-pointer transition-colors ${
              viewMode === "manage" ? "bg-[#0f241d] text-white" : "text-[#0f241d60] hover:text-[#0f241d]"
            }`}
          >
            Manage Deck
          </button>
        </div>
      </div>

      {/* 2. Interactive Language Picker tabs */}
      <div className="w-full overflow-x-auto pb-2 flex gap-2 no-scrollbar border-b border-[#0f241d05]">
        {MULTILINGUAL_DATA.map((lang) => (
          <button
            key={lang.id}
            onClick={() => setSelectedLanguageId(lang.id)}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-mono border transition-all cursor-pointer whitespace-nowrap ${
              selectedLanguageId === lang.id
                ? "bg-[#0f241d] text-white border-[#0f241d]"
                : "bg-white text-[#0f241d70] border-[#0f241d12] hover:border-[#0f241d40]"
            }`}
          >
            <span>{lang.flag}</span>
            <span>{lang.name}</span>
          </button>
        ))}
      </div>

      {/* Loading state indicator */}
      {loadingCards && (
        <div className="bg-white border border-[#0f241d15] p-12 text-center space-y-4">
          <RefreshCw className="w-8 h-8 text-[#2d7a64] mx-auto animate-spin" />
          <h3 className="font-sans font-semibold tracking-tight text-lg text-[#0f241d]">Synchronizing with database...</h3>
        </div>
      )}

      {/* STUDY MODE CONTAINER */}
      {!loadingCards && viewMode === "study" && (
        <>
          {/* Level Filters tabs */}
          <div className="flex justify-end">
            <div className="flex bg-[#e8f0eb] border border-[#0f241d10] p-1 gap-1">
              <button
                onClick={() => setSelectedLevel("all")}
                className={`px-3 py-1 text-[9px] font-mono uppercase tracking-wider transition-colors cursor-pointer ${
                  selectedLevel === "all" ? "bg-[#0f241d] text-white" : "text-[#0f241d60] hover:text-[#0f241d]"
                }`}
              >
                All
              </button>
              <button
                onClick={() => setSelectedLevel("Beginner")}
                className={`px-3 py-1 text-[9px] font-mono uppercase tracking-wider transition-colors cursor-pointer ${
                  selectedLevel === "Beginner" ? "bg-[#0f241d] text-white" : "text-[#0f241d60] hover:text-[#0f241d]"
                }`}
              >
                A1/A2
              </button>
              <button
                onClick={() => setSelectedLevel("Intermediate")}
                className={`px-3 py-1 text-[9px] font-mono uppercase tracking-wider transition-colors cursor-pointer ${
                  selectedLevel === "Intermediate" ? "bg-[#0f241d] text-white" : "text-[#0f241d60] hover:text-[#0f241d]"
                }`}
              >
                B1/B2
              </button>
              <button
                onClick={() => setSelectedLevel("Advanced")}
                className={`px-3 py-1 text-[9px] font-mono uppercase tracking-wider transition-colors cursor-pointer ${
                  selectedLevel === "Advanced" ? "bg-[#0f241d] text-white" : "text-[#0f241d60] hover:text-[#0f241d]"
                }`}
              >
                C1/C2
              </button>
            </div>
          </div>

          {deck.length === 0 ? (
            <div className="bg-white border border-[#0f241d15] p-12 text-center space-y-4">
              <Award className="w-10 h-10 text-[#2d7a64] mx-auto animate-pulse" />
              <h3 className="font-sans font-semibold tracking-tight text-xl">No cards found</h3>
              <p className="text-xs text-[#0f241d50] max-w-xs mx-auto">
                No vocabulary found for {selectedLanguageName} at the selected level. Add some cards in 'Manage Deck'!
              </p>
            </div>
          ) : (
            currentCard && (
              <>
                {/* The Flashcard Component */}
                <div className="relative w-full aspect-[4/5] max-h-[400px] perspective-1000 group">
                  {/* Side Arrows for Desktop */}
                  <button
                    onClick={prevCard}
                    disabled={deck.length <= 1}
                    className="absolute -left-16 top-1/2 -translate-y-1/2 w-10 h-10 border border-[#0f241d] bg-white hover:bg-[#e8f0eb] text-[#0f241d] flex items-center justify-center cursor-pointer transition-all active:scale-95 disabled:opacity-25 disabled:pointer-events-none hidden md:flex"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <button
                    onClick={nextCard}
                    disabled={deck.length <= 1}
                    className="absolute -right-16 top-1/2 -translate-y-1/2 w-10 h-10 border border-[#0f241d] bg-white hover:bg-[#e8f0eb] text-[#0f241d] flex items-center justify-center cursor-pointer transition-all active:scale-95 disabled:opacity-25 disabled:pointer-events-none hidden md:flex"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>

                  {/* Inner Flipped Card */}
                  <div
                    onClick={handleFlip}
                    className={`flip-card-inner relative w-full h-full preserve-3d cursor-pointer transition-transform duration-500 ${
                      isAnimating ? "opacity-0 scale-95" : ""
                    } ${isFlipped ? "is-flipped rotate-y-180" : ""}`}
                  >
                    {/* FRONT SIDE */}
                    <div className="backface-hidden absolute inset-0 bg-white border border-[#0f241d15] p-8 flex flex-col items-center justify-center shadow-xs">
                      <div className="absolute top-6 left-6 flex gap-2">
                        <span className="px-3 py-1 bg-[#f3f7f5] border border-[#0f241d10] text-[9px] font-mono uppercase tracking-wider text-[#0f241d60]">
                          {currentCard.language}
                        </span>
                        <span className="px-3 py-1 bg-[#f3f7f5] border border-[#0f241d10] text-[9px] font-mono uppercase tracking-wider text-[#0f241d60]">
                          {currentCard.level}
                        </span>
                        {currentCard.custom && (
                          <span className="px-3 py-1 bg-amber-50 border border-amber-200 text-[9px] font-mono uppercase tracking-wider text-amber-700">
                            Custom
                          </span>
                        )}
                      </div>

                      <div className="text-center space-y-6 w-full">
                        <h3 className="text-4xl md:text-5xl font-sans font-semibold tracking-tight font-medium text-[#0f241d] tracking-tight select-all">
                          {currentCard.word}
                        </h3>
                        <button
                          onClick={(e) => playPronunciation(e, currentCard.word, currentCard.language)}
                          className="mx-auto w-14 h-14 rounded-full border border-[#0f241d] bg-white flex items-center justify-center hover:bg-[#e8f0eb] transition-colors cursor-pointer group/btn"
                        >
                          <Volume2 className="w-5 h-5 text-[#0f241d] group-hover/btn:scale-105 transition-transform" />
                        </button>
                      </div>

                      <p className="absolute bottom-6 text-[9px] font-mono tracking-widest uppercase text-[#0f241d40]">
                        Tap card to reveal translation
                      </p>
                    </div>

                    {/* BACK SIDE */}
                    <div className="backface-hidden rotate-y-180 absolute inset-0 bg-white border border-[#0f241d15] p-6 flex flex-col items-center shadow-xs">
                      <div className="w-full flex justify-between items-start mb-2">
                        <div className="w-8 h-8 border border-[#0f241d10] bg-[#f3f7f5] flex items-center justify-center text-[#0f241d]">
                          <BookOpen className="w-4 h-4" />
                        </div>
                        <button
                          onClick={(e) => toggleStar(e, currentCard)}
                          className={`w-8 h-8 border flex items-center justify-center transition-colors cursor-pointer active:scale-95 ${
                            currentCard.starred
                              ? "bg-[#f3f7f5] border-yellow-500 text-yellow-500"
                              : "bg-white border-[#0f241d15] text-[#0f241d50]"
                          }`}
                        >
                          ★
                        </button>
                      </div>

                      {/* Back side details */}
                      <div className="w-full space-y-3 flex-1 overflow-y-auto pr-1 custom-scrollbar">
                        <div className="text-center mb-1">
                          <h4 className="text-[9px] uppercase tracking-widest text-[#0f241d50] font-mono mb-0.5">
                            Translation
                          </h4>
                          <p className="text-2xl font-sans font-semibold tracking-tight font-medium text-[#0f241d]">
                            {currentCard.translation}
                          </p>
                        </div>

                        <div className="p-3.5 bg-[#e8f0eb] border border-[#0f241d08] w-full">
                          <h4 className="text-[8px] font-mono text-[#0f241d50] uppercase tracking-wider mb-0.5">
                            Pronunciation Guide
                          </h4>
                          <p className="text-xs font-semibold text-[#0f241d]">
                            {currentCard.pronunciation}
                          </p>
                        </div>

                        {/* Automatic examples backend generator section */}
                        <div className="p-3.5 bg-[#e8f0eb] border border-[#0f241d08] w-full flex flex-col gap-2">
                          <div className="flex justify-between items-center">
                            <h4 className="text-[8px] font-mono text-[#0f241d50] uppercase tracking-wider">
                              Illustrative Sentence (AI)
                            </h4>

                            <button
                              onClick={handleGenerateAIExample}
                              disabled={isGeneratingExample}
                              className="flex items-center gap-1 text-[8px] font-mono uppercase tracking-wider text-[#2d7a64] hover:text-[#0f241d] transition-colors cursor-pointer"
                            >
                              {isGeneratingExample ? (
                                <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                              ) : (
                                <Sparkles className="w-2.5 h-2.5" />
                              )}
                              <span>{activeCustomExample ? "Regenerate" : "Generate Automatic Ex"}</span>
                            </button>
                          </div>

                          {activeCustomExample ? (
                            <div className="space-y-1">
                              <p className="text-xs text-[#0f241d] leading-relaxed select-all">
                                "{activeCustomExample.sentence}"
                              </p>
                              <p className="text-[10px] text-[#0f241d50] leading-relaxed">
                                "{activeCustomExample.translation}"
                              </p>
                              <p className="text-[9px] font-mono text-[#2d7a64]">
                                Pronun: {activeCustomExample.pronunciation}
                              </p>
                            </div>
                          ) : (
                            <div className="py-2 text-center">
                              <p className="text-[10px] text-[#0f241d40]">
                                No example loaded yet. Tap 'Generate Automatic Ex' to load one!
                              </p>
                            </div>
                          )}

                          {generationError && (
                            <p className="text-[8px] font-mono text-red-500 mt-1">{generationError}</p>
                          )}
                        </div>
                      </div>

                      {/* Got It and Again Buttons */}
                      <div className="mt-3 pt-1.5 flex gap-3 w-full">
                        <button
                          onClick={nextCard}
                          className="flex-1 py-2.5 border border-red-500/30 hover:border-red-500 bg-white hover:bg-red-50 text-red-600 font-mono text-[10px] uppercase tracking-widest transition-colors cursor-pointer"
                        >
                          Again
                        </button>
                        <button
                          onClick={handleGotIt}
                          className="flex-1 py-2.5 bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-[10px] uppercase tracking-widest transition-colors cursor-pointer border border-[#0f241d]"
                        >
                          Got it!
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Navigation & Shuffling Controls */}
                <div className="mt-4 flex gap-4 w-full max-w-sm justify-center mx-auto items-center">
                  <button
                    onClick={prevCard}
                    disabled={deck.length <= 1}
                    className="w-11 h-11 border border-[#0f241d12] hover:border-[#0f241d] bg-white hover:bg-[#e8f0eb] text-[#0f241d] flex items-center justify-center transition-all cursor-pointer active:scale-95 disabled:opacity-20 disabled:pointer-events-none"
                    title="Previous Word"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <span className="text-[10px] font-mono text-[#0f241d55] uppercase tracking-wider">
                    {currentIndex + 1} of {deck.length}
                  </span>

                  <button
                    onClick={shuffleDeck}
                    disabled={deck.length <= 1}
                    className="w-11 h-11 border border-[#0f241d12] hover:border-[#0f241d] bg-white hover:bg-[#e8f0eb] text-[#0f241d] flex items-center justify-center transition-all cursor-pointer active:scale-95 disabled:opacity-20"
                    title="Shuffle Deck"
                  >
                    <Shuffle className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={nextCard}
                    disabled={deck.length <= 1}
                    className="w-11 h-11 border border-[#0f241d12] hover:border-[#0f241d] bg-white hover:bg-[#e8f0eb] text-[#0f241d] flex items-center justify-center transition-all cursor-pointer active:scale-95 disabled:opacity-20 disabled:pointer-events-none"
                    title="Next Word"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </>
            )
          )}
        </>
      )}

      {/* MANAGE MODE CONTAINER (CRUD Operations) */}
      {!loadingCards && viewMode === "manage" && (
        <div className="space-y-6">
          {/* Add New Custom Flashcard Form */}
          <form
            onSubmit={handleCreateCard}
            className="bg-white border border-[#0f241d15] p-6 space-y-4 shadow-xs"
          >
            <div className="flex items-center gap-2 border-b border-[#0f241d10] pb-2">
              <Plus className="w-4 h-4 text-[#0f241d]" />
              <h3 className="font-sans font-semibold tracking-tight text-lg font-medium text-[#0f241d]">
                Add Custom Flashcard ({selectedLanguageName})
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-wider text-[#0f241d60] mb-1">
                  Word or Phrase *
                </label>
                <input
                  type="text"
                  required
                  value={newWord}
                  onChange={(e) => setNewWord(e.target.value)}
                  placeholder="e.g. Swagatha"
                  className="w-full bg-[#f3f7f5] border border-[#0f241d15] p-2.5 text-xs font-mono text-[#0f241d] outline-none focus:border-[#0f241d]"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono uppercase tracking-wider text-[#0f241d60] mb-1">
                  English Translation *
                </label>
                <input
                  type="text"
                  required
                  value={newTranslation}
                  onChange={(e) => setNewTranslation(e.target.value)}
                  placeholder="e.g. Welcome"
                  className="w-full bg-[#f3f7f5] border border-[#0f241d15] p-2.5 text-xs font-mono text-[#0f241d] outline-none focus:border-[#0f241d]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-wider text-[#0f241d60] mb-1">
                  Pronunciation guide
                </label>
                <input
                  type="text"
                  value={newPronunciation}
                  onChange={(e) => setNewPronunciation(e.target.value)}
                  placeholder="e.g. Swah-gah-thah"
                  className="w-full bg-[#f3f7f5] border border-[#0f241d15] p-2.5 text-xs font-mono text-[#0f241d] outline-none focus:border-[#0f241d]"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono uppercase tracking-wider text-[#0f241d60] mb-1">
                  Level
                </label>
                <select
                  value={newLevel}
                  onChange={(e) => setNewLevel(e.target.value)}
                  className="w-full bg-[#f3f7f5] border border-[#0f241d15] p-2.5 text-xs font-mono text-[#0f241d] outline-none focus:border-[#0f241d]"
                >
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-[10px] uppercase tracking-widest py-3 transition-colors cursor-pointer"
            >
              Add Card to Cloud
            </button>
          </form>

          {/* List and Search Cards in subcollection */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <h4 className="font-sans font-semibold tracking-tight text-lg font-medium text-[#0f241d]">
                Flashcards in {selectedLanguageName} ({managedCardsList.length})
              </h4>

              {/* Search Bar */}
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#0f241d40]" />
                <input
                  type="text"
                  value={manageSearch}
                  onChange={(e) => setManageSearch(e.target.value)}
                  placeholder="Search cards..."
                  className="w-full bg-white border border-[#0f241d15] py-1.5 pl-8 pr-3 text-xs font-mono text-[#0f241d] outline-none focus:border-[#0f241d]"
                />
              </div>
            </div>

            {managedCardsList.length === 0 ? (
              <div className="bg-white border border-[#0f241d10] p-8 text-center text-[#0f241d50] text-xs">
                No cards match your current query or language. Add a custom card above to get started!
              </div>
            ) : (
              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1 custom-scrollbar">
                {managedCardsList.map((card) => {
                  const isEditing = editingCardId === card.id;

                  return (
                    <div
                      key={card.id}
                      className="bg-white border border-[#0f241d15] p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition-all"
                    >
                      {isEditing ? (
                        /* Inline Edit Form */
                        <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[8px] font-mono uppercase text-[#0f241d50]">Word</label>
                            <input
                              type="text"
                              value={editWord}
                              onChange={(e) => setEditWord(e.target.value)}
                              className="w-full bg-[#f3f7f5] border border-[#0f241d15] p-1.5 text-xs font-mono text-[#0f241d] outline-none"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[8px] font-mono uppercase text-[#0f241d50]">Translation</label>
                            <input
                              type="text"
                              value={editTranslation}
                              onChange={(e) => setEditTranslation(e.target.value)}
                              className="w-full bg-[#f3f7f5] border border-[#0f241d15] p-1.5 text-xs font-mono text-[#0f241d] outline-none"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[8px] font-mono uppercase text-[#0f241d50]">Pronunciation</label>
                            <input
                              type="text"
                              value={editPronunciation}
                              onChange={(e) => setEditPronunciation(e.target.value)}
                              className="w-full bg-[#f3f7f5] border border-[#0f241d15] p-1.5 text-xs font-mono text-[#0f241d] outline-none"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[8px] font-mono uppercase text-[#0f241d50]">Level</label>
                            <select
                              value={editLevel}
                              onChange={(e) => setEditLevel(e.target.value)}
                              className="w-full bg-[#f3f7f5] border border-[#0f241d15] p-1.5 text-xs font-mono text-[#0f241d] outline-none"
                            >
                              <option value="Beginner">Beginner</option>
                              <option value="Intermediate">Intermediate</option>
                              <option value="Advanced">Advanced</option>
                            </select>
                          </div>

                          <div className="sm:col-span-2 flex justify-end gap-2 mt-2">
                            <button
                              type="button"
                              onClick={() => setEditingCardId(null)}
                              className="px-3 py-1.5 border border-[#0f241d15] text-[9px] font-mono uppercase tracking-wider text-[#0f241d60] hover:text-[#0f241d]"
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              onClick={() => handleUpdateCard(card.id)}
                              className="px-3 py-1.5 bg-[#0f241d] text-[#f3f7f5] text-[9px] font-mono uppercase tracking-wider"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      ) : (
                        /* Standard View Row */
                        <>
                          <div className="space-y-1 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-sans font-semibold tracking-tight font-medium text-base text-[#0f241d]">
                                {card.word}
                              </span>
                              <span className="px-1.5 py-0.5 bg-[#f3f7f5] border border-[#0f241d10] text-[8px] font-mono uppercase tracking-wider text-[#0f241d50]">
                                {card.level}
                              </span>
                              {card.custom && (
                                <span className="px-1.5 py-0.5 bg-amber-50 border border-amber-200 text-[8px] font-mono uppercase tracking-wider text-amber-700">
                                  Custom
                                </span>
                              )}
                              {card.starred && (
                                <span className="text-yellow-500 text-[10px]">★</span>
                              )}
                            </div>
                            <p className="text-xs text-[#0f241d60]">{card.translation}</p>
                            <p className="text-[9px] font-mono text-[#0f241d40]">Pronun: {card.pronunciation}</p>
                          </div>

                          <div className="flex gap-2 w-full md:w-auto justify-end">
                            <button
                              type="button"
                              onClick={() => startEditing(card)}
                              className="p-2 border border-[#0f241d15] text-[#0f241d60] hover:text-[#0f241d] hover:border-[#0f241d] transition-colors cursor-pointer"
                              title="Edit Card"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteCard(card.id)}
                              className="p-2 border border-red-200 hover:border-red-500 text-red-500 hover:bg-red-50 transition-colors cursor-pointer"
                              title="Delete Card"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
