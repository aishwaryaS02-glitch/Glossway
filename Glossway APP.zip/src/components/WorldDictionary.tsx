import { useState, useMemo } from "react";
import { MULTILINGUAL_DATA } from "../data/multilingualHubData";
import { UserProfile } from "../types";
import { db } from "../firebase";
import { collection, addDoc } from "firebase/firestore";
import { apiFetch } from "../utils/api";
import {
  Search,
  BookOpen,
  Volume2,
  Sparkles,
  Plus,
  ArrowRight,
  Check,
  RefreshCw,
  Info,
  Languages,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface WorldDictionaryProps {
  userProfile: UserProfile | null;
  onNavigate: (screen: string) => void;
  selectedLanguageId: string;
  onSelectLanguage: (langId: string) => void;
  onUpdateUserProfile?: (updates: Partial<UserProfile>) => void;
  searchQuery?: string;
  onSearchQueryChange?: (query: string) => void;
}

interface DictionaryEntry {
  id: string;
  word: string;
  translation: string;
  pronunciation: string;
  type: "Vocabulary" | "Phrase" | "Grammar";
  extraDetail?: string; // part of speech or context
}

export default function WorldDictionary({
  userProfile,
  onNavigate,
  selectedLanguageId,
  onSelectLanguage,
  // onUpdateUserProfile,
  searchQuery: propSearchQuery,
  onSearchQueryChange: propOnSearchQueryChange,
}: WorldDictionaryProps) {
  const [localSearchQuery, setLocalSearchQuery] = useState("");
  const searchQuery = propSearchQuery !== undefined ? propSearchQuery : localSearchQuery;
  const setSearchQuery = propOnSearchQueryChange !== undefined ? propOnSearchQueryChange : setLocalSearchQuery;

  const [selectedEntry, setSelectedEntry] = useState<DictionaryEntry | null>(null);




  // AI sentence generation states
  const [isGeneratingSentences, setIsGeneratingSentences] = useState(false);
  const [generatedSentences, setGeneratedSentences] = useState<string>("");
  const [generationError, setGenerationError] = useState<string>("");

  // Firestore add flashcard status
  const [isAddingToFlashcards, setIsAddingToFlashcards] = useState(false);
  const [addSuccess, setAddSuccess] = useState(false);

  // Find active language data
  const activeLanguage = useMemo(() => {
    return MULTILINGUAL_DATA.find((lang) => lang.id === selectedLanguageId) || MULTILINGUAL_DATA[0];
  }, [selectedLanguageId]);

  // Map all dictionary entries for active language
  const dictionaryEntries = useMemo(() => {
    const entries: DictionaryEntry[] = [];

    // Add beginner vocabulary
    activeLanguage.beginner.forEach((v, idx) => {
      entries.push({
        id: `vocab_${idx}`,
        word: v.word,
        translation: v.translation,
        pronunciation: v.pronunciation,
        type: "Vocabulary",
        extraDetail: v.partOfSpeech,
      });
    });

    // Add middleware phrases
    activeLanguage.middleware.forEach((p, idx) => {
      entries.push({
        id: `phrase_${idx}`,
        word: p.phrase,
        translation: p.translation,
        pronunciation: p.pronunciation,
        type: "Phrase",
        extraDetail: p.context,
      });
    });

    // Add advanced grammar rule examples as sentences
    activeLanguage.pro.forEach((r, idx) => {
      entries.push({
        id: `grammar_${idx}`,
        word: r.ruleName,
        translation: r.explanation,
        pronunciation: r.structure,
        type: "Grammar",
      });
    });

    return entries;
  }, [activeLanguage]);

  // Filter entries based on search
  const filteredEntries = useMemo(() => {
    if (!searchQuery.trim()) return dictionaryEntries;

    const lowerQuery = searchQuery.toLowerCase();
    return dictionaryEntries.filter(
      (entry) =>
        entry.word.toLowerCase().includes(lowerQuery) ||
        entry.translation.toLowerCase().includes(lowerQuery) ||
        entry.pronunciation.toLowerCase().includes(lowerQuery)
    );
  }, [dictionaryEntries, searchQuery]);

  const handleSpeak = (text: string) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);

    const activeVoice = (window as any).__activeVoice;
    const activeLangTag = (window as any).__activeLanguageTag;

    if (activeVoice) {
      utterance.voice = activeVoice;
    }
    utterance.lang = activeLangTag || "en-US";
    utterance.rate = 0.85;
    window.speechSynthesis.speak(utterance);
  };

  // Generate 3 more illustrative sentences using Gemini API
  const handleGenerateSentences = async (entry: DictionaryEntry) => {
    setIsGeneratingSentences(true);
    setGeneratedSentences("");
    setGenerationError("");

    try {
      const response = await apiFetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: `Generate exactly three illustrative conversational example sentences in ${activeLanguage.name} using the word/phrase/rule "${entry.word}" (meaning: "${entry.translation}").
For each sentence, provide:
1. The sentence in ${activeLanguage.name} (with bold formatting **sentence**)
2. Its English translation
3. An English phonetic pronunciation guide (especially important for non-Latin scripts)

Format your output as an elegant, clean markdown numbered list. Keep sentences practical and helpful.`,
          modelType: "gemini",
          language: activeLanguage.name,
        }),
        retryAction: () => handleGenerateSentences(entry),
        actionName: "Linguistic Example Framer"
      });

      const data = await response.json();
      if (response.ok && data && data.text) {
        setGeneratedSentences(data.text);
      } else {
        throw new Error(data.error || "Failed to generate sentences from AI engine.");
      }
    } catch (err: any) {
      console.error(err);
      setGenerationError(err.message || "Connection failed. Please ensure the server is active.");
    } finally {
      setIsGeneratingSentences(false);
    }
  };

  // Add the dictionary entry directly to user's Firestore flashcard collection
  const handleAddToFlashcards = async (entry: DictionaryEntry) => {
    if (!userProfile?.uid) return;
    setIsAddingToFlashcards(true);
    setAddSuccess(false);

    try {
      const flashcardsColRef = collection(db, "users", userProfile.uid, "flashcards");
      
      // Attempt to find any parsed example sentence from our generated block if present
      let exampleSentence = "";
      let exampleTranslation = "";
      let examplePronunciation = "";

      if (generatedSentences) {
        // Simple heuristic parsing or fallback to default empty values
        exampleSentence = `Generated sentences available under custom dictionary review`;
      }

      await addDoc(flashcardsColRef, {
        word: entry.word,
        translation: entry.translation,
        pronunciation: entry.pronunciation,
        exampleSentence: exampleSentence,
        exampleTranslation: exampleTranslation,
        examplePronunciation: examplePronunciation,
        language: activeLanguage.name,
        level: entry.type === "Vocabulary" ? "Beginner" : entry.type === "Phrase" ? "Intermediate" : "Advanced",
        starred: false,
        custom: true,
        createdAt: Date.now(),
      });

      setAddSuccess(true);
      setTimeout(() => setAddSuccess(false), 3000);
    } catch (err) {
      console.error("Failed to add custom flashcard:", err);
    } finally {
      setIsAddingToFlashcards(false);
    }
  };

  const handleEntryClick = (entry: DictionaryEntry) => {
    setSelectedEntry(entry);
    setGeneratedSentences("");
    setGenerationError("");
    setAddSuccess(false);
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12 font-sans relative">

      {/* 1. View Header */}
      <div className="border-b border-[#0f241d10] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[#2d7a64]">
            <Languages className="w-4 h-4" />
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-semibold">
              Global Lexicon Explorer
            </span>
          </div>
          <h2 className="font-sans font-semibold tracking-tight text-3xl font-medium text-[#0f241d] mt-1">
            World Dictionary
          </h2>
          <p className="text-xs text-[#0f241d50] mt-0.5">
            Search hundreds of vocabulary terms, phrases, and grammatical components. Generate context sentences and add cards to your cloud study deck.
          </p>
        </div>

        {/* View Cards Bridge */}
        <button
          onClick={() => onNavigate("cards")}
          className="px-4 py-2 border border-[#0f241d] hover:bg-[#e8f0eb] text-[#0f241d] text-[10px] font-mono uppercase tracking-widest cursor-pointer transition-colors flex items-center gap-1"
        >
          Study Active Deck <ArrowRight className="w-3.5 h-3.5 text-[#2d7a64]" />
        </button>
      </div>

      {/* 2. Language Picker Tabs */}
      <div className="w-full overflow-x-auto pb-2 flex gap-2 no-scrollbar border-b border-[#0f241d05]">
        {MULTILINGUAL_DATA.map((lang) => (
          <button
            key={lang.id}
            onClick={() => {
              onSelectLanguage(lang.id);
              setSelectedEntry(null);
              setGeneratedSentences("");
              setGenerationError("");
            }}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-mono border transition-all cursor-pointer whitespace-nowrap ${
              selectedLanguageId === lang.id
                ? "bg-[#0f241d] text-white border-[#0f241d]"
                : "bg-white text-[#0f241d70] border-[#0f241d12] hover:border-[#0f241d40]"
            }`}
          >
            <span>{lang.flag}</span>
            <span>{lang.name}</span>
          </button>
        ))}
      </div>

      {/* 3. Grid Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Side: Search list */}
        <div className="lg:col-span-5 space-y-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0f241d40]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search words, phrases, meanings..."
                className="w-full bg-white border border-[#0f241d15] py-2.5 pl-9 pr-4 text-xs font-mono text-[#0f241d] outline-none focus:border-[#0f241d] placeholder:text-[#0f241d40]"
              />
            </div>
            <button
              type="submit"
              className="px-4 bg-[#0f241d] hover:bg-[#25332e] text-white text-[10px] font-mono uppercase tracking-widest cursor-pointer transition-colors shrink-0 border border-black flex items-center gap-1.5 font-bold"
            >
              <Search className="w-3.5 h-3.5 text-[#2d7a64]" />
              <span>Search</span>
            </button>
          </form>

          <div className="bg-white border border-[#0f241d15] max-h-[500px] overflow-y-auto custom-scrollbar">
            {filteredEntries.length === 0 ? (
              <div className="p-8 text-center text-[#0f241d50] text-xs font-sans font-semibold tracking-tight">
                No entries match your search query. Try typing another term.
              </div>
            ) : (
              <div className="divide-y divide-[#0f241d08]">
                <AnimatePresence mode="popLayout">
                  {filteredEntries.map((entry) => (
                    <motion.div
                      key={entry.id}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
                      onClick={() => handleEntryClick(entry)}
                      className={`p-4 cursor-pointer transition-colors flex justify-between items-center ${
                        selectedEntry?.id === entry.id
                          ? "bg-[#e8f0eb]"
                          : "hover:bg-[#f3f7f5]"
                      }`}
                    >
                      <div className="space-y-1 pr-4 truncate">
                        <h4 className="font-sans font-semibold tracking-tight font-medium text-[#0f241d] text-sm truncate">
                          {entry.word}
                        </h4>
                        <p className="text-xs text-[#0f241d50] truncate">{entry.translation}</p>
                      </div>
                      <span
                        className={`text-[8px] font-mono uppercase tracking-wider px-2 py-0.5 border shrink-0 ${
                          entry.type === "Vocabulary"
                            ? "bg-emerald-50 border-emerald-100 text-emerald-700"
                            : entry.type === "Phrase"
                            ? "bg-purple-50 border-purple-100 text-purple-700"
                            : "bg-amber-50 border-amber-100 text-amber-700"
                        }`}
                      >
                        {entry.type}
                      </span>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Detailed inspect card & actions */}
        <div className="lg:col-span-7">
          {selectedEntry ? (
            <div className="bg-white border border-[#0f241d15] p-6 md:p-8 space-y-6">
              {/* Word, Pronunciation, and Speak control */}
              <div className="space-y-4">
                <div className="flex justify-between items-start gap-4 flex-wrap">
                  <span className="px-3 py-1 bg-[#e8f0eb] border border-[#0f241d10] text-[9px] font-mono uppercase tracking-wider text-[#0f241d60]">
                    {selectedEntry.type}
                  </span>
                  {selectedEntry.extraDetail && (
                    <span className="px-3 py-1 bg-neutral-50 border border-neutral-200 text-[9px] font-mono uppercase tracking-wider text-neutral-500">
                      {selectedEntry.extraDetail}
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <h3 className="text-3xl md:text-4xl font-sans font-semibold tracking-tight font-medium text-[#0f241d] tracking-tight">
                      {selectedEntry.word}
                    </h3>
                    <p className="text-xs text-emerald-700 font-mono">
                      {selectedEntry.pronunciation}
                    </p>
                  </div>

                  <button
                    onClick={() => handleSpeak(selectedEntry.word)}
                    className="w-12 h-12 rounded-full border border-[#0f241d15] bg-[#f3f7f5] hover:bg-[#e8f0eb] flex items-center justify-center transition-all cursor-pointer hover:scale-105 active:scale-95 group"
                    title="Listen Pronunciation"
                  >
                    <Volume2 className="w-5 h-5 text-[#0f241d] group-hover:text-black" />
                  </button>
                </div>
              </div>

              {/* Translation Display */}
              <div className="p-4 bg-[#f3f7f5] border border-[#0f241d08]">
                <span className="text-[8px] font-mono text-[#0f241d40] uppercase tracking-wider block mb-1">
                  Translation
                </span>
                <p className="font-sans font-semibold tracking-tight text-lg text-[#0f241d]">
                  {selectedEntry.translation}
                </p>
              </div>

              {/* AI sentence generation block */}
              <div className="space-y-3">
                <div className="flex justify-between items-center border-b border-[#0f241d08] pb-2">
                  <span className="text-[9px] font-mono text-[#0f241d50] uppercase tracking-wider flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#2d7a64]" /> Linguistic AI Sentences
                  </span>

                  <button
                    onClick={() => handleGenerateSentences(selectedEntry)}
                    disabled={isGeneratingSentences}
                    className="flex items-center gap-1 text-[9px] font-mono uppercase tracking-wider text-black bg-[#e8f0eb] hover:bg-[#f3f7f5] border border-[#0f241d15] px-2.5 py-1 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {isGeneratingSentences ? (
                      <RefreshCw className="w-3 h-3 animate-spin" />
                    ) : (
                      <Sparkles className="w-3 h-3" />
                    )}
                    <span>{generatedSentences ? "Regenerate" : "Give More Sentences"}</span>
                  </button>
                </div>

                {isGeneratingSentences && (
                  <div className="py-8 text-center space-y-2">
                    <RefreshCw className="w-6 h-6 text-[#2d7a64] mx-auto animate-spin" />
                    <p className="text-[10px] font-mono uppercase text-[#0f241d40] tracking-wider">
                      Framer AI is creating sentence variations...
                    </p>
                  </div>
                )}

                {generatedSentences && !isGeneratingSentences && (
                  <div className="bg-[#f3f7f5] border border-[#0f241d08] p-4 text-xs space-y-3 leading-relaxed whitespace-pre-line text-[#0f241d80] font-sans font-semibold tracking-tight">
                    {generatedSentences}
                  </div>
                )}

                {generationError && !isGeneratingSentences && (
                  <p className="text-xs font-mono text-red-500 bg-red-50 p-3 border border-red-100">
                    {generationError}
                  </p>
                )}

                {!generatedSentences && !isGeneratingSentences && (
                  <p className="text-xs text-[#0f241d40] font-sans font-semibold tracking-tight text-center py-4">
                    Tap "Give More Sentences" to generate conversational variations for this word using Gemini AI.
                  </p>
                )}
              </div>

              {/* Add to study deck action */}
              <div className="pt-4 border-t border-[#0f241d10] flex gap-3">
                <button
                  onClick={() => handleAddToFlashcards(selectedEntry)}
                  disabled={isAddingToFlashcards || addSuccess}
                  className={`flex-1 font-mono text-[10px] uppercase tracking-widest py-3 border transition-all cursor-pointer flex items-center justify-center gap-2 ${
                    addSuccess
                      ? "bg-emerald-600 text-white border-emerald-600 font-bold"
                      : "bg-[#0f241d] hover:bg-[#25332e] text-white border-black"
                  } disabled:opacity-50`}
                >
                  {isAddingToFlashcards ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Adding to Cloud...</span>
                    </>
                  ) : addSuccess ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Successfully Added!</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add to My Flashcards</span>
                    </>
                  )}
                </button>
              </div>

              {/* Learning Portal Navigation Shortcut */}
              <div className="p-3 bg-amber-50 border border-amber-200/40 flex items-start gap-2.5">
                <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div className="text-[11px] text-[#0f241d70]">
                  <p className="font-semibold text-amber-800">Learn in Depth</p>
                  <p className="mt-0.5 leading-relaxed">
                    Want pronunciation voice metrics and tutor breakdowns for this language? Open the{" "}
                    <button
                      onClick={() => onNavigate("learning")}
                      className="font-bold underline text-amber-900 cursor-pointer"
                    >
                      Learning Portal
                    </button>
                    .
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-[#0f241d15] p-12 text-center space-y-4">
              <BookOpen className="w-10 h-10 text-[#2d7a64] mx-auto animate-pulse" />
              <h3 className="font-sans font-semibold tracking-tight text-xl text-[#0f241d]">Select an Entry</h3>
              <p className="text-xs text-[#0f241d40] max-w-xs mx-auto">
                Click on any dictionary entry from the left list to hear pronunciation, inspect translations, generate AI sentence variations, and save to your study deck.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
