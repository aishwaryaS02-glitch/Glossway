
import { motion } from "motion/react";
import { Target, ArrowRight, Plus, Minus } from "lucide-react";

interface DailyGoalProgressProps {
  todaySeconds: number;
  targetMinutes: number;
  onUpdateGoal?: (minutes: number) => void;
  onNavigate?: (screen: string) => void;
}

export default function DailyGoalProgress({
  todaySeconds,
  targetMinutes,
  onUpdateGoal,
  onNavigate,
}: DailyGoalProgressProps) {
  const todayMinutes = Math.round(todaySeconds / 60);
  const percentage = Math.min(100, Math.round((todayMinutes / targetMinutes) * 100));
  const isGoalAchieved = todayMinutes >= targetMinutes;

  // Editorial quote mapping representing the learner's developmental stage today
  const getEditorialQuote = () => {
    if (percentage === 0) {
      return "Every great dialogue begins with a single silent observation. Initiate your study today.";
    }
    if (percentage < 30) {
      return "A modest start. The foundation is laid; consistency is the architect of mastery.";
    }
    if (percentage < 60) {
      return "Halfway to your daily horizon. Let the rhythm of the language guide your focus.";
    }
    if (percentage < 100) {
      return "The goal is in sight. Just a brief moment more of deliberate practice to secure your day's journey.";
    }
    return "Outstanding. You have successfully fulfilled your learning vow for today. The path lies clear.";
  };

  // SVG configuration
  const radius = 50;
  const strokeWidth = 4;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  const handleIncrement = () => {
    if (onUpdateGoal) {
      onUpdateGoal(targetMinutes + 5);
    }
  };

  const handleDecrement = () => {
    if (onUpdateGoal && targetMinutes > 5) {
      onUpdateGoal(targetMinutes - 5);
    }
  };

  return (
    <motion.div
      id="daily-goal-progress-card"
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="bg-white border border-[#0f241d15] p-6 md:p-8 space-y-8 relative overflow-hidden"
    >
      {/* Decorative background visual depth element */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-[#2d7a64]/5 rounded-full filter blur-xl pointer-events-none" />

      {/* Title & Description with Editorial Tone */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-5 border-b border-[#0f241d10]">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-[#2d7a64]">
            <Target className="w-3.5 h-3.5" />
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-bold">
              Journal Target
            </span>
          </div>
          <h3 className="font-sans font-semibold tracking-tight text-2xl font-semibold text-[#0f241d]">
            Daily Goal Progress
          </h3>
          <p className="text-xs text-[#0f241d50]">
            A dedicated visual measure of your deliberate language exploration.
          </p>
        </div>

        {/* Goal Quick Adjuster Widget */}
        <div className="flex items-center gap-3 bg-[#f3f7f5] border border-[#0f241d10] p-1.5 rounded-sm">
          <button
            id="decrement-goal-btn"
            onClick={handleDecrement}
            className="w-7 h-7 flex items-center justify-center hover:bg-[#0f241d10] text-[#0f241d80] hover:text-[#0f241d] transition-colors rounded-xs cursor-pointer"
            title="Decrease Target"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <div className="flex flex-col items-center px-1">
            <span className="text-[8px] font-mono text-[#0f241d40] uppercase tracking-wider font-semibold">
              Goal Minutes
            </span>
            <span className="font-mono text-xs font-bold text-[#0f241d]">
              {targetMinutes}m
            </span>
          </div>
          <button
            id="increment-goal-btn"
            onClick={handleIncrement}
            className="w-7 h-7 flex items-center justify-center hover:bg-[#0f241d10] text-[#0f241d80] hover:text-[#0f241d] transition-colors rounded-xs cursor-pointer"
            title="Increase Target"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main progress content layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        {/* Left Col: Minimalistic Circular Progress Bar */}
        <div className="md:col-span-5 flex flex-col items-center justify-center p-6 bg-[#f3f7f5] border border-[#0f241d05] relative rounded-xs">
          <div className="relative w-40 h-40 flex items-center justify-center">
            {/* SVG Progress Circle */}
            <svg className="w-full h-full transform -rotate-90">
              {/* Back track circle */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                className="stroke-[#0f241d08]"
                strokeWidth={strokeWidth}
                fill="transparent"
              />
              {/* Dynamic filled circle with path animation */}
              <motion.circle
                cx="80"
                cy="80"
                r={radius}
                className={`${
                  isGoalAchieved ? "stroke-emerald-600" : "stroke-[#2d7a64]"
                } transition-colors duration-500`}
                strokeWidth={strokeWidth}
                fill="transparent"
                strokeDasharray={circumference}
                initial={{ strokeDashoffset: circumference }}
                animate={{ strokeDashoffset }}
                transition={{ duration: 1.2, ease: "easeOut" }}
                strokeLinecap="round"
              />
            </svg>

            {/* Central overlay metrics */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-3">
              <motion.span
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className={`text-3xl font-sans font-semibold tracking-tight font-bold tracking-tight ${
                  isGoalAchieved ? "text-emerald-700" : "text-[#0f241d]"
                }`}
              >
                {percentage}%
              </motion.span>
              <span className="text-[8px] font-mono uppercase tracking-[0.2em] text-[#0f241d40] mt-0.5 font-bold">
                {isGoalAchieved ? "Complete ✓" : "Studied"}
              </span>
            </div>
          </div>

          {/* Core ratio values */}
          <div className="mt-3 text-[11px] font-mono text-[#0f241d50]">
            <span className="font-bold text-[#0f241d]">{todayMinutes}m</span> explored / {targetMinutes}m goal
          </div>
        </div>

        {/* Right Col: Philosophical Guidance & Status Breakdown */}
        <div className="md:col-span-7 flex flex-col justify-between h-full space-y-6">
          <div className="space-y-4">
            <span className="text-[9px] font-mono uppercase tracking-[0.25em] text-[#2d7a64] block font-bold">
              Pedagogical Guidance
            </span>
            <p className="text-sm text-[#0f241d80] font-sans font-semibold tracking-tight leading-relaxed">
              "{getEditorialQuote()}"
            </p>
          </div>

          {/* Numerical status checklist */}
          <div className="grid grid-cols-2 gap-6 pt-5 border-t border-[#0f241d08]">
            <div className="space-y-1">
              <span className="text-[9px] font-mono text-[#0f241d40] uppercase tracking-wider block font-semibold">
                Daily Vow Status
              </span>
              <span className="text-xs font-mono font-medium text-[#0f241d] flex items-center gap-2">
                {isGoalAchieved ? (
                  <>
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                    Achieved Today
                  </>
                ) : (
                  <>
                    <span className="w-1.5 h-1.5 bg-[#2d7a64] rounded-full" />
                    Pending Completion
                  </>
                )}
              </span>
            </div>

            <div className="space-y-1">
              <span className="text-[9px] font-mono text-[#0f241d40] uppercase tracking-wider block font-semibold">
                Remaining Effort
              </span>
              <span className="text-xs font-mono font-medium text-[#0f241d]">
                {isGoalAchieved ? (
                  <span className="text-emerald-700 font-bold uppercase tracking-wider text-[10px]">
                    None (Goal Met!)
                  </span>
                ) : (
                  `${targetMinutes - todayMinutes} more minutes`
                )}
              </span>
            </div>
          </div>

          {/* Practice Redirection CTA Button */}
          {!isGoalAchieved && onNavigate && (
            <div className="pt-2">
              <button
                id="practice-redirect-btn"
                onClick={() => onNavigate("learning")}
                className="inline-flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-[#0f241d] hover:text-[#2d7a64] font-bold transition-all cursor-pointer group"
              >
                Enter Practice Portal
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform text-[#2d7a64]" />
              </button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
