import { useState, useEffect } from "react";
import { db } from "../firebase";
import { doc, updateDoc, increment, collection, addDoc, getDocs, query, orderBy } from "firebase/firestore";
import { UserProfile, QuizQuestion } from "../types";
import { X, Award, HelpCircle, Gift, Sparkles, Trophy, Check, TrendingUp, Calendar, Bot, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { MULTILINGUAL_DATA } from "../data/multilingualHubData";
import { playSuccessChime } from "../utils/audio";

interface QuizViewProps {
  userProfile: UserProfile | null;
  onUpdateUserProfile: (updates: Partial<UserProfile>) => void;
  onNavigate: (screen: string) => void;
  onCompleteQuiz?: () => void;
  selectedLanguageId?: string;
}

interface ConfettiParticle {
  id: number;
  x: number;
  y: number;
  color: string;
  size: number;
  shape: "circle" | "square" | "triangle" | "star";
  angle: number;
  velocity: number;
}

const LANGUAGE_QUIZZES: Record<string, QuizQuestion[]> = {
  kannada: [
    {
      id: "kan_1",
      challengeType: "VOCABULARY CHALLENGE",
      question: 'What does the Kannada word "Mane" mean?',
      options: [
        { letter: "A", text: "Food / Meal" },
        { letter: "B", text: "House / Home" },
        { letter: "C", text: "Water" },
        { letter: "D", text: "Book" },
      ],
      correctAnswer: "B",
    },
    {
      id: "kan_2",
      challengeType: "CONVERSATIONAL PHRASE",
      question: 'How do you ask "Have you eaten?" in Kannada?',
      options: [
        { letter: "A", text: "Hegiddeera?" },
        { letter: "B", text: "Nanna hesaru..." },
        { letter: "C", text: "Oota aaytha?" },
        { letter: "D", text: "Innu ondhu kodi" },
      ],
      correctAnswer: "C",
    },
    {
      id: "kan_3",
      challengeType: "SYNTAX CHALLENGE",
      question: "In Kannada syntax, what is the standard sentence order?",
      options: [
        { letter: "A", text: "Subject - Verb - Object (SVO)" },
        { letter: "B", text: "Verb - Subject - Object (VSO)" },
        { letter: "C", text: "Subject - Object - Verb (SOV)" },
        { letter: "D", text: "Object - Subject - Verb (OSV)" },
      ],
      correctAnswer: "C",
    }
  ],
  hindi: [
    {
      id: "hin_1",
      challengeType: "VOCABULARY CHALLENGE",
      question: 'Which Hindi word represents "water"?',
      options: [
        { letter: "A", text: "Ghar" },
        { letter: "B", text: "Khana" },
        { letter: "C", text: "Paani" },
        { letter: "D", text: "Mitra" },
      ],
      correctAnswer: "C",
    },
    {
      id: "hin_2",
      challengeType: "CONVERSATIONAL PHRASE",
      question: 'How do you say "See you again" in Hindi?',
      options: [
        { letter: "A", text: "Aap kaise hain?" },
        { letter: "B", text: "Phir milenge" },
        { letter: "C", text: "Mera naam" },
        { letter: "D", text: "Aapka swagat hai" },
      ],
      correctAnswer: "B",
    },
    {
      id: "hin_3",
      challengeType: "GRAMMAR CHALLENGE",
      question: "In Hindi perfect tenses, the marker 'ne' (ने) attaches to what part of speech?",
      options: [
        { letter: "A", text: "The Verb" },
        { letter: "B", text: "The Subject" },
        { letter: "C", text: "The Direct Object" },
        { letter: "D", text: "The Adjective" },
      ],
      correctAnswer: "B",
    }
  ],
  english: [
    {
      id: "eng_1",
      challengeType: "VOCABULARY CHALLENGE",
      question: 'What is the phonetic pronunciation of the English word "School"?',
      options: [
        { letter: "A", text: "Huh-loh" },
        { letter: "B", text: "Skool" },
        { letter: "C", text: "Frend" },
        { letter: "D", text: "Wah-ter" },
      ],
      correctAnswer: "B",
    },
    {
      id: "eng_2",
      challengeType: "GRAMMAR CHALLENGE",
      question: "Which tense represents an action that started in the past, continues in the present, and will likely persist?",
      options: [
        { letter: "A", text: "Simple Past" },
        { letter: "B", text: "Future Perfect" },
        { letter: "C", text: "Present Perfect Continuous" },
        { letter: "D", text: "Pluperfect" },
      ],
      correctAnswer: "C",
    },
    {
      id: "eng_3",
      challengeType: "CONVERSATIONAL PHRASE",
      question: "Which phrase is standard when asking someone's identity upon first meeting?",
      options: [
        { letter: "A", text: "How are you?" },
        { letter: "B", text: "Nice to meet you" },
        { letter: "C", text: "What is your name?" },
        { letter: "D", text: "Can you help me?" },
      ],
      correctAnswer: "C",
    }
  ],
  spanish: [
    {
      id: "esp_1",
      challengeType: "VOCABULARY CHALLENGE",
      question: 'Which Spanish word represents "library"?',
      options: [
        { letter: "A", text: "Amanecer" },
        { letter: "B", text: "Biblioteca" },
        { letter: "C", text: "Sutil" },
        { letter: "D", text: "Alboroto" },
      ],
      correctAnswer: "B",
    },
    {
      id: "esp_2",
      challengeType: "IDIOM CHALLENGE",
      question: 'What does "Tengo hambre" literally translate to in Spanish?',
      options: [
        { letter: "A", text: "I have hunger" },
        { letter: "B", text: "I am thirsty" },
        { letter: "C", text: "I am cold" },
        { letter: "D", text: "I am tired" },
      ],
      correctAnswer: "A",
    },
    {
      id: "esp_3",
      challengeType: "GRAMMAR CHALLENGE",
      question: "Which mood is used in Spanish to express desires, doubts, or subjective views?",
      options: [
        { letter: "A", text: "Indicative Mood" },
        { letter: "B", text: "Imperative Mood" },
        { letter: "C", text: "Subjunctive Mood" },
        { letter: "D", text: "Infinitive Mood" },
      ],
      correctAnswer: "C",
    }
  ],
  french: [
    {
      id: "fre_1",
      challengeType: "VOCABULARY CHALLENGE",
      question: 'What is the French word for "bread"?',
      options: [
        { letter: "A", text: "Eau" },
        { letter: "B", text: "Pain" },
        { letter: "C", text: "Livre" },
        { letter: "D", text: "Maison" },
      ],
      correctAnswer: "B",
    },
    {
      id: "fre_2",
      challengeType: "CONVERSATIONAL PHRASE",
      question: 'Which expression means "Nice/Delighted to meet you" in French?',
      options: [
        { letter: "A", text: "Comment ça va?" },
        { letter: "B", text: "S'il vous plaît" },
        { letter: "C", text: "Enchanté" },
        { letter: "D", text: "Bonjour" },
      ],
      correctAnswer: "C",
    },
    {
      id: "fre_3",
      challengeType: "GRAMMAR CHALLENGE",
      question: "Which auxiliary verb do motion and reflexive verbs use in the past tense (Passé Composé)?",
      options: [
        { letter: "A", text: "Avoir" },
        { letter: "B", text: "Être" },
        { letter: "C", text: "Faire" },
        { letter: "D", text: "Aller" },
      ],
      correctAnswer: "B",
    }
  ],
  german: [
    {
      id: "ger_1",
      challengeType: "VOCABULARY CHALLENGE",
      question: 'What is the German word for "water"?',
      options: [
        { letter: "A", text: "Wasser" },
        { letter: "B", text: "Brot" },
        { letter: "C", text: "Buch" },
        { letter: "D", text: "Zeit" },
      ],
      correctAnswer: "A",
    },
    {
      id: "ger_2",
      challengeType: "SYNTAX CHALLENGE",
      question: "What happens to the conjugated verb in German subordinate clauses (after 'weil', 'dass')?",
      options: [
        { letter: "A", text: "It is placed at the absolute beginning of the clause" },
        { letter: "B", text: "It is kicked to the absolute end of the clause" },
        { letter: "C", text: "It is deleted entirely" },
        { letter: "D", text: "It remains in the second position" },
      ],
      correctAnswer: "B",
    },
    {
      id: "ger_3",
      challengeType: "GRAMMAR CHALLENGE",
      question: "For two-way prepositions in German, which case is used to represent a stationary state or location?",
      options: [
        { letter: "A", text: "Accusative Case" },
        { letter: "B", text: "Dative Case" },
        { letter: "C", text: "Genitive Case" },
        { letter: "D", text: "Nominative Case" },
      ],
      correctAnswer: "B",
    }
  ],
  mandarin: [
    {
      id: "man_1",
      challengeType: "VOCABULARY CHALLENGE",
      question: 'What does the Mandarin word "Xièxie" mean?',
      options: [
        { letter: "A", text: "Hello" },
        { letter: "B", text: "Water" },
        { letter: "C", text: "Thank you" },
        { letter: "D", text: "Friend" },
      ],
      correctAnswer: "C",
    },
    {
      id: "man_2",
      challengeType: "GRAMMAR CHALLENGE",
      question: "What must be placed between a number and a noun when counting items in Mandarin Chinese?",
      options: [
        { letter: "A", text: "A preposition" },
        { letter: "B", text: "A measure word (classifier)" },
        { letter: "C", text: "A verb suffix" },
        { letter: "D", text: "An aspect particle" },
      ],
      correctAnswer: "B",
    },
    {
      id: "man_3",
      challengeType: "PARTICLE CHALLENGE",
      question: "Which particle is appended to signal a completed action or change of state?",
      options: [
        { letter: "A", text: "Ma (吗)" },
        { letter: "B", text: "De (de)" },
        { letter: "C", text: "Le (了)" },
        { letter: "D", text: "Ba (吧)" },
      ],
      correctAnswer: "C",
    }
  ],
  japanese: [
    {
      id: "jap_1",
      challengeType: "VOCABULARY CHALLENGE",
      question: 'What is the formal way to say "Thank you very much" in Japanese?',
      options: [
        { letter: "A", text: "Arigato" },
        { letter: "B", text: "Doumo" },
        { letter: "C", text: "Arigato Gozaimasu" },
        { letter: "D", text: "Sumimasen" },
      ],
      correctAnswer: "C",
    },
    {
      id: "jap_2",
      challengeType: "PARTICLE CHALLENGE",
      question: "In Japanese, which particle is used to mark the direct object of a verb?",
      options: [
        { letter: "A", text: "Wa (は)" },
        { letter: "B", text: "Ga (が)" },
        { letter: "C", text: "Wo (を)" },
        { letter: "D", text: "Ni (に)" },
      ],
      correctAnswer: "C",
    },
    {
      id: "jap_3",
      challengeType: "HONORIFIC CHALLENGE",
      question: "What is the polite/honorific speech hierarchy system in Japanese called?",
      options: [
        { letter: "A", text: "Keigo" },
        { letter: "B", text: "Hiragana" },
        { letter: "C", text: "Kanji" },
        { letter: "D", text: "Romaji" },
      ],
      correctAnswer: "A",
    }
  ],
  arabic: [
    {
      id: "ara_1",
      challengeType: "VOCABULARY CHALLENGE",
      question: 'What is the Arabic word for "book"?',
      options: [
        { letter: "A", text: "Bayt" },
        { letter: "B", text: "Ma'" },
        { letter: "C", text: "Kitab" },
        { letter: "D", text: "Sadiq" },
      ],
      correctAnswer: "C",
    },
    {
      id: "ara_2",
      challengeType: "MORPHOLOGY CHALLENGE",
      question: "Arabic words are typically derived from a core combination of how many consonant root letters?",
      options: [
        { letter: "A", text: "Two letters" },
        { letter: "B", text: "Three letters" },
        { letter: "C", text: "Five letters" },
        { letter: "D", text: "Seven letters" },
      ],
      correctAnswer: "B",
    },
    {
      id: "ara_3",
      challengeType: "GRAMMAR CHALLENGE",
      question: "What is the name of the Arabic noun construct state indicating relationship or possession?",
      options: [
        { letter: "A", text: "Idafa" },
        { letter: "B", text: "Fatha" },
        { letter: "C", text: "Kasra" },
        { letter: "D", text: "Damma" },
      ],
      correctAnswer: "A",
    }
  ],
  russian: [
    {
      id: "rus_1",
      challengeType: "VOCABULARY CHALLENGE",
      question: 'What does the Russian word "Spasibo" mean?',
      options: [
        { letter: "A", text: "Please" },
        { letter: "B", text: "Thank you" },
        { letter: "C", text: "Hello" },
        { letter: "D", text: "Goodbye" },
      ],
      correctAnswer: "B",
    },
    {
      id: "rus_2",
      challengeType: "GRAMMAR CHALLENGE",
      question: "How many grammatical cases do Russian nouns decline across?",
      options: [
        { letter: "A", text: "Three cases" },
        { letter: "B", text: "Four cases" },
        { letter: "C", text: "Six cases" },
        { letter: "D", text: "Eight cases" },
      ],
      correctAnswer: "C",
    },
    {
      id: "rus_3",
      challengeType: "VERBAL ASPECT CHALLENGE",
      question: "Which aspect represents process or ongoing, unfinalized actions in Russian?",
      options: [
        { letter: "A", text: "Perfective Aspect" },
        { letter: "B", text: "Imperfective Aspect" },
        { letter: "C", text: "Passive Aspect" },
        { letter: "D", text: "Subjunctive Aspect" },
      ],
      correctAnswer: "B",
    }
  ]
};

export default function QuizView({
  userProfile,
  onUpdateUserProfile,
  onNavigate,
  onCompleteQuiz,
  selectedLanguageId = "kannada",
}: QuizViewProps) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedLetter, setSelectedLetter] = useState<"A" | "B" | "C" | "D" | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isWrong, setIsWrong] = useState(false);
  const [, setShowFeedback] = useState(false);

  const [quizComplete, setQuizComplete] = useState(false);
  const [wrongAnswers, setWrongAnswers] = useState<QuizQuestion[]>([]);
  const [quizSummary, setQuizSummary] = useState<string | null>(null);
  const [loadingSummary, setLoadingSummary] = useState(false);

  const [score, setScore] = useState(0);

  // History and metrics tracker
  const [history, setHistory] = useState<{
    id: string;
    languageId: string;
    score: number;
    totalQuestions: number;
    accuracy: number;
    completedAt: number;
  }[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  // Present/Gift box states (User Reward system)
  const [showGiftBox, setShowGiftBox] = useState(false);
  const [giftBoxOpened, setGiftBoxOpened] = useState(false);
  const [giftRewardName, setGiftRewardName] = useState("");
  const [giftRewardDetail, setGiftRewardDetail] = useState("");
  const [openingGift, setOpeningGift] = useState(false);
  const [particles, setParticles] = useState<ConfettiParticle[]>([]);

  // Fetch past quiz results when component is in complete state
  useEffect(() => {
    if (userProfile && quizComplete) {
      fetchQuizHistory();
      generateSummary();
    }
  }, [userProfile, quizComplete]);

  const generateSummary = async () => {
    setLoadingSummary(true);
    try {
      const response = await fetch("/api/quiz-summary", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          score,
          totalQuestions: questions.length,
          language: selectedLanguageId,
          wrongAnswers: wrongAnswers.map(q => ({
            question: q.question,
            correctAnswer: q.options.find(opt => opt.letter === q.correctAnswer)?.text || q.correctAnswer
          }))
        })
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const text = await response.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (err) {
        throw new Error("Invalid JSON response from server");
      }
      if (data.success) {
        setQuizSummary(data.summary);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingSummary(false);
    }
  };

  const fetchQuizHistory = async () => {
    if (!userProfile) return;
    setLoadingHistory(true);
    try {
      const quizzesColRef = collection(db, "users", userProfile.uid, "quizzes");
      const q = query(quizzesColRef, orderBy("completedAt", "desc"));
      const querySnapshot = await getDocs(q);
      const docsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as any[];
      setHistory(docsData);
    } catch (e) {
      console.error("Failed to fetch quiz history:", e);
    } finally {
      setLoadingHistory(false);
    }
  };

  const saveQuizResult = async (finalScore: number) => {
    if (!userProfile) return;
    try {
      const quizzesColRef = collection(db, "users", userProfile.uid, "quizzes");
      const quizResult = {
        languageId: selectedLanguageId,
        score: finalScore,
        totalQuestions: questions.length,
        accuracy: Math.round((finalScore / questions.length) * 100),
        completedAt: Date.now()
      };
      await addDoc(quizzesColRef, quizResult);
      fetchQuizHistory();
    } catch (e) {
      console.error("Failed to save quiz result:", e);
    }
  };

  const triggerConfetti = () => {
    const colors = [
      "#2d7a64", "#0f241d", "#D4AF37", "#10B981", "#3B82F6", 
      "#EF4444", "#EC4899", "#F59E0B", "#14B8A6", "#b59870"
    ];
    const newParticles: ConfettiParticle[] = Array.from({ length: 120 }).map((_, i) => {
      const angle = (Math.random() * 360 * Math.PI) / 180;
      const velocity = 10 + Math.random() * 25;
      const size = 6 + Math.random() * 10;
      const shapes: ("circle" | "square" | "triangle" | "star")[] = ["circle", "square", "triangle", "star"];
      const shape = shapes[Math.floor(Math.random() * shapes.length)];
      return {
        id: Date.now() + i,
        x: 0,
        y: 0,
        color: colors[Math.floor(Math.random() * colors.length)],
        size,
        shape,
        angle,
        velocity,
      };
    });
    setParticles(newParticles);
  };

  const questions = LANGUAGE_QUIZZES[selectedLanguageId] || LANGUAGE_QUIZZES["kannada"];
  const currentQuestion = questions[currentIdx];

  const handleSelect = (letter: "A" | "B" | "C" | "D") => {
    if (isAnswered) return;
    setSelectedLetter(letter);
    setIsWrong(false);
  };

  const handleCheckAnswer = async () => {
    if (!selectedLetter) return;

    const isCorrect = selectedLetter === currentQuestion.correctAnswer;

    if (isCorrect) {
      setIsAnswered(true);
      playSuccessChime();
      const newScore = score + 1;
      setScore(newScore);
      setShowFeedback(true);

      setTimeout(() => {
        setShowFeedback(false);
      }, 1500);

      if (userProfile) {
        try {
          const userDocRef = doc(db, "users", userProfile.uid);
          await updateDoc(userDocRef, {
            xp: increment(15),
          });
          onUpdateUserProfile({
            xp: userProfile.xp + 15,
          });
        } catch (e) {
          console.error("Firestore update failed:", e);
        }
      }
    } else {
      setIsWrong(true);
      if (!wrongAnswers.find(q => q.question === currentQuestion.question)) {
        setWrongAnswers(prev => [...prev, currentQuestion]);
      }
      if (navigator.vibrate) {
        navigator.vibrate(50);
      }
      setTimeout(() => {
        setIsWrong(false);
      }, 500);
    }
  };

  const handleNext = () => {
    setIsAnswered(false);
    setSelectedLetter(null);
    setIsWrong(false);

    if (currentIdx < questions.length - 1) {
      setCurrentIdx((prev) => prev + 1);
    } else {
      setQuizComplete(true);
      setShowGiftBox(true); // Automatically display the interactive gift box unboxing overlay modal!
      
      // Save result to Firestore
      saveQuizResult(score);

      if (userProfile) {
        const userDocRef = doc(db, "users", userProfile.uid);
        updateDoc(userDocRef, {
          sessions: increment(1),
        }).then(() => {
          onUpdateUserProfile({
            sessions: userProfile.sessions + 1,
          });
        });
      }
    }
  };

  // Triggered when clicking Claim Present
  const handleOpenPresentGift = () => {
    if (openingGift) return;
    setOpeningGift(true);
    // Randomize gorgeous gifts!
    const rewardPresets = [
      { name: "Golden Phoenix Trophy 🏆", detail: "+100 Bonus XP & Master Linguist Title" },
      { name: "Double Streak Shield 🛡️", detail: "+50 Bonus XP & Auto-Freeze Missed Days" },
      { name: "Ancient Scholar Codex 📜", detail: "+150 Bonus XP & Rare Vocabulary Card" },
      { name: "Sacred Glossway Medallion 🏅", detail: "+200 Bonus XP & VIP Chat Color Key" }
    ];
    const chosen = rewardPresets[Math.floor(Math.random() * rewardPresets.length)];

    setTimeout(() => {
      setOpeningGift(false);
      setGiftBoxOpened(true);
      setGiftRewardName(chosen.name);
      setGiftRewardDetail(chosen.detail);
      
      // Trigger particles confetti explosion!
      triggerConfetti();
      
      // Trigger App.tsx's parent calendar marking and reward synchronization
      if (onCompleteQuiz) {
        onCompleteQuiz();
      }
    }, 1500);
  };

  if (quizComplete) {
    return (
      <div className="max-w-[600px] mx-auto text-center space-y-8 py-10 animate-fade-in font-sans text-[#0f241d] relative">
        
        {/* GOLDEN PRESENT OPENER MODAL OVERLAY */}
        <AnimatePresence>
          {showGiftBox && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 30 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 30 }}
                transition={{ type: "spring", damping: 25, stiffness: 350 }}
                className="bg-white border-2 border-[#0f241d] w-full max-w-[460px] p-6 md:p-8 space-y-6 text-center relative shadow-2xl overflow-hidden bg-radial from-white to-[#f3f7f5]"
              >
                {/* Close Button */}
                <button
                  onClick={() => setShowGiftBox(false)}
                  className="absolute top-4 right-4 w-8 h-8 border border-[#0f241d15] hover:bg-neutral-100 flex items-center justify-center cursor-pointer text-[#0f241d] z-50"
                  title="Close Reward Modal"
                >
                  <X className="w-4 h-4" />
                </button>

                {/* Bursting Confetti Particles */}
                <div className="absolute inset-0 pointer-events-none overflow-hidden flex items-center justify-center">
                  {particles.map((p) => {
                    const destX = Math.cos(p.angle) * p.velocity * 12;
                    const destY = Math.sin(p.angle) * p.velocity * 12 - 140;
                    return (
                      <motion.div
                        key={p.id}
                        initial={{ x: 0, y: 40, scale: 0, opacity: 1, rotate: 0 }}
                        animate={{
                          x: destX,
                          y: [40, destY, destY + 250],
                          opacity: [1, 1, 0.9, 0],
                          scale: [1, 1.4, 0.8, 0.4],
                          rotate: [0, 180, 360, Math.random() * 720]
                        }}
                        transition={{
                          duration: 1.6 + Math.random() * 1.4,
                          ease: "easeOut"
                        }}
                        style={{
                          position: "absolute",
                          width: p.size,
                          height: p.size,
                          backgroundColor: p.shape !== "triangle" ? p.color : undefined,
                          borderRadius: p.shape === "circle" ? "50%" : p.shape === "square" ? "4px" : "0",
                          borderLeft: p.shape === "triangle" ? `${p.size / 2}px solid transparent` : undefined,
                          borderRight: p.shape === "triangle" ? `${p.size / 2}px solid transparent` : undefined,
                          borderBottom: p.shape === "triangle" ? `${p.size}px solid ${p.color}` : undefined,
                          zIndex: 60,
                        }}
                      />
                    );
                  })}
                </div>

                <div className="inline-flex items-center gap-2 text-[#2d7a64] mx-auto relative z-10">
                  <Gift className="w-5 h-5 text-[#2d7a64] animate-bounce" />
                  <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-semibold">
                    Daily Quiz Present Unlocked!
                  </span>
                </div>

                {!giftBoxOpened ? (
                  <div className="space-y-6 flex flex-col items-center py-4 relative z-10">
                    <div className="relative">
                      <motion.div
                        animate={openingGift ? {
                          rotate: [-3, 3, -3, 3, -6, 6, -6, 6, -10, 10, -10, 10, 0],
                          scale: [1, 1.05, 1.05, 1.1, 1.1, 1.15, 1.15, 1.2, 1.2, 1.05, 1],
                          transition: { duration: 1.5, ease: "easeInOut" }
                        } : {
                          y: [0, -5, 0],
                          transition: { duration: 2, repeat: Infinity, ease: "easeInOut" }
                        }}
                        whileHover={{ scale: 1.05 }}
                        onClick={!openingGift ? handleOpenPresentGift : undefined}
                        className="w-32 h-32 border-2 border-[#0f241d] bg-[#f3f7f5] shadow-lg flex items-center justify-center cursor-pointer overflow-hidden group relative"
                      >
                        {/* Elegant Ribbon Accents */}
                        <div className="absolute top-0 bottom-0 w-4 bg-[#2d7a64] left-[calc(50%-8px)]" />
                        <div className="absolute left-0 right-0 h-4 bg-[#2d7a64] top-[calc(50%-8px)]" />
                        <div className="absolute inset-0 bg-gradient-to-tr from-[#2d7a64]/15 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        
                        <Gift className={`w-16 h-16 relative z-10 ${openingGift ? "text-[#2d7a64] scale-110 animate-pulse" : "text-black group-hover:text-[#2d7a64]"} transition-all duration-300`} />
                      </motion.div>
                      {openingGift && (
                        <div className="absolute inset-0 bg-[#2d7a64]/15 flex items-center justify-center rounded-xs pointer-events-none">
                          <Sparkles className="w-10 h-10 text-[#2d7a64] animate-spin" />
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <h3 className="font-sans font-semibold tracking-tight font-medium text-2xl text-[#0f241d]">
                        {openingGift ? "Opening the Vault..." : "Your Reward Awaits!"}
                      </h3>
                      <p className="text-xs text-[#0f241d50] max-w-sm mx-auto leading-relaxed font-sans font-semibold tracking-tight">
                        You achieved an outstanding daily quiz completion. Open your premium gift package to claim exclusive scholar bonus rewards!
                      </p>
                    </div>

                    <button
                      onClick={handleOpenPresentGift}
                      disabled={openingGift}
                      className="w-full py-4 bg-black hover:bg-neutral-800 text-[#f3f7f5] font-mono text-xs uppercase tracking-widest transition-all cursor-pointer disabled:opacity-50 shadow-md relative overflow-hidden group border border-black"
                    >
                      <span className="relative z-10 flex items-center justify-center gap-2">
                        {openingGift ? (
                          <>Cracking Open... <Sparkles className="w-4 h-4 animate-spin" /></>
                        ) : (
                          <>Unbox Golden Present 🎁</>
                        )}
                      </span>
                      <div className="absolute inset-0 bg-white/10 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
                    </button>
                  </div>
                ) : (
                  <div className="space-y-6 flex flex-col items-center py-4 relative z-10">
                    <motion.div
                      initial={{ scale: 0.5, rotate: -45 }}
                      animate={{ scale: [1, 1.2, 1], rotate: 0 }}
                      transition={{ type: "spring", duration: 0.8 }}
                      className="relative"
                    >
                      <div className="w-24 h-24 bg-[#2d7a64]/10 border-2 border-[#2d7a64] rounded-full flex items-center justify-center">
                        <Trophy className="w-10 h-10 text-[#2d7a64]" />
                      </div>
                      <div className="absolute -top-1 -right-1 bg-red-500 text-white p-1 rounded-full animate-bounce">
                        <Sparkles className="w-4 h-4 text-white" />
                      </div>
                    </motion.div>

                    <div className="space-y-2">
                      <span className="text-[9px] font-mono uppercase bg-[#2d7a64] text-white px-3 py-1 font-bold tracking-widest">
                        REWARD GRANTED
                      </span>
                      <h3 className="font-sans font-semibold tracking-tight font-medium text-3xl text-black">
                        {giftRewardName}
                      </h3>
                      <p className="text-xs font-mono text-[#0f241d60] tracking-wide mt-1">
                        {giftRewardDetail}
                      </p>
                    </div>

                    <div className="flex flex-col items-center gap-2 pt-2">
                      <p className="text-[10px] text-emerald-600 font-mono uppercase tracking-wider flex items-center gap-1.5 bg-emerald-50 px-4 py-1.5 border border-emerald-500/10">
                        <Check className="w-4 h-4 stroke-[3]" /> CALENDAR STAMP UNLOCKED!
                      </p>
                    </div>

                    <div className="pt-4 flex gap-3 w-full max-w-xs">
                      <button
                        onClick={() => {
                          setShowGiftBox(false);
                          onNavigate("dashboard");
                        }}
                        className="flex-grow py-3.5 bg-black hover:bg-neutral-800 text-white font-mono text-xs uppercase tracking-widest cursor-pointer transition-colors border border-black shadow-md"
                      >
                        Go To Calendar
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <div className="w-16 h-16 border border-[#0f241d15] bg-[#e8f0eb] flex items-center justify-center text-[#0f241d] mx-auto">
          <Award className="w-8 h-8 text-[#2d7a64]" />
        </div>
        <h2 className="text-3.5xl font-sans font-semibold tracking-tight font-medium text-[#0f241d]">
          Challenge Completed!
        </h2>
        <p className="text-[#0f241d60] max-w-sm mx-auto text-xs leading-relaxed font-mono uppercase tracking-wider">
          Amazing work! You got {score} / {questions.length} correct on this session.
        </p>

        {/* CURRENT SESSION STATS */}
        <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
          <div className="p-5 bg-white border border-[#0f241d15] flex flex-col items-center shadow-xs">
            <span className="text-2xl font-sans font-semibold tracking-tight font-semibold text-[#0f241d]">+{score * 15} XP</span>
            <span className="text-[9px] font-mono uppercase tracking-widest text-[#0f241d40] mt-1 font-bold">Session XP Earned</span>
          </div>
          <div className="p-5 bg-white border border-[#0f241d15] flex flex-col items-center shadow-xs">
            <span className="text-2xl font-sans font-semibold tracking-tight font-semibold text-[#0f241d]">{Math.round((score / questions.length) * 100)}%</span>
            <span className="text-[9px] font-mono uppercase tracking-widest text-[#0f241d40] mt-1 font-bold">Accuracy Rating</span>
          </div>
        </div>


        {/* AI SESSION SUMMARY */}
        <div className="max-w-md mx-auto pt-4 text-left">
          <div className="p-6 bg-[#f3f7f5] border border-[#0f241d15] shadow-sm relative overflow-hidden">
            <div className="flex items-center gap-2 mb-3">
              <Bot className="w-4 h-4 text-[#2d7a64]" />
              <span className="text-[10px] font-mono uppercase tracking-[0.15em] text-[#0f241d50] font-bold">AI Session Summary</span>
            </div>
            {loadingSummary ? (
              <div className="flex flex-col items-center justify-center py-6 space-y-3">
                <Loader2 className="w-5 h-5 text-[#2d7a64] animate-spin" />
                <span className="text-xs font-mono text-[#0f241d40] tracking-wide">ai mentor is analyzing your performance...</span>
              </div>
            ) : (
              <p className="text-sm font-sans font-semibold tracking-tight leading-relaxed text-[#0f241d80]">
                {quizSummary || "Keep up the excellent work! Regular practice is the key to fluency."}
              </p>
            )}
          </div>
        </div>

        {/* CUMULATIVE LEARNER PERFORMANCE METRICS (Bento Grid Style) */}

        <div className="max-w-md mx-auto space-y-4 pt-4 text-left">
          <div className="flex items-center gap-2 border-b border-[#0f241d10] pb-2">
            <TrendingUp className="w-3.5 h-3.5 text-[#2d7a64]" />
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-[#0f241d40] font-bold">Cumulative Learner Stats</span>
          </div>
          
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white border border-[#0f241d10] p-4 flex flex-col items-center text-center">
              <span className="text-xl font-sans font-semibold tracking-tight font-bold text-[#0f241d]">{loadingHistory ? "..." : history.length}</span>
              <span className="text-[8px] font-mono uppercase tracking-wider text-[#0f241d50] mt-1">Quizzes taken</span>
            </div>
            <div className="bg-white border border-[#0f241d10] p-4 flex flex-col items-center text-center">
              <span className="text-xl font-sans font-semibold tracking-tight font-bold text-[#0f241d]">
                {loadingHistory ? "..." : history.length > 0 ? `${Math.round(history.reduce((sum, item) => sum + item.accuracy, 0) / history.length)}%` : "0%"}
              </span>
              <span className="text-[8px] font-mono uppercase tracking-wider text-[#0f241d50] mt-1">Avg Accuracy</span>
            </div>
            <div className="bg-white border border-[#0f241d10] p-4 flex flex-col items-center text-center">
              <span className="text-xl font-sans font-semibold tracking-tight font-bold text-[#0f241d]">
                {loadingHistory ? "..." : history.filter(item => item.score === item.totalQuestions).length}
              </span>
              <span className="text-[8px] font-mono uppercase tracking-wider text-[#0f241d50] mt-1">Perfect Score</span>
            </div>
          </div>
        </div>

        {/* LEARNING HISTORY LEDGER */}
        <div className="max-w-md mx-auto space-y-3 pt-2 text-left">
          <div className="flex items-center gap-2 border-b border-[#0f241d10] pb-2">
            <Calendar className="w-3.5 h-3.5 text-[#2d7a64]" />
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-[#0f241d40] font-bold">Historical Sessions Ledger</span>
          </div>

          {loadingHistory ? (
            <div className="text-center py-6 text-xs font-mono text-neutral-400">Loading historical ledger data...</div>
          ) : history.length === 0 ? (
            <div className="text-center py-6 text-xs text-neutral-400 font-sans font-semibold tracking-tight">No learning records found.</div>
          ) : (
            <div className="border border-[#0f241d12] bg-white divide-y divide-[#0f241d08] max-h-[220px] overflow-y-auto shadow-xs">
              {history.map((session, index) => {
                const sessionLang = MULTILINGUAL_DATA.find(l => l.id === session.languageId) || { name: session.languageId, flag: "🌐" };
                return (
                  <div key={session.id || index} className="p-3.5 flex items-center justify-between text-left hover:bg-neutral-50 transition-colors">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm select-none">{sessionLang.flag}</span>
                        <span className="font-sans font-semibold tracking-tight font-medium text-xs text-[#0f241d] capitalize">{sessionLang.name}</span>
                      </div>
                      <p className="text-[9px] font-mono text-[#0f241d40]">
                        {new Date(session.completedAt).toLocaleDateString(undefined, {
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit"
                        })}
                      </p>
                    </div>
                    <div className="text-right space-y-1">
                      <div className="text-[11px] font-mono font-bold text-[#0f241d]">
                        {session.score} / {session.totalQuestions}
                      </div>
                      <span className={`inline-block text-[8px] font-mono px-1.5 py-0.5 font-bold tracking-wider uppercase ${
                        session.accuracy >= 100 
                          ? "bg-emerald-50 text-emerald-700 border border-emerald-500/10" 
                          : session.accuracy >= 66 
                          ? "bg-[#2d7a64]/15 text-[#2d7a64]" 
                          : "bg-neutral-100 text-neutral-500"
                      }`}>
                        {session.accuracy}%
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* PRESENT TRIGGER BANNER */}
        <div className="p-5 border border-[#2d7a64] bg-[#2d7a64]/5 max-w-md mx-auto space-y-3 shadow-xs">
          <div className="flex items-center justify-center gap-2 text-[#2d7a64]">
            <Gift className="w-5 h-5" />
            <span className="text-xs font-mono font-bold uppercase tracking-wider">Scholar Present Unlocked</span>
          </div>
          <p className="text-[11px] font-sans font-semibold tracking-tight text-[#0f241d70] leading-relaxed">
            As an active learner, completing this daily challenge unlocks a premium present box! Claim it to stamp your study streak.
          </p>
          <button
            onClick={() => setShowGiftBox(true)}
            className="w-full py-2.5 bg-black hover:bg-neutral-800 text-white font-mono text-[10px] uppercase tracking-widest cursor-pointer transition-colors"
          >
            Claim Scholar Present 🎁
          </button>
        </div>

        <div className="pt-4 flex gap-4 max-w-md mx-auto">
          <button
            onClick={() => {
              setQuizComplete(false);
              setCurrentIdx(0);
              setScore(0);
              setSelectedLetter(null);
              setIsAnswered(false);
              setShowGiftBox(false);
              setGiftBoxOpened(false);
            }}
            className="flex-1 py-3.5 bg-white border border-[#0f241d] hover:bg-[#e8f0eb] text-[#0f241d] font-mono text-xs uppercase tracking-widest transition-colors cursor-pointer"
          >
            Restart
          </button>
          <button
            onClick={() => onNavigate("dashboard")}
            className="flex-1 py-3.5 bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest border border-[#0f241d] transition-colors cursor-pointer"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  const progressPct = Math.round(((currentIdx + (isAnswered ? 1 : 0)) / questions.length) * 100);

  const langData = MULTILINGUAL_DATA.find(l => l.id === selectedLanguageId) || MULTILINGUAL_DATA[0];

  return (
    <div className="max-w-[650px] mx-auto space-y-8 py-6 animate-fade-in font-sans text-[#0f241d]">
      {/* Top Progress Bar */}
      <div className="h-1.5 w-full bg-[#e8f0eb] border border-[#0f241d08] overflow-hidden">
        <motion.div
          className="h-full bg-[#0f241d]"
          initial={{ width: 0 }}
          animate={{ width: `${progressPct}%` }}
          transition={{ duration: 0.4, ease: "easeOut" }}
        />
      </div>

      {/* Header */}
      <div className="flex justify-between items-center">
        <button
          onClick={() => onNavigate("dashboard")}
          className="w-9 h-9 border border-[#0f241d15] bg-white hover:bg-[#e8f0eb] text-[#0f241d] flex items-center justify-center cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
        <h1 className="text-xl font-sans font-semibold tracking-tight font-medium text-[#0f241d] flex items-center gap-2">
          <span>{langData.flag}</span>
          <span>{langData.name} Challenge</span>
        </h1>
        <div className="w-9 h-9 border border-[#0f241d15] bg-white flex items-center justify-center text-[#0f241d]">
          <HelpCircle className="w-4 h-4" />
        </div>
      </div>

      {/* Question Card and Options */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIdx}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="space-y-6"
        >
          {/* Question Card */}
          <section className="w-full bg-white border border-[#0f241d15] p-8 text-center shadow-xs">
            <span className="inline-block border border-[#0f241d15] bg-[#e8f0eb] text-[9px] font-mono uppercase tracking-[0.2em] px-3.5 py-1 mb-4 text-[#0f241d70]">
              {currentQuestion.challengeType}
            </span>
            <h2 className="text-2xl md:text-3xl font-sans font-semibold tracking-tight font-medium text-[#0f241d] leading-normal select-all">
              {currentQuestion.question}
            </h2>

            {currentQuestion.imageUrl && (
              <div className="w-full h-48 border border-[#0f241d15] p-1.5 bg-white mt-6">
                <img
                  src={currentQuestion.imageUrl}
                  alt="Context illustration"
                  className="w-full h-full object-cover select-none grayscale brightness-95 contrast-105"
                />
              </div>
            )}
          </section>

          {/* Options Grid (Consistent Single Column Spacing) */}
          <div className="grid grid-cols-1 gap-4 w-full" id="quiz-options">
            {currentQuestion.options.map((option, idx) => {
              const isSelected = selectedLetter === option.letter;
              return (
                <motion.button
                  key={option.letter}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05, duration: 0.3 }}
                  onClick={() => handleSelect(option.letter)}
                  className={`flex items-center p-5 border transition-all text-left min-h-[72px] cursor-pointer group ${
                    isSelected
                      ? "bg-[#0f241d] text-[#f3f7f5] border-[#0f241d]"
                      : "bg-white border-[#0f241d15] hover:border-[#0f241d] hover:bg-[#f3f7f5] text-[#0f241d]"
                  } ${isWrong && isSelected ? "animate-shake border-red-500 bg-red-50 text-red-700" : ""}`}
                >
                  <div
                    className={`w-9 h-9 border flex items-center justify-center mr-4 shrink-0 transition-colors ${
                      isSelected
                        ? "bg-white border-white text-[#0f241d]"
                        : "bg-[#e8f0eb] border-[#0f241d10] text-[#0f241d60] group-hover:bg-[#0f241d] group-hover:text-white group-hover:border-[#0f241d]"
                    }`}
                  >
                    <span className="font-mono text-xs font-semibold">{option.letter}</span>
                  </div>
                  <span className="text-sm font-medium tracking-wide">{option.text}</span>
                </motion.button>
              );
            })}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Bottom Action Button */}
      <div className="pt-4 flex flex-col items-center">
        {isAnswered ? (
          <button
            onClick={handleNext}
            className="w-full py-3.5 bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest border border-[#0f241d] transition-colors cursor-pointer"
          >
            Continue
          </button>
        ) : (
          <button
            onClick={handleCheckAnswer}
            disabled={!selectedLetter}
            className="w-full py-3.5 bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest border border-[#0f241d] transition-colors cursor-pointer disabled:opacity-30"
          >
            Check Answer
          </button>
        )}
      </div>
    </div>
  );
}
