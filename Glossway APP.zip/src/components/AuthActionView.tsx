import { useState, useEffect } from "react";
import { auth } from "../firebase";
import {
  confirmPasswordReset,
  verifyPasswordResetCode,
  applyActionCode,
} from "firebase/auth";
import { Sparkles, CheckCircle, AlertCircle, Lock, ArrowLeft } from "lucide-react";

interface AuthActionViewProps {
  mode: string;
  oobCode: string;
  onClearAction: () => void;
}

export default function AuthActionView({
  mode,
  oobCode,
  onClearAction,
}: AuthActionViewProps) {
  const [email, setEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [errorMessage, setErrorMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!oobCode || !mode) {
      setStatus("error");
      setErrorMessage("Invalid or missing action parameters.");
      return;
    }

    if (mode === "resetPassword") {
      // Verify password reset code to get the target email
      setStatus("loading");
      verifyPasswordResetCode(auth, oobCode)
        .then((emailAddress) => {
          setEmail(emailAddress);
          setStatus("success");
        })
        .catch((err) => {
          console.error("Error verifying reset code:", err);
          setStatus("error");
          setErrorMessage(err.message || "The password reset link is invalid or has expired.");
        });
    } else if (mode === "verifyEmail") {
      // Automatically apply email verification code
      setStatus("loading");
      applyActionCode(auth, oobCode)
        .then(() => {
          setStatus("success");
        })
        .catch((err) => {
          console.error("Error applying action code:", err);
          setStatus("error");
          setErrorMessage(err.message || "Failed to verify your email address. The link may have expired.");
        });
    } else if (mode === "recoverEmail") {
      // Automatically apply action code for email recovery
      setStatus("loading");
      applyActionCode(auth, oobCode)
        .then(() => {
          setStatus("success");
        })
        .catch((err) => {
          console.error("Error recovering email:", err);
          setStatus("error");
          setErrorMessage(err.message || "Failed to recover your email address. The link may have expired.");
        });
    } else {
      setStatus("error");
      setErrorMessage(`Action mode "${mode}" is not supported.`);
    }
  }, [mode, oobCode]);

  const handlePasswordResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setErrorMessage("Passwords do not match.");
      return;
    }
    if (newPassword.length < 6) {
      setErrorMessage("Password should be at least 6 characters.");
      return;
    }

    setSubmitting(true);
    setErrorMessage("");

    try {
      await confirmPasswordReset(auth, oobCode, newPassword);
      setStatus("success");
      // Set mode to success done to show confirmation
      setNewPassword("");
      setConfirmPassword("");
    } catch (err: any) {
      console.error("Failed to reset password:", err);
      setErrorMessage(err.message || "Failed to reset password. Please try requesting a new link.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f3f7f5] flex flex-col items-center justify-center p-6 font-sans text-[#0f241d]">
      {/* Branding */}
      <div className="mb-10 text-center flex flex-col items-center gap-1.5">
        <div className="w-12 h-12 border border-[#0f241d15] bg-[#e8f0eb] flex items-center justify-center text-[#0f241d] mb-3">
          <Sparkles className="w-5 h-5 text-[#2d7a64]" />
        </div>
        <h1 className="font-sans font-semibold tracking-tight text-4xl font-semibold text-[#0f241d] tracking-tight">
          Glossway
        </h1>
        <span className="text-[9px] font-mono tracking-[0.25em] uppercase text-[#0f241d60] mt-0.5">
          Secure Action Center
        </span>
      </div>

      {/* Main Action Card */}
      <div className="w-full max-w-md bg-white p-8 border border-[#0f241d15]">
        {/* LOADING STATE */}
        {status === "loading" && (
          <div className="text-center py-8 space-y-4">
            <div className="w-10 h-10 border-2 border-[#0f241d] border-t-transparent animate-spin mx-auto"></div>
            <p className="text-xs font-mono uppercase tracking-wider text-[#0f241d60]">
              Processing action with Glossway...
            </p>
          </div>
        )}

        {/* ERROR STATE */}
        {status === "error" && (
          <div className="space-y-6 text-center">
            <div className="w-12 h-12 rounded-full bg-red-50 border border-red-200 flex items-center justify-center mx-auto text-red-600">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div className="space-y-2">
              <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d]">
                Action Failed
              </h2>
              <p className="text-xs text-[#0f241d60] leading-relaxed">
                {errorMessage}
              </p>
            </div>
            <button
              onClick={onClearAction}
              className="w-full py-3 border border-[#0f241d] hover:bg-[#e8f0eb] text-[#0f241d] font-mono text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Sign In
            </button>
          </div>
        )}

        {/* SUCCESS - VERIFY EMAIL */}
        {status === "success" && mode === "verifyEmail" && (
          <div className="space-y-6 text-center">
            <div className="w-12 h-12 bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto text-emerald-600">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div className="space-y-2">
              <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d]">
                Email Verified
              </h2>
              <p className="text-xs text-[#0f241d60] leading-relaxed">
                Your email address has been successfully verified! You're ready to continue your language learning journey.
              </p>
            </div>
            <button
              onClick={onClearAction}
              className="w-full bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest py-3.5 border border-[#0f241d] transition-colors cursor-pointer"
            >
              Sign In to Your Account
            </button>
          </div>
        )}

        {/* SUCCESS - RECOVER EMAIL */}
        {status === "success" && mode === "recoverEmail" && (
          <div className="space-y-6 text-center">
            <div className="w-12 h-12 bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto text-emerald-600">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div className="space-y-2">
              <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d]">
                Email Recovered
              </h2>
              <p className="text-xs text-[#0f241d60] leading-relaxed">
                Your previous email address has been restored. If you did not initiate this change, we recommend changing your password.
              </p>
            </div>
            <button
              onClick={onClearAction}
              className="w-full bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest py-3.5 border border-[#0f241d] transition-colors cursor-pointer"
            >
              Go to Sign In
            </button>
          </div>
        )}

        {/* PASSWORD RESET FORM */}
        {status === "success" && mode === "resetPassword" && (
          <>
            {submitting ? (
              <div className="text-center py-8 space-y-4">
                <div className="w-10 h-10 border-2 border-[#0f241d] border-t-transparent animate-spin mx-auto"></div>
                <p className="text-xs font-mono uppercase tracking-wider text-[#0f241d60]">
                  Saving your new password...
                </p>
              </div>
            ) : !errorMessage && submitting === false && newPassword === "" && confirmPassword === "" && email === "" ? (
              // This is a subtle state check: if reset is completed, we render the success message
              <div className="space-y-6 text-center animate-fade-in">
                <div className="w-12 h-12 bg-emerald-50 border border-emerald-200 flex items-center justify-center mx-auto text-emerald-600">
                  <CheckCircle className="w-6 h-6" />
                </div>
                <div className="space-y-2">
                  <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d]">
                    Password Updated
                  </h2>
                  <p className="text-xs text-[#0f241d60] leading-relaxed">
                    Your password has been reset successfully. You can now log in using your new credentials.
                  </p>
                </div>
                <button
                  onClick={onClearAction}
                  className="w-full bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest py-3.5 border border-[#0f241d] transition-colors cursor-pointer"
                >
                  Sign In
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-center">
                  <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d]">
                    Reset Password
                  </h2>
                  {email && (
                    <p className="text-[10px] font-mono uppercase tracking-widest text-[#0f241d60] mt-1.5">
                      For: {email}
                    </p>
                  )}
                </div>

                {errorMessage && (
                  <div className="p-3 border border-red-200 bg-red-50 text-red-700 text-xs font-mono uppercase tracking-wider">
                    {errorMessage}
                  </div>
                )}

                <form onSubmit={handlePasswordResetSubmit} className="space-y-5">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono font-semibold text-[#0f241d60] uppercase tracking-widest block pl-0.5">
                      New Password
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0f241d40]" />
                      <input
                        type="password"
                        required
                        placeholder="Min 6 characters"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="w-full bg-[#f3f7f5] border border-[#0f241d15] py-2.5 pl-10 pr-4 text-xs font-mono uppercase tracking-wider text-[#0f241d] outline-none transition-all focus:border-[#0f241d] placeholder:text-[#0f241d30]"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono font-semibold text-[#0f241d60] uppercase tracking-widest block pl-0.5">
                      Confirm New Password
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#0f241d40]" />
                      <input
                        type="password"
                        required
                        placeholder="Confirm password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full bg-[#f3f7f5] border border-[#0f241d15] py-2.5 pl-10 pr-4 text-xs font-mono uppercase tracking-wider text-[#0f241d] outline-none transition-all focus:border-[#0f241d] placeholder:text-[#0f241d30]"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#0f241d] hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest py-3.5 border border-[#0f241d] transition-colors cursor-pointer mt-2"
                  >
                    Save New Password
                  </button>
                </form>

                <div className="text-center pt-2">
                  <button
                    onClick={onClearAction}
                    className="text-xs font-mono uppercase tracking-wider text-[#0f241d60] hover:text-[#0f241d] hover:underline"
                  >
                    Cancel and Return
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
