import { useState } from "react";
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";
import { UserProfile } from "../types";
import { Award, Zap, Sparkles } from "lucide-react";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";

interface ProficiencyRadarChartProps {
  userProfile: UserProfile | null;
  onUpdateUserProfile: (updates: Partial<UserProfile>) => void;
}

export default function ProficiencyRadarChart({
  userProfile,
  onUpdateUserProfile,
}: ProficiencyRadarChartProps) {
  const [selectedSkillForPractice, setSelectedSkillForPractice] = useState<string | null>(null);
  const [practicing, setPracticing] = useState(false);
  const [practiceSuccess, setPracticeSuccess] = useState<string | null>(null);

  // Compute stats dynamically from the user profile data to make it live and authentic
  const words = userProfile?.wordsLearned || 0;
  const xp = userProfile?.xp || 0;
  const streak = userProfile?.streak || 0;
  const studyMins = userProfile?.studyTime ? Math.round(userProfile.studyTime / 60) : 0;

  // Let's establish baseline levels
  // Reading: strongly correlated with vocabulary words learned
  const baseReading = Math.min(95, 15 + Math.min(words * 5, 60) + Math.min(xp / 15, 20));
  // Writing: grammar, structures, goals
  const baseWriting = Math.min(95, 10 + Math.min(studyMins * 0.8, 55) + Math.min(words * 2, 30));
  // Speaking: active phonetics, streak
  const baseSpeaking = Math.min(95, 20 + Math.min(streak * 4, 45) + Math.min(studyMins * 0.5, 30));
  // Listening: exposure, xp
  const baseListening = Math.min(95, 15 + Math.min(xp / 10, 50) + Math.min(streak * 2, 30));

  // Allow custom overrides in state if practicing
  const [readingBonus, setReadingBonus] = useState(0);
  const [writingBonus, setWritingBonus] = useState(0);
  const [speakingBonus, setSpeakingBonus] = useState(0);
  const [listeningBonus, setListeningBonus] = useState(0);

  const finalReading = Math.round(Math.max(10, baseReading + readingBonus));
  const finalWriting = Math.round(Math.max(10, baseWriting + writingBonus));
  const finalSpeaking = Math.round(Math.max(10, baseSpeaking + speakingBonus));
  const finalListening = Math.round(Math.max(10, baseListening + listeningBonus));

  const data = [
    { subject: "Speaking", Level: finalSpeaking, fullMark: 100 },
    { subject: "Listening", Level: finalListening, fullMark: 100 },
    { subject: "Reading", Level: finalReading, fullMark: 100 },
    { subject: "Writing", Level: finalWriting, fullMark: 100 },
  ];

  // Practical skill-building simulations
  const handleSimulatePractice = async (skill: string) => {
    setSelectedSkillForPractice(skill);
    setPracticing(true);
    setPracticeSuccess(null);

    // Short elegant simulated drill
    setTimeout(async () => {
      setPracticing(false);
      let earnedXp = 15;
      
      if (skill === "Speaking") {
        setSpeakingBonus((b) => Math.min(25, b + 5));
        setPracticeSuccess("Pronunciation Drill Completed! Speaking +5 points!");
      } else if (skill === "Listening") {
        setListeningBonus((b) => Math.min(25, b + 5));
        setPracticeSuccess("Phonetic Listening Drill Completed! Listening +5 points!");
      } else if (skill === "Reading") {
        setReadingBonus((b) => Math.min(25, b + 5));
        setPracticeSuccess("Lexicon Comprehension Drill Completed! Reading +5 points!");
      } else if (skill === "Writing") {
        setWritingBonus((b) => Math.min(25, b + 5));
        setPracticeSuccess("Grammar Synthesis Drill Completed! Writing +5 points!");
      }

      // Grant actual XP reward!
      if (userProfile) {
        const currentXp = userProfile.xp || 0;
        const newXp = currentXp + earnedXp;
        const newLevel = Math.floor(newXp / 100) + 1;
        onUpdateUserProfile({ xp: newXp, level: newLevel });

        if (userProfile.uid) {
          try {
            const userRef = doc(db, "users", userProfile.uid);
            await updateDoc(userRef, { xp: newXp, level: newLevel });
          } catch (e) {
            console.error("Failed to sync simulated drill rewards:", e);
          }
        }
      }

      setTimeout(() => {
        setPracticeSuccess(null);
        setSelectedSkillForPractice(null);
      }, 3000);
    }, 1500);
  };

  const getOverallProficiencyCategory = () => {
    const avg = (finalSpeaking + finalListening + finalReading + finalWriting) / 4;
    if (avg >= 80) return { title: "Proficient Polyglot", color: "text-emerald-600", desc: "Fluent processing with quick recall kinetics." };
    if (avg >= 55) return { title: "Vibrant Intermediate", color: "text-[#2d7a64]", desc: "Steady expression with structured syntax building." };
    return { title: "Aspiring Novice", color: "text-[#0f241d70]", desc: "Laying vital phonetic and vocabulary foundations." };
  };

  const status = getOverallProficiencyCategory();

  return (
    <div className="bg-white border border-[#0f241d15] p-6 space-y-6">
      
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-[#0f241d08]">
        <div>
          <div className="flex items-center gap-1.5 text-[#2d7a64]">
            <Award className="w-4 h-4 animate-pulse" />
            <span className="text-[10px] font-mono uppercase tracking-[0.12em] font-semibold">
              Cognitive Proficiency Matrix
            </span>
          </div>
          <h3 className="text-xl font-sans font-semibold tracking-tight font-medium text-[#0f241d]">
            Polyglot Skill Radar
          </h3>
          <p className="text-[10px] font-mono uppercase text-[#0f241d50] tracking-wider mt-0.5">
            Real-time balance of passive comprehension & active expression
          </p>
        </div>

        <div className="text-right">
          <span className="text-[8px] font-mono uppercase text-[#0f241d40] block">Global Index</span>
          <span className={`text-xs font-mono font-bold uppercase tracking-wider ${status.color}`}>
            {status.title}
          </span>
        </div>
      </div>

      {/* MATRIX LAYOUT */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        
        {/* RADAR CHART VISUALIZATION */}
        <div className="md:col-span-7 flex justify-center items-center min-h-[250px] relative">
          <ResponsiveContainer width="100%" height={260}>
            <RadarChart cx="50%" cy="50%" outerRadius="75%" data={data}>
              <PolarGrid stroke="#0f241d10" />
              <PolarAngleAxis
                dataKey="subject"
                tick={{ fill: "#0f241d80", fontSize: 10, fontFamily: "JetBrains Mono" }}
              />
              <PolarRadiusAxis
                angle={45}
                domain={[0, 100]}
                tick={{ fill: "#0f241d40", fontSize: 8 }}
                axisLine={false}
              />
              <Radar
                name="Proficiency"
                dataKey="Level"
                stroke="#2d7a64"
                fill="#2d7a64"
                fillOpacity={0.35}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* METRICS & DRILLS SIDEBAR */}
        <div className="md:col-span-5 space-y-4">
          <div className="p-4 bg-[#f3f7f5] border border-[#0f241d05] space-y-2">
            <span className="text-[8px] font-mono uppercase text-[#0f241d40] tracking-wider block">
              Skill Breakdown Profile
            </span>
            <div className="space-y-2">
              {data.map((item) => (
                <div key={item.subject} className="space-y-1">
                  <div className="flex justify-between items-baseline text-xs">
                    <span className="font-mono text-[#0f241d70]">{item.subject}</span>
                    <span className="font-mono font-bold text-[#0f241d]">{item.Level}%</span>
                  </div>
                  <div className="w-full bg-[#0f241d08] h-1">
                    <div
                      style={{ width: `${item.Level}%` }}
                      className="bg-[#2d7a64] h-full transition-all duration-500"
                    />
                  </div>
                </div>
              ))}
            </div>
            <p className="text-[9px] font-mono text-[#0f241d50] pt-2 leading-tight">
              {status.desc}
            </p>
          </div>

          {/* ACTIVE PRACTICE ACTIONS */}
          <div className="space-y-2">
            <span className="text-[8px] font-mono uppercase text-[#0f241d40] tracking-wider block font-bold">
              Practice Drills (Skill Booster)
            </span>
            <div className="grid grid-cols-2 gap-2">
              {["Speaking", "Listening", "Reading", "Writing"].map((skill) => {
                const isThisSkill = selectedSkillForPractice === skill;
                return (
                  <button
                    key={skill}
                    onClick={() => handleSimulatePractice(skill)}
                    disabled={practicing}
                    className="p-3 border border-[#0f241d10] hover:border-black bg-white hover:bg-[#f3f7f5] text-left space-y-1 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-[#0f241d] font-semibold">
                        {skill}
                      </span>
                      <Zap className="w-3 h-3 text-[#2d7a64]" />
                    </div>
                    <span className="text-[8px] font-mono text-[#0f241d40] block">
                      {isThisSkill && practicing ? "Drilling..." : "+15 XP Reward"}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

      </div>

      {/* FEEDBACK BANNER */}
      {practiceSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-800 text-[10px] font-mono uppercase font-bold text-center flex items-center justify-center gap-1.5 animate-pulse">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          {practiceSuccess}
        </div>
      )}

    </div>
  );
}
