import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MULTILINGUAL_DATA, VocabWord, ExpressionPhrase, GrammarRule } from "../data/multilingualHubData";
import { UserProfile } from "../types";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";
import PronunciationPractice from "./PronunciationPractice";
import {
  Volume2,
  Compass,
  Star,
  Sparkles,
  Lock,
  X,
  Play,
  Pause,
  ArrowRight,
  Mic,
  Video,
  Brain,
  Search,
  Plus,
  PenTool,
  CheckCircle,
  RefreshCw
} from "lucide-react";

interface LearningPortalProps {
  userProfile: UserProfile | null;
  onUpdateUserProfile: (updates: Partial<UserProfile>) => void;
  onNavigate: (screen: string) => void;
  onOpenBilling?: () => void;
  selectedLanguageId?: string;
  onSelectLanguage?: (langId: string) => void;
}

const LANGUAGE_ESSAYS: Record<string, { p1: string; p2: string }> = {
  kannada: {
    p1: "Kannada, one of the classical languages of India, possesses a rich literary history spanning over a millennium and a half. As a principal Dravidian language, its epigraphical records date back to the Halmidi inscription of 450 CE. It flourished under the patronage of historic empires like the Kadambas, Chalukyas, and the Rashtrakutas, whose court poets crafted exquisite epics.",
    p2: "The language is celebrated for its deep philological structure, phonetic precision, and its distinct, elegant rounded script. From the ancient poetic treatise of Kavirajamarga to the vibrant modern works of Jnanpith laureates, Kannada bridges antiquity and contemporary linguistic elegance."
  },
  hindi: {
    p1: "Hindi stands as a prominent Indo-Aryan language with deep roots in classical Sanskrit, evolving through Sauraseni Prakrit and Apabhramsha. Written in the highly systematic Devanagari script, it embodies a delicate phonetic harmony where spelling precisely mirrors pronunciation.",
    p2: "As a lingua franca of northern and central India, Hindi represents a rich confluence of cultural history, blending classical Indo-Aryan vocabulary with Persian, Arabic, and Sanskrit elements. Its literature ranges from medieval bhakti poetry to modern prose masterpieces."
  },
  spanish: {
    p1: "Spanish, or Castilian, is a Romance language that evolved from Vulgar Latin on the Iberian Peninsula. Its journey was shaped by the historical fusion of Celtic, Iberian, and Arabic influences, leaving a lasting mark on its rich lexicon and phonetic cadence.",
    p2: "Today, it serves as a vibrant global tongue uniting diverse cultures across Europe and the Americas. Its editorial legacy is anchored by the classical prose of Cervantes and the magic realism of Latin American giants, celebrated for its expressive, rhythmic vitality."
  },
  french: {
    p1: "French, historically the international language of diplomacy and high culture, emerged from the Gallo-Romance dialects of northern Gaul. Its evolutionary path was heavily influenced by Germanic Frankish tongues, giving French its distinct nasal vowels and sophisticated phonology.",
    p2: "Revered for its precise grammatical rules and elegant syntax, the language of Molière and Hugo has long been a global symbol of philosophical discourse and artistic expression. It continues to be a cornerstone of post-Enlightenment editorial prestige."
  },
  german: {
    p1: "German, a major West Germanic language, is renowned for its logical complexity, extensive compound words, and expressive consonant clusters. It developed through the High German consonant shift, solidifying its standard modern form through Martin Luther’s biblical translations.",
    p2: "As the language of Goethe, Schiller, and Kant, German possesses a monumental philosophical and scientific heritage. Its structured grammar, with four distinct noun cases, provides an unparalleled level of precision for technical and creative composition alike."
  },
  japanese: {
    p1: "Japanese is a highly contextual Japonic language distinguished by its complex writing system, which beautifully integrates three distinct scripts: Hiragana, Katakana, and Kanji. Its evolutionary history is deeply intertwined with classical Chinese and indigenous Yamato vocabulary.",
    p2: "Characterized by its unique honorific system (Keigo) and Subject-Object-Verb syntax, the language reflects a profound cultural emphasis on harmony and social alignment. Its literature, from the medieval Tale of Genji to modern visual novels, represents a timeless aesthetic."
  },
  mandarin: {
    p1: "Mandarin Chinese, the most spoken of the Sinitic languages, boasts an unbroken literary tradition extending back thousands of years. It is characterized by its tonal nature, where four distinct pitches alter word meanings entirely, and its logographic writing system.",
    p2: "The written characters serve as an artistic and conceptual bridge across diverse regional dialects. Rooted in classical Confucian texts and Tang dynasty poetry, Mandarin is an editorial masterpiece of concise syntax, deep homophonic richness, and historical depth."
  },
  italian: {
    p1: "Italian, the direct modern heir to Latin, evolved from the Tuscan dialect popularized by the monumental poetry of Dante Alighieri. It is universally celebrated for its melodic cadence, pure vowel sounds, and expressive phonetic structure.",
    p2: "As the language of the Renaissance, opera, and classical art, Italian has profoundly shaped Western high culture. Its grammar and rich vocabulary capture a warm, passionate view of the world, making it a favorite for lovers of music, gastronomy, and literature."
  },
  arabic: {
    p1: "Arabic, a Semitic language of immense antiquity, is renowned for its highly systematic triconsonantal root system. From a three-letter root, an entire family of verbs, nouns, and adjectives can be derived, creating a mathematical and poetic symmetry.",
    p2: "Written in an elegant, flowing cursive script from right to left, Arabic literature spans classical pre-Islamic poetry and profound philosophical treatises. It represents a monumental bridge of global knowledge, preservation, and cultural sophistication."
  },
  korean: {
    p1: "Korean, an isolate language spoken by millions, features Hangul—one of the most scientifically designed and phonetically logical writing systems in human history. Created by King Sejong the Great in 1443, Hangul's letters physically mimic the shape of the mouth during pronunciation.",
    p2: "With a complex system of honorifics and a Subject-Object-Verb sentence structure, Korean communicates rich layers of social relationship and contextual respect. Its modern literature and global cultural wave have brought its unique linguistic beauty to the forefront."
  }
};

const TUTORS: Record<string, { name: string; location: string; avatar: string; description: string; mouthPhonetics: string }> = {
  kannada: {
    name: "Priya Hegde",
    location: "Bangalore, India 🇮🇳",
    avatar: "👩‍🏫",
    description: "Kannada script linguist specializing in conversational Aksharamale phonetics and household noun articulation.",
    mouthPhonetics: "Dental-alveolar stop: place the tip of your tongue against the back of your upper teeth for a soft 'Namaskara' retroflex loop."
  },
  hindi: {
    name: "Rajesh Kumar",
    location: "New Delhi, India 🇮🇳",
    avatar: "👨‍🏫",
    description: "Sanskrit scholar specializing in Devanagari script and phonetic vowel marking articulation.",
    mouthPhonetics: "Retroflex flap: curl the tip of your tongue backwards against the roof of your mouth for the perfect 'Ghar' or 'Shanti' tone."
  },
  english: {
    name: "Sarah Jenkins",
    location: "Oxford, UK 🇬🇧",
    avatar: "👩‍💼",
    description: "Oxford linguistics graduate focusing on RP accent, idioms, and standard phrasal syntax patterns.",
    mouthPhonetics: "Alveolar ridge: place the tongue behind the upper front teeth, letting air flow smoothly for 'Hello' and soft vowels."
  },
  spanish: {
    name: "Sofia Alvarez",
    location: "Seville, Spain 🇪🇸",
    avatar: "👩‍🎨",
    description: "Castilian phonetics specialist expert in dynamic accent pairing and emotional subjunctive expressions.",
    mouthPhonetics: "Trilled 'rr': place the tip of your tongue against the alveolar ridge and let it vibrate rapidly with outward breath."
  },
  french: {
    name: "Chloe Laurent",
    location: "Paris, France 🇫🇷",
    avatar: "👩‍🔬",
    description: "Sorbonne researcher focusing on soft liaison glides and nasal vowel resonance.",
    mouthPhonetics: "Nasal glide: drop the jaw slightly and keep the tongue flat, letting sound resonate through your nasal passage for 'Bonjour'."
  },
  german: {
    name: "Lucas Weber",
    location: "Munich, Germany 🇩🇪",
    avatar: "👨‍💼",
    description: "Grammarian expert in subordinating clausal verb structures and compound word articulation.",
    mouthPhonetics: "Glottal stop (Knacklaut): briefly close and reopen the vocal cords before starting vowel-initial words like 'Wasser'."
  },
  mandarin: {
    name: "Mei Ling Chen",
    location: "Beijing, China 🇨🇳",
    avatar: "👩‍💻",
    description: "Chinese academy professor specializing in the four primary pinyin tones and classifier measure words.",
    mouthPhonetics: "Tone alignment: maintain a high flat pitch for the 1st tone, and drop-then-rise with your voice for the 3rd tone in 'Shuǐ'."
  },
  japanese: {
    name: "Yuki Tanaka",
    location: "Kyoto, Japan 🇯🇵",
    avatar: "👩‍🎨",
    description: "Honorific Keigo hierarchy specialist teaching standard Kyoto articulation and particles.",
    mouthPhonetics: "Syllabic nasal 'n': close the mouth and allow the voice to resonate behind the soft palate for a perfect 'Konnichiwa'."
  },
  arabic: {
    name: "Youssef Al-Farsi",
    location: "Cairo, Egypt 🇸🇦",
    avatar: "👨‍🎨",
    description: "Semitic root specialist expert in Pharyngeal fricative sounds and the Idafa construct state.",
    mouthPhonetics: "Pharyngeal constriction: pull the root of your tongue back against the pharynx wall to articulate the deep throat 'Ma' sound."
  },
  russian: {
    name: "Dmitry Volkov",
    location: "St. Petersburg, Russia 🇷🇺",
    avatar: "👨‍🚀",
    description: "Cyrillic morphology specialist expert in verbal aspect shifts and palatalized consonants.",
    mouthPhonetics: "Palatalization (soft sign): raise the middle of the tongue toward the hard palate while pronouncing 'Privet' consonants."
  }
};

import { apiFetch } from "../utils/api";

export default function LearningPortal({
  userProfile,
  onUpdateUserProfile,
  
  onOpenBilling,
  selectedLanguageId: propSelectedLanguageId,
  onSelectLanguage: propOnSelectLanguage,
}: LearningPortalProps) {
  const [localSelectedLanguageId, setLocalSelectedLanguageId] = useState<string>("kannada");

  const selectedLanguageId = propSelectedLanguageId || localSelectedLanguageId;
  const setSelectedLanguageId = propOnSelectLanguage || setLocalSelectedLanguageId;
  const [activeTab, setActiveTab] = useState<"beginner" | "middleware" | "pro" | "lexicon" | "pronunciation">("beginner");
  const [markedLearned, setMarkedLearned] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem("glossway_marked_learned_words");
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  });

  useEffect(() => {
    localStorage.setItem("glossway_marked_learned_words", JSON.stringify(markedLearned));
  }, [markedLearned]);

  // Extra compiled vocabulary lists loaded from Gemini infinitely
  const [extraVocab, setExtraVocab] = useState<Record<string, VocabWord[]>>({});
  const [extraMiddleware, setExtraMiddleware] = useState<Record<string, ExpressionPhrase[]>>({});
  const [extraPro, setExtraPro] = useState<Record<string, GrammarRule[]>>({});
  const [isExpandingWords, setIsExpandingWords] = useState<boolean>(false);
  const [expansionError, setExpansionError] = useState<string>("");

  // AI Dictionary Lookup
  const [dictionaryQuery, setDictionaryQuery] = useState<string>("");
  const [isSearchingDictionary, setIsSearchingDictionary] = useState<boolean>(false);
  const [dictionaryResult, setDictionaryResult] = useState<{
    word: string;
    pronunciation: string;
    translation: string;
    partOfSpeech: string;
    level: "beginner" | "middleware" | "pro";
    culturalContext: string;
    exampleSentence: string;
    exampleTranslation: string;
  } | null>(null);
  const [dictionaryError, setDictionaryError] = useState<string>("");

  const handleExpandWords = async () => {
    setIsExpandingWords(true);
    setExpansionError("");
    try {
      const res = await apiFetch("/api/expand-words", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          languageId: selectedLanguageId,
          languageName: activeLanguage.name,
          levelName: activeTab,
        }),
        retryAction: () => handleExpandWords(),
        actionName: "Vocabulary Sandbox Expander"
      });

      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || "Failed to load more vocabulary.");
      }

      if (json.success && json.data) {
        if (activeTab === "beginner") {
          setExtraVocab((prev) => ({
            ...prev,
            [selectedLanguageId]: [...(prev[selectedLanguageId] || []), ...json.data]
          }));
        } else if (activeTab === "middleware") {
          setExtraMiddleware((prev) => ({
            ...prev,
            [selectedLanguageId]: [...(prev[selectedLanguageId] || []), ...json.data]
          }));
        } else if (activeTab === "pro") {
          setExtraPro((prev) => ({
            ...prev,
            [selectedLanguageId]: [...(prev[selectedLanguageId] || []), ...json.data]
          }));
        }
      }
    } catch (err: any) {
      console.error(err);
      setExpansionError(err.message || "Could not connect to the vocabulary compilation engine.");
    } finally {
      setIsExpandingWords(false);
    }
  };

  const handleSearchDictionary = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!dictionaryQuery.trim()) return;

    setIsSearchingDictionary(true);
    setDictionaryError("");
    setDictionaryResult(null);

    try {
      const res = await apiFetch("/api/dictionary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          word: dictionaryQuery,
          targetLanguage: activeLanguage.name,
        }),
        retryAction: () => handleSearchDictionary(),
        actionName: "Linguistic Scholar Dictionary"
      });

      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || "Failed to query the dictionary.");
      }

      if (json.success && json.data) {
        setDictionaryResult(json.data);
      }
    } catch (err: any) {
      console.error(err);
      setDictionaryError(err.message || "Failed to reach dictionary search.");
    } finally {
      setIsSearchingDictionary(false);
    }
  };

  const handleAddDictionaryToBoard = (item: any) => {
    if (!item) return;
    
    // Add the searched word dynamically to their respective tab!
    if (item.level === "beginner") {
      const vocabItem: VocabWord = {
        word: item.word,
        pronunciation: item.pronunciation,
        translation: item.translation,
        partOfSpeech: item.partOfSpeech || "Noun"
      };
      setExtraVocab((prev) => ({
        ...prev,
        [selectedLanguageId]: [...(prev[selectedLanguageId] || []), vocabItem]
      }));
      setActiveTab("beginner");
    } else if (item.level === "middleware") {
      const exprItem: ExpressionPhrase = {
        phrase: item.word,
        pronunciation: item.pronunciation,
        translation: item.translation,
        context: item.partOfSpeech || "General context"
      };
      setExtraMiddleware((prev) => ({
        ...prev,
        [selectedLanguageId]: [...(prev[selectedLanguageId] || []), exprItem]
      }));
      setActiveTab("middleware");
    } else {
      const proItem: GrammarRule = {
        ruleName: item.word,
        explanation: item.culturalContext || "No additional explanation",
        structure: item.partOfSpeech || "Structure matrix",
        examples: [{
          native: item.exampleSentence || "",
          pronunciation: item.pronunciation || "",
          translation: item.exampleTranslation || ""
        }]
      };
      setExtraPro((prev) => ({
        ...prev,
        [selectedLanguageId]: [...(prev[selectedLanguageId] || []), proItem]
      }));
      setActiveTab("pro");
    }

    setDictionaryResult(null);
    setDictionaryQuery("");
  };

  // Pronunciation Video Guide Player state
  const [activeVideoItem, setActiveVideoItem] = useState<{
    wordOrPhrase: string;
    pronunciation: string;
    translation: string;
    type: "word" | "phrase";
    info?: string;
  } | null>(null);

  // Video playback speed controls
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);

  // Simulated Voice Record Sandbox state
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingSuccess, setRecordingSuccess] = useState<boolean>(false);
  const [recordingScore, setRecordingScore] = useState<number | null>(null);
  const [recordingFeedback, setRecordingFeedback] = useState<string>("");

  // AI 100 Sentence Generator State
  const [selectedVocabForExamples, setSelectedVocabForExamples] = useState<{
    word: string;
    translation: string;
    pronunciation: string;
    partOfSpeech?: string;
  } | null>(null);
  const [examplesModel, setExamplesModel] = useState<"chatgpt" | "claude" | "gemini">("gemini");
  const [examplesCount, setExamplesCount] = useState<number>(15);
  const [examplesResult, setExamplesResult] = useState<string>("");
  const [isGeneratingExamples, setIsGeneratingExamples] = useState<boolean>(false);
  const [examplesError, setExamplesError] = useState<string>("");

  // AI Quick Add State
  const [quickAddText, setQuickAddText] = useState<string>("");
  const [isCompilingQuickAdd, setIsCompilingQuickAdd] = useState<boolean>(false);
  const [quickAddError, setQuickAddError] = useState<string>("");
  const [quickAddSuccess, setQuickAddSuccess] = useState<string>("");

  const handleQuickAddCompile = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!quickAddText.trim()) return;

    setIsCompilingQuickAdd(true);
    setQuickAddError("");
    setQuickAddSuccess("");

    try {
      const res = await apiFetch("/api/quick-add-parse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          textList: quickAddText,
          targetLanguage: activeLanguage.name,
        }),
        retryAction: () => handleQuickAddCompile(),
        actionName: "Interactive Quick Add Compiler"
      });

      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || "Failed to compile the quick-add list.");
      }

      if (json.success && Array.isArray(json.data)) {
        const parsedItems = json.data;
        if (parsedItems.length === 0) {
          throw new Error("No words or phrases could be parsed. Please try pasting a different format.");
        }

        const newBeginners: VocabWord[] = [];
        const newMiddlewares: ExpressionPhrase[] = [];
        const newPros: GrammarRule[] = [];

        parsedItems.forEach((item: any) => {
          if (item.category === "beginner") {
            newBeginners.push({
              word: item.word,
              pronunciation: item.pronunciation,
              translation: item.translation,
              partOfSpeech: item.partOfSpeech || "Noun",
            });
          } else if (item.category === "middleware") {
            newMiddlewares.push({
              phrase: item.word,
              pronunciation: item.pronunciation,
              translation: item.translation,
              context: item.context || item.partOfSpeech || "Conversational Phrase",
            });
          } else if (item.category === "pro") {
            newMiddlewares.push({
              phrase: item.word,
              pronunciation: item.pronunciation,
              translation: item.translation,
              context: item.explanation || item.partOfSpeech || "Sentence Pattern",
            });
            newPros.push({
              ruleName: item.word,
              explanation: item.explanation || "No additional explanation",
              structure: item.structure || "Sentence Pattern",
              examples: item.examples || [{
                native: item.exampleSentence || item.word || "",
                pronunciation: item.pronunciation || "",
                translation: item.exampleTranslation || item.translation || "",
              }],
            });
          }
        });

        if (newBeginners.length > 0) {
          setExtraVocab((prev) => ({
            ...prev,
            [selectedLanguageId]: [...(prev[selectedLanguageId] || []), ...newBeginners],
          }));
        }

        if (newMiddlewares.length > 0) {
          setExtraMiddleware((prev) => ({
            ...prev,
            [selectedLanguageId]: [...(prev[selectedLanguageId] || []), ...newMiddlewares],
          }));
        }

        if (newPros.length > 0) {
          setExtraPro((prev) => ({
            ...prev,
            [selectedLanguageId]: [...(prev[selectedLanguageId] || []), ...newPros],
          }));
        }

        // Award dynamic XP!
        if (userProfile) {
          const earnedXp = parsedItems.length * 10;
          const currentXp = userProfile.xp || 0;
          const newXp = currentXp + earnedXp;
          const newLevel = Math.floor(newXp / 100) + 1;
          onUpdateUserProfile({ xp: newXp, level: newLevel });

          if (userProfile.uid) {
            try {
              const userRef = doc(db, "users", userProfile.uid);
              await updateDoc(userRef, { xp: newXp, level: newLevel });
            } catch (e) {
              console.error("Failed to sync quick-add XP rewards:", e);
            }
          }
        }

        setQuickAddSuccess(
          `Successfully compiled and injected ${parsedItems.length} custom flashcards into your tabs! (+${parsedItems.length * 10} XP Awarded)`
        );
        setQuickAddText("");
      } else {
        throw new Error("Invalid or empty response structure from Gemini.");
      }
    } catch (err: any) {
      console.error(err);
      setQuickAddError(err.message || "Failed to parse the provided list. Please check your connection or format.");
    } finally {
      setIsCompilingQuickAdd(false);
    }
  };

  // AI Composition Critique State
  const [compositionText, setCompositionText] = useState<string>("");
  const [isAnalyzingComposition, setIsAnalyzingComposition] = useState<boolean>(false);
  const [compositionCritique, setCompositionCritique] = useState<{
    score: number;
    cefrLevel: string;
    critique: {
      grammar: string;
      vocabulary: string;
      flow: string;
    };
    errors: {
      original: string;
      correction: string;
      explanation: string;
    }[];
    vocabularySuggestions: {
      word: string;
      suggestion: string;
      explanation: string;
    }[];
    polishedVersion: string;
    translationOfPolished: string;
  } | null>(null);
  const [compositionError, setCompositionError] = useState<string>("");
  const [compositionSuccess, setCompositionSuccess] = useState<string>("");

  const handleCompositionSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!compositionText.trim()) return;

    setIsAnalyzingComposition(true);
    setCompositionError("");
    setCompositionSuccess("");
    setCompositionCritique(null);

    try {
      const res = await apiFetch("/api/composition-critique", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: compositionText,
          targetLanguage: activeLanguage.name,
        }),
        retryAction: () => handleCompositionSubmit(),
        actionName: "Creative Composition Analyst"
      });

      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || "Failed to analyze composition.");
      }

      if (json.success && json.data) {
        setCompositionCritique(json.data);
        
        // Award XP for creative composition writing!
        if (userProfile) {
          // Dynamic XP based on length of text, capped at 150 XP
          const wordsCount = compositionText.trim().split(/\s+/).length;
          const earnedXp = Math.min(150, Math.max(30, wordsCount * 4));
          const currentXp = userProfile.xp || 0;
          const newXp = currentXp + earnedXp;
          const newLevel = Math.floor(newXp / 100) + 1;
          onUpdateUserProfile({ xp: newXp, level: newLevel });

          if (userProfile.uid) {
            try {
              const userRef = doc(db, "users", userProfile.uid);
              await updateDoc(userRef, { xp: newXp, level: newLevel });
            } catch (e) {
              console.error("Failed to sync composition XP rewards:", e);
            }
          }
          setCompositionSuccess(`Composition analyzed with high fidelity! +${earnedXp} XP Awarded.`);
        } else {
          setCompositionSuccess("Composition analyzed with high fidelity!");
        }
      } else {
        throw new Error("Invalid response format received from critique server.");
      }
    } catch (err: any) {
      console.error(err);
      setCompositionError(err.message || "Failed to analyze your text. Please try again.");
    } finally {
      setIsAnalyzingComposition(false);
    }
  };

  const handleOpenSentenceExamples = (
    word: string,
    translation: string,
    pronunciation: string,
    partOfSpeech?: string
  ) => {
    setSelectedVocabForExamples({ word, translation, pronunciation, partOfSpeech });
    setExamplesResult("");
    setExamplesError("");
  };

  const handleGenerateExamples = async () => {
    if (!selectedVocabForExamples) return;
    setIsGeneratingExamples(true);
    setExamplesResult("");
    setExamplesError("");
    try {
      const response = await apiFetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: `Please frame exactly ${examplesCount} unique, illustrative, and context-aware example sentences in ${activeLanguage.name} using the vocabulary word "${selectedVocabForExamples.word}" (translation: "${selectedVocabForExamples.translation}", part of speech: "${selectedVocabForExamples.partOfSpeech || 'N/A'}"). 

Each of the ${examplesCount} sentences MUST follow this exact layout, numbered from 1 to ${examplesCount}:
[Number]. **Foreign sentence in ${activeLanguage.name}**: [Sentence]
   - English translation: [Translation]
   - Pronunciation guide: [Pronunciation]

Categorize the sentences into thematic groups (e.g. casual greeting, travel, academic, etc.) so that they are organized and structured. Keep the vocabulary appropriate for dynamic study.`,
          modelType: examplesModel,
          language: activeLanguage.name
        }),
        retryAction: () => handleGenerateExamples(),
        actionName: "Linguistic Example Framer"
      });
      const data = await response.json();
      if (response.ok && data && data.text) {
        setExamplesResult(data.text);
      } else {
        const errMsg = data?.error || "Received an invalid or empty response from the AI linguistic engine.";
        setExamplesError(`Error: ${errMsg}`);
      }
    } catch (err: any) {
      console.error(err);
      setExamplesError(`Connection failed: ${err.message || "Could not reach the AI framing service. Please ensure the backend server is active."}`);
    } finally {
      setIsGeneratingExamples(false);
    }
  };

  const activeLanguage = MULTILINGUAL_DATA.find((l) => l.id === selectedLanguageId) || MULTILINGUAL_DATA[0];
  const combinedMiddleware = [
    ...activeLanguage.middleware,
    ...(extraMiddleware[selectedLanguageId] || [])
  ];
  const combinedPro = [
    ...activeLanguage.pro,
    ...(extraPro[selectedLanguageId] || [])
  ];
  const combinedBeginner = [
    ...activeLanguage.beginner,
    ...(extraVocab[selectedLanguageId] || [])
  ];

  const activeTutor = TUTORS[selectedLanguageId] || TUTORS["kannada"];

  const activeAudioRef = useRef<HTMLAudioElement | null>(null);
  const [, setIsPlayingVoice] = useState(false);

  // Speech synthesis helper matching the target playback speed
  const handleSpeak = async (text: string, langId: string, speedModifier: number = 1.0) => {
    // Stop any ongoing native audio playbacks
    if (activeAudioRef.current) {
      activeAudioRef.current.pause();
      activeAudioRef.current = null;
    }

    const langNameMap: Record<string, string> = {
      english: "English (Oxford UK standard voice)",
      spanish: "Castilian Spanish (Seville voice)",
      french: "French (Paris voice)",
      german: "German (Munich voice)",
      mandarin: "Mandarin Chinese (Beijing voice)",
      japanese: "Japanese (Kyoto voice)",
      hindi: "Hindi (New Delhi fluent voice)",
      russian: "Russian (St. Petersburg voice)",
      arabic: "Modern Standard Arabic (fluent local voice)",
      kannada: "Kannada (fluent voice, perfectly natural articulation for Bangalore/Karnataka people)",
    };

    const targetLangName = langNameMap[langId] || langId;

    try {
      setIsPlayingVoice(true);
      const res = await apiFetch("/api/speak", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text,
          language: targetLangName
        }),
        retryAction: () => handleSpeak(text, langId, speedModifier),
        actionName: "voice Synth"
      });

      if (!res.ok) {
        throw new Error("Generative voice engine returned non-ok status");
      }

      const data = await res.json();
      if (!data.audio) {
        throw new Error("No audio payload returned");
      }

      // Play the base64-encoded audio
      const audioUrl = `data:${data.mimeType || "audio/wav"};base64,${data.audio}`;
      const audioObj = new Audio(audioUrl);
      activeAudioRef.current = audioObj;
      
      // Apply the playback rate (playbackSpeed)
      audioObj.playbackRate = speedModifier;
      
      await audioObj.play();
      setIsPlayingVoice(false);
    } catch (err) {
      console.warn("Falling back to client SpeechSynthesis due to voice engine error:", err);
      setIsPlayingVoice(false);

      if (!window.speechSynthesis) return;
      
      // Stop any ongoing speech
      window.speechSynthesis.cancel();
      
      const utterance = new SpeechSynthesisUtterance(text);
      
      const activeVoice = (window as any).__activeVoice;
      const activeLangTag = (window as any).__activeLanguageTag;

      if (activeVoice) {
        utterance.voice = activeVoice;
      }
      utterance.lang = activeLangTag || "en-US";
      // Adjust speed based on speed modifier: 1.0x -> 0.85 (slightly slower), 0.75x -> 0.6, 0.5x -> 0.4
      utterance.rate = 0.85 * speedModifier;
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleMarkAsLearned = async (itemKey: string, xpReward: number) => {
    if (markedLearned[itemKey]) return; // already marked in this local session

    setMarkedLearned((prev) => ({ ...prev, [itemKey]: true }));

    // Increment user wordsLearned and xp
    const currentWords = userProfile?.wordsLearned || 0;
    const currentXp = userProfile?.xp || 0;

    const newWords = currentWords + 1;
    const newXp = currentXp + xpReward;
    
    // Simple level up mechanism: every 100 XP is a level
    const newLevel = Math.floor(newXp / 100) + 1;

    onUpdateUserProfile({
      wordsLearned: newWords,
      xp: newXp,
      level: newLevel,
    });

    if (userProfile?.uid) {
      try {
        const userRef = doc(db, "users", userProfile.uid);
        await updateDoc(userRef, {
          wordsLearned: newWords,
          xp: newXp,
          level: newLevel,
        });
      } catch (err) {
        console.error("Failed to sync learned word to database:", err);
      }
    }
  };

  // Triggered when practicing pronunciation
  const handlePracticeVoice = () => {
    setIsRecording(true);
    setRecordingSuccess(false);
    setRecordingScore(null);
    setRecordingFeedback("");

    // Speak word initially to guide the user
    if (activeVideoItem) {
      handleSpeak(activeVideoItem.wordOrPhrase, selectedLanguageId, playbackSpeed);
    }

    // Simulate 3 seconds of listing & signal analysis
    setTimeout(() => {
      setIsRecording(false);
      setRecordingSuccess(true);
      // Perfect high-fidelity simulated scores
      const score = Math.floor(Math.random() * 15) + 85; // 85% to 99%
      setRecordingScore(score);

      const feedbackOptions = [
        "Astounding articulation! Your vowel length and syllable stress match our tutor models perfectly.",
        "Beautiful resonance! Just a minor drop in initial syllable release, but overall highly intelligible.",
        "Excellent retroflex tongue placement! You sound exceptionally fluent and clear.",
        "Terrific pacing! Your vocal intonation curve mirrors a standard fluent speaker's phrasing structure."
      ];
      setRecordingFeedback(feedbackOptions[Math.floor(Math.random() * feedbackOptions.length)]);

      // Credit XP bonus!
      if (userProfile) {
        const currentXp = userProfile.xp || 0;
        const newXp = currentXp + 10;
        onUpdateUserProfile({ xp: newXp });
        if (userProfile.uid) {
          const userRef = doc(db, "users", userProfile.uid);
          updateDoc(userRef, { xp: newXp }).catch(err => console.error(err));
        }
      }
    }, 2800);
  };


  const renderExpansionEngineBox = () => (
    <div className="col-span-1 md:col-span-2 border-2 border-dashed border-[#0f241d15] p-6 text-center space-y-4 bg-white/50">
      <div className="mx-auto w-10 h-10 bg-[#e8f0eb] border border-[#0f241d10] text-[#2d7a64] flex items-center justify-center rounded-full">
        <Sparkles className="w-5 h-5 animate-pulse" />
      </div>
      <div>
        <h4 className="font-sans font-semibold tracking-tight text-sm font-medium text-black">
          Infinite Language Library Engine
        </h4>
        <p className="text-xs text-[#0f241d50] max-w-md mx-auto">
          Tired of standard words? Harness the vocabulary compiler. Instantly synthesize 15 advanced, high-utility {activeTab} vocabulary terms in {activeLanguage.name} on-demand.
        </p>
      </div>

      {expansionError && (
        <div className="text-xs font-mono text-red-500 bg-red-50 border border-red-100 p-2.5 max-w-sm mx-auto space-y-2">
          <p>⚠️ {expansionError}</p>
          <button
            onClick={handleExpandWords}
            disabled={isExpandingWords}
            className="text-red-700 hover:text-red-900 underline font-mono text-[10px] uppercase tracking-wider cursor-pointer flex items-center justify-center gap-1 mx-auto font-bold"
          >
            <RefreshCw className={`w-3 h-3 ${isExpandingWords ? "animate-spin" : ""}`} />
            <span>Try Again</span>
          </button>
        </div>
      )}

      <button
        onClick={handleExpandWords}
        disabled={isExpandingWords}
        className="mx-auto bg-[#0f241d] hover:bg-[#25332e] disabled:opacity-50 text-white font-mono text-[10px] uppercase tracking-widest px-6 py-3 cursor-pointer transition-colors flex items-center gap-1.5 shadow-sm"
      >
        {isExpandingWords ? (
          <>
            <span className="w-3.5 h-3.5 border-2 border-white/20 border-t-white rounded-full animate-spin"></span>
            Compiling 15 level-up words...
          </>
        ) : (
          <>
            <Plus className="w-3.5 h-3.5" /> Compile 15 Level-Up Words
          </>
        )}
      </button>
    </div>
  );

  return (
    <div className="space-y-8 animate-fade-in pb-12 font-sans text-[#0f241d] relative">
      
      {/* AI 100 CONTEXT-AWARE SENTENCE EXAMPLES OVERLAY */}
      {selectedVocabForExamples && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#0f241d] w-full max-w-[800px] shadow-2xl relative flex flex-col h-[85vh] overflow-hidden">
            
            {/* Header */}
            <div className="p-5 border-b border-[#0f241d10] flex justify-between items-center bg-[#f3f7f5]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#e8f0eb] border border-[#0f241d10] flex items-center justify-center text-[#2d7a64]">
                  <Brain className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs">{activeLanguage.flag}</span>
                    <span className="text-[10px] font-mono uppercase tracking-[0.15em] text-[#0f241d50]">
                      AI Sentence Framing Assistant
                    </span>
                  </div>
                  <h3 className="font-sans font-semibold tracking-tight font-bold text-lg text-[#0f241d]">
                    Context Sentences for "{selectedVocabForExamples.word}"
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setSelectedVocabForExamples(null)}
                className="w-10 h-10 border border-[#0f241d10] hover:bg-neutral-100 flex items-center justify-center cursor-pointer text-[#0f241d] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Config & Controls bar */}
            <div className="p-4 border-b border-[#0f241d10] bg-[#f3f7f5] flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex flex-col gap-1">
                  <label className="text-[9px] font-mono uppercase tracking-wider text-[#0f241d50]">Select AI Model</label>
                  <div className="flex border border-[#0f241d15] bg-white p-0.5">
                    {[
                      { id: "gemini", label: "Gemini 3.5 (Web Grounded)" },
                      { id: "chatgpt", label: "ChatGPT 4o (Analytical)" },
                      { id: "claude", label: "Claude 3.5 (Nuanced)" }
                    ].map((m) => (
                      <button
                        key={m.id}
                        onClick={() => setExamplesModel(m.id as any)}
                        className={`px-3 py-1 text-[9px] font-mono uppercase tracking-wider transition-all cursor-pointer ${
                          examplesModel === m.id
                            ? "bg-[#0f241d] text-[#f3f7f5]"
                            : "hover:bg-neutral-50 text-neutral-600"
                        }`}
                      >
                        {m.id === "gemini" ? "Gemini" : m.id === "chatgpt" ? "ChatGPT" : "Claude"}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-[9px] font-mono uppercase tracking-wider text-[#0f241d50]">Target Sentence Count</label>
                  <div className="flex border border-[#0f241d15] bg-white p-0.5">
                    {[10, 15, 25, 50].map((count) => (
                      <button
                        key={count}
                        onClick={() => setExamplesCount(count)}
                        className={`px-3 py-1 text-[9px] font-mono uppercase tracking-wider transition-all cursor-pointer ${
                          examplesCount === count
                            ? "bg-[#0f241d] text-[#f3f7f5]"
                            : "hover:bg-neutral-50 text-neutral-600"
                        }`}
                      >
                        {count} Sentences
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={handleGenerateExamples}
                disabled={isGeneratingExamples}
                className="w-full sm:w-auto px-6 py-2.5 bg-[#0f241d] hover:bg-[#25332e] disabled:bg-neutral-400 text-white font-mono text-[10px] uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                {isGeneratingExamples ? (
                  <>
                    <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Generating {examplesCount} Examples...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-[#2d7a64] animate-pulse" />
                    Generate {examplesCount} Examples
                  </>
                )}
              </button>
            </div>

            {/* Output body */}
            <div className="flex-1 overflow-y-auto p-6 bg-[#f3f7f5] relative">
              {isGeneratingExamples ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center space-y-4 bg-[#f3f7f5]/80 backdrop-blur-xs z-10 p-6 text-center">
                  <div className="w-12 h-12 border-2 border-[#0f241d10] border-t-[#2d7a64] rounded-full animate-spin" />
                  <div className="space-y-1">
                    <p className="font-sans font-semibold tracking-tight text-lg text-black">Drafting {examplesCount} illustrative examples...</p>
                    <p className="text-xs text-[#0f241d50] max-w-sm">
                      Our linguist compiler is requesting {examplesModel.toUpperCase()} to formulate clean, thematic, context-aware sentences for "{selectedVocabForExamples.word}".
                    </p>
                  </div>
                </div>
              ) : null}

              {examplesError ? (
                <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded-sm space-y-2">
                  <p>{examplesError}</p>
                  <button
                    onClick={handleGenerateExamples}
                    disabled={isGeneratingExamples}
                    className="text-red-800 hover:text-red-950 underline font-mono text-[10px] uppercase tracking-wider cursor-pointer flex items-center gap-1 mt-1 font-bold"
                  >
                    <RefreshCw className={`w-3 h-3 ${isGeneratingExamples ? "animate-spin" : ""}`} />
                    <span>Try Again</span>
                  </button>
                </div>
              ) : null}

              {examplesResult ? (
                <div className="space-y-6 max-w-2xl mx-auto bg-white p-6 md:p-8 border border-[#0f241d10] shadow-sm font-sans">
                  <div className="border-b border-[#0f241d10] pb-4 flex items-center justify-between">
                    <div>
                      <span className="text-[9px] font-mono uppercase tracking-wider text-[#0f241d40]">Target Word:</span>
                      <h4 className="font-sans font-semibold tracking-tight font-extrabold text-2xl text-black flex items-center gap-2">
                        {selectedVocabForExamples.word}
                        <span className="text-xs font-mono font-normal text-[#2d7a64]">[{selectedVocabForExamples.pronunciation}]</span>
                      </h4>
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] font-mono uppercase tracking-wider text-[#0f241d40] block">Translation:</span>
                      <span className="text-sm font-sans font-semibold tracking-tight text-neutral-700 font-semibold">"{selectedVocabForExamples.translation}"</span>
                    </div>
                  </div>

                  <div className="text-sm leading-relaxed text-[#0f241d] whitespace-pre-line select-text">
                    {examplesResult.split("\n").map((para, i) => (
                      <p key={i} className="mb-3 last:mb-0">
                        {para.split("**").map((chunk, j) => {
                          if (j % 2 === 1) {
                            return (
                              <strong key={j} className="text-[#2d7a64] font-extrabold">
                                {chunk}
                              </strong>
                            );
                          }
                          return chunk;
                        })}
                      </p>
                    ))}
                  </div>

                  <div className="border-t border-[#0f241d10] pt-4 mt-6 flex flex-col sm:flex-row justify-between items-center text-[10px] font-mono text-[#0f241d40] gap-2">
                    <span>Generated via expert AI models using curated web reference parameters.</span>
                    <button
                      onClick={() => {
                        if (window.speechSynthesis) {
                          window.speechSynthesis.cancel();
                          const utterance = new SpeechSynthesisUtterance(selectedVocabForExamples.word);
                          const langMap: Record<string, string> = {
                            english: "en-US", spanish: "es-ES", french: "fr-FR", german: "de-DE",
                            mandarin: "zh-CN", japanese: "ja-JP", hindi: "hi-IN", russian: "ru-RU",
                            arabic: "ar-SA", kannada: "kn-IN"
                          };
                          utterance.lang = langMap[selectedLanguageId] || "en-US";
                          window.speechSynthesis.speak(utterance);
                        }
                      }}
                      className="text-[#2d7a64] hover:text-black flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="w-3.5 h-3.5" /> Listen Original Word
                    </button>
                  </div>
                </div>
              ) : (
                !isGeneratingExamples && (
                  <div className="flex flex-col items-center justify-center text-center py-20 space-y-6">
                    <div className="w-16 h-16 bg-white border border-[#0f241d10] flex items-center justify-center text-[#2d7a64] shadow-sm">
                      <Sparkles className="w-8 h-8 animate-pulse" />
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-sans font-semibold tracking-tight text-xl font-medium text-black">Ready for Sentence Generation</h4>
                      <p className="text-xs text-[#0f241d50] max-w-sm mx-auto leading-relaxed">
                        Formulate {examplesCount} context-aware examples with translations and phonetics in {activeLanguage.name} using our dynamic linguistic compilers.
                      </p>
                    </div>
                    <button
                      onClick={handleGenerateExamples}
                      className="px-8 py-3.5 bg-black hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest border border-black cursor-pointer shadow-md transition-all"
                    >
                      Draft Examples Now
                    </button>
                  </div>
                )
              )}
            </div>
          </div>
        </div>
      )}

      {/* MULTIMEDIA VIDEO PRONUNCIATION COACH OVERLAY */}
      {activeVideoItem && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#0f241d] w-full max-w-[440px] shadow-2xl relative flex flex-col max-h-[90vh] overflow-hidden">
            
            {/* Header */}
            <div className="p-4 border-b border-[#0f241d10] flex justify-between items-center bg-[#f3f7f5]">
              <div className="flex items-center gap-2">
                <span className="text-sm">{activeLanguage.flag}</span>
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#0f241d50]">
                  Accent Coach
                </span>
              </div>
              <button
                onClick={() => {
                  setActiveVideoItem(null);
                  setRecordingScore(null);
                  setRecordingSuccess(false);
                  setIsPlaying(false);
                }}
                className="w-8 h-8 border border-[#0f241d10] hover:bg-neutral-100 flex items-center justify-center cursor-pointer text-[#0f241d]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Video Body Reel Simulation Container */}
            <div className="relative flex-1 overflow-y-auto">
              
              {/* Virtual Video Canvas with live pulsing sound bars */}
              <div className="relative aspect-[3/4] bg-[#0f241d] flex flex-col justify-between p-6 overflow-hidden">
                
                {/* Simulated Tutor Portrait */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 space-y-4">
                  
                  {/* Avatar ring pulsing based on playback speed */}
                  <div className="relative">
                    <div className={`w-28 h-28 rounded-full border border-white/20 bg-neutral-800 flex items-center justify-center text-5xl relative z-10 select-none ${
                      isPlaying ? "animate-pulse" : ""
                    }`}>
                      {activeTutor.avatar}
                    </div>
                    {isPlaying && (
                      <div 
                        className="absolute inset-0 border-2 border-[#2d7a64] rounded-full scale-110 animate-ping opacity-30"
                        style={{ animationDuration: `${1.5 / playbackSpeed}s` }}
                      />
                    )}
                  </div>

                  <div className="space-y-1 relative z-10">
                    <h4 className="text-white font-sans font-semibold tracking-tight font-semibold text-lg drop-shadow-md">
                      {activeTutor.name}
                    </h4>
                    <span className="text-[10px] font-mono text-neutral-400 bg-black/40 px-3 py-1 rounded-full border border-white/5 inline-block">
                      {activeTutor.location}
                    </span>
                  </div>

                  {/* Scrolling Subtitle board */}
                  <div className="bg-black/50 backdrop-blur-md p-3.5 border border-white/10 text-center max-w-xs mt-4 relative z-10 rounded-sm">
                    <span className="text-xs font-mono text-[#2d7a64] uppercase tracking-wider block mb-1">
                      Target Pronunciation
                    </span>
                    <span className="text-xl font-bold text-white block">
                      "{activeVideoItem.wordOrPhrase}"
                    </span>
                    <span className="text-xs text-neutral-300 block mt-1">
                      [{activeVideoItem.pronunciation}]
                    </span>
                  </div>
                </div>

                {/* Animated Bottom Audio Sound Waves */}
                <div className="flex justify-center items-end gap-1.5 h-10 w-full relative z-10 pb-2">
                  {[0.4, 0.9, 0.3, 0.75, 1.0, 0.5, 0.8, 0.2, 0.6, 0.95, 0.4].map((height, i) => (
                    <div
                      key={i}
                      className="w-1 bg-[#2d7a64] transition-all"
                      style={{
                        height: isPlaying ? `${height * 100}%` : "15%",
                        transitionDuration: `${0.1 / playbackSpeed}s`
                      }}
                    />
                  ))}
                </div>

                {/* Top Overlay Badge */}
                <div className="absolute top-4 left-4 bg-red-600 text-white font-mono text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-xs flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
                  LIVE ACCENT TUTORING
                </div>
              </div>

              {/* Tutor articulation advice & Phonetics */}
              <div className="p-6 space-y-5 bg-white border-t border-[#0f241d10]">
                <div className="space-y-1">
                  <span className="text-[9px] font-mono uppercase tracking-widest text-[#0f241d55] block">
                    Phonetic Articulation Advice
                  </span>
                  <p className="text-xs font-sans font-semibold tracking-tight text-[#0f241d80] leading-relaxed">
                    {activeTutor.mouthPhonetics}
                  </p>
                </div>

                {/* Playback Settings Panel */}
                <div className="border border-[#0f241d08] bg-[#f3f7f5] p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => {
                        setIsPlaying(!isPlaying);
                        if (!isPlaying) {
                          handleSpeak(activeVideoItem.wordOrPhrase, selectedLanguageId, playbackSpeed);
                        } else {
                          window.speechSynthesis.cancel();
                        }
                      }}
                      className="w-10 h-10 bg-black text-white hover:bg-neutral-800 flex items-center justify-center rounded-full cursor-pointer transition-colors"
                    >
                      {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white translate-x-0.5" />}
                    </button>
                    <div>
                      <span className="text-[9px] font-mono text-[#0f241d50] block uppercase tracking-wider">
                        Acoustic Playback
                      </span>
                      <span className="text-xs font-bold text-[#0f241d]">
                        {activeVideoItem.type === "word" ? "Vocabulary word loop" : "Expression context"}
                      </span>
                    </div>
                  </div>

                  {/* Playback Speed controller */}
                  <div className="flex items-center gap-1.5 bg-white border border-[#0f241d08] p-1">
                    {[1.0, 0.75, 0.5].map((speed) => (
                      <button
                        key={speed}
                        onClick={() => {
                          setPlaybackSpeed(speed);
                          setIsPlaying(true);
                          handleSpeak(activeVideoItem.wordOrPhrase, selectedLanguageId, speed);
                        }}
                        className={`text-[9px] font-mono px-2 py-1 select-none cursor-pointer transition-colors ${
                          playbackSpeed === speed
                            ? "bg-black text-white"
                            : "text-[#0f241d50] hover:text-[#0f241d]"
                        }`}
                      >
                        {speed}x
                      </button>
                    ))}
                  </div>
                </div>

                {/* practice Sandbox Recording Section */}
                <div className="border border-[#2d7a64]/40 bg-[#2d7a64]/5 p-5 space-y-4 rounded-xs">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-1.5 text-[#2d7a64]">
                      <Mic className="w-4 h-4" />
                      <span className="text-[10px] font-mono uppercase tracking-widest font-semibold">
                        Accent Sandbox Practice
                      </span>
                    </div>
                    <span className="text-[8px] font-mono text-[#2d7a64] uppercase tracking-wider">
                      Reward: +10 XP
                    </span>
                  </div>

                  {!isRecording && !recordingSuccess ? (
                    <div className="space-y-3">
                      <p className="text-[11px] text-[#0f241d60] leading-relaxed">
                        Ready to speak? Click the microphone and repeat the phrase aloud to test your syllable articulation accuracy score!
                      </p>
                      <button
                        onClick={handlePracticeVoice}
                        className="w-full py-2.5 bg-black hover:bg-neutral-800 text-white font-mono text-[10px] uppercase tracking-widest cursor-pointer transition-colors"
                      >
                        Start Speaking Challenge 🎙️
                      </button>
                    </div>
                  ) : isRecording ? (
                    <div className="flex flex-col items-center py-4 space-y-3">
                      <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center animate-ping">
                        <Mic className="w-5 h-5 text-white" />
                      </div>
                      <span className="text-[10px] font-mono text-red-600 uppercase tracking-widest font-bold">
                        Now Listening... speak now
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-3 animate-fade-in">
                      <div className="flex items-center justify-between pb-2 border-b border-[#0f241d10]">
                        <div>
                          <span className="text-[9px] font-mono text-[#0f241d50] uppercase block">
                            Simulated Accuracy Score
                          </span>
                          <span className="text-xl font-mono font-bold text-[#2d7a64]">
                            {recordingScore}% Match
                          </span>
                        </div>
                        <span className="text-xs font-sans font-semibold tracking-tight text-emerald-600 bg-emerald-50 px-2 py-1 font-bold">
                          {recordingScore && recordingScore >= 90 ? "Excellent Articulation!" : "Terrific Progress!"}
                        </span>
                      </div>
                      <p className="text-xs text-[#0f241d70] leading-relaxed font-sans font-semibold tracking-tight">
                        "{recordingFeedback}"
                      </p>
                      <button
                        onClick={handlePracticeVoice}
                        className="w-full py-2 bg-white border border-[#0f241d30] hover:bg-neutral-50 text-neutral-800 font-mono text-[9px] uppercase tracking-wider cursor-pointer transition-colors"
                      >
                        Speak Again 🎙️
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <section className="pb-6 border-b border-[#0f241d10] flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[#2d7a64]">
            <Compass className="w-4 h-4" />
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-semibold">Multilingual Center</span>
          </div>
          <h1 className="font-sans font-semibold tracking-tight text-3xl font-medium text-[#0f241d] mt-1">
            Global Learning Portal
          </h1>
          <p className="text-xs text-[#0f241d50] mt-1 max-w-2xl">
            Acquire high fluency step-by-step. Toggle between single beginner words, middleware expressions, and pro-level sentence framing.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-[#e8f0eb] border border-[#0f241d15] p-3 text-right">
            <span className="text-[9px] font-mono text-[#0f241d40] block uppercase tracking-wider">Your Fluency XP</span>
            <span className="font-mono text-sm font-bold text-[#0f241d]">{userProfile?.xp || 0} XP • Lvl {userProfile?.level || 1}</span>
          </div>
        </div>
      </section>

      {/* Language Horizontal Selectors */}
      <div className="flex gap-2 overflow-x-auto pb-3 scrollbar-thin scrollbar-thumb-gray-200" id="language-list">
        {MULTILINGUAL_DATA.map((lang) => {
          const isActive = selectedLanguageId === lang.id;
          return (
            <button
              key={lang.id}
              onClick={() => setSelectedLanguageId(lang.id)}
              className={`px-4 py-3 border text-xs font-mono uppercase tracking-wider whitespace-nowrap cursor-pointer transition-all flex items-center gap-2 shrink-0 ${
                isActive
                  ? "bg-[#0f241d] text-[#f3f7f5] border-[#0f241d]"
                  : "bg-white text-[#0f241d80] border-[#0f241d15] hover:text-[#0f241d] hover:border-[#0f241d]"
              }`}
            >
              <span className="text-sm">{lang.flag}</span>
              <span className="font-bold">{lang.name}</span>
            </button>
          );
        })}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={selectedLanguageId}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.35, ease: "easeInOut" }}
          className="space-y-8"
        >
          {/* PHILOLOGICAL CHRONICLE - EDITORIAL ARTICLE */}
          {(() => {
            const essayObj = LANGUAGE_ESSAYS[selectedLanguageId] || LANGUAGE_ESSAYS.kannada;
            const firstLetter = essayObj.p1.charAt(0);
            const remainingP1 = essayObj.p1.slice(1);

            return (
              <div className="bg-[#f3f7f5] border border-[#0f241d10] p-6 md:p-8 space-y-4">
                <div className="flex items-center justify-between border-b border-[#0f241d10] pb-2">
                  <span className="text-[9px] font-mono uppercase tracking-[0.2em] text-[#2d7a64] font-bold">
                    The Philological Chronicle
                  </span>
                  <span className="text-[9px] font-mono uppercase tracking-widest text-[#0f241d40]">
                    Vol. IV • Origin & Culture
                  </span>
                </div>
                <div className="md:columns-2 gap-8 [column-rule:1px_solid_#0f241d10] text-justify space-y-4">
                  <p className="font-sans font-semibold tracking-tight text-sm text-[#0f241d80] leading-relaxed break-inside-avoid">
                    <span className="float-left text-4xl md:text-5xl font-sans font-semibold tracking-tight font-bold text-[#2d7a64] mr-2 mt-1 leading-[0.8] select-none border-b-2 border-[#2d7a64]/30 pb-1">
                      {firstLetter}
                    </span>
                    {remainingP1}
                  </p>
                  <p className="font-sans font-semibold tracking-tight text-sm text-[#0f241d80] leading-relaxed break-inside-avoid">
                    {essayObj.p2}
                  </p>
                </div>
              </div>
            );
          })()}

        {/* TABS SELECTOR (BEGINNER, MIDDLEWARE, PRO, PRONUNCIATION) */}
      <div className="flex border-b border-[#0f241d10] overflow-x-auto scrollbar-none">
        {(["beginner", "middleware", "pro", "pronunciation"] as const).map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 md:flex-initial text-center px-6 py-3.5 text-xs font-mono uppercase tracking-widest font-semibold border-b-2 cursor-pointer transition-colors whitespace-nowrap ${
                isActive
                  ? "border-[#0f241d] text-[#0f241d]"
                  : "border-transparent text-[#0f241d50] hover:text-[#0f241d]"
              }`}
            >
              {tab === "pro"
                ? "🔒 Pro: Sentence Framing"
                : tab === "pronunciation"
                ? "🎙️ Pronunciation Practice"
                : tab === "beginner"
                ? "Beginner"
                : "Middleware"}
            </button>
          );
        })}
      </div>

      {/* AI LIVE DICTIONARY & CULTURAL EXPLORER */}
      <div className="bg-white border border-[#0f241d10] p-6 space-y-4">
        <div className="flex items-center gap-2 text-[#2d7a64]">
          <Sparkles className="w-4 h-4" />
          <span className="text-[10px] font-mono uppercase tracking-widest font-bold">AI Live Dictionary & Cultural Explorer</span>
        </div>
        <div>
          <h2 className="font-sans font-semibold tracking-tight text-lg font-medium text-black">
            Linguistic Oracle Search
          </h2>
          <p className="text-xs text-[#0f241d50]">
            Search ANY English or {activeLanguage.name} word, idiom, or conversational phrase. Gemini will translate, spell phonetically, categorize difficulty, and explain cultural nuances.
          </p>
        </div>

        <form onSubmit={handleSearchDictionary} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#0f241d40] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={dictionaryQuery}
              onChange={(e) => setDictionaryQuery(e.target.value)}
              placeholder={`Search e.g. "Waterfall", "Please sit down", "Water"...`}
              className="w-full bg-[#f3f7f5] border border-[#0f241d10] pl-10 pr-4 py-3 text-xs font-mono focus:border-[#2d7a64] focus:outline-none"
            />
          </div>
          <button
            type="submit"
            disabled={isSearchingDictionary}
            className="bg-[#0f241d] hover:bg-[#25332e] text-[#f3f7f5] px-5 py-3 text-xs font-mono uppercase tracking-wider cursor-pointer disabled:opacity-50 flex items-center gap-1.5 shrink-0"
          >
            {isSearchingDictionary ? (
              <>
                <span className="w-3 h-3 border-2 border-white/20 border-t-white rounded-full animate-spin"></span>
                Searching...
              </>
            ) : (
              "Explore"
            )}
          </button>
        </form>

        {dictionaryError && (
          <div className="text-xs font-mono text-red-500 bg-red-50 border border-red-100 p-3 space-y-2">
            <p>⚠️ {dictionaryError}</p>
            <button
              onClick={() => handleSearchDictionary()}
              disabled={isSearchingDictionary}
              className="text-red-700 hover:text-red-900 underline font-mono text-[10px] uppercase tracking-wider cursor-pointer flex items-center gap-1 font-bold"
            >
              <RefreshCw className={`w-3 h-3 ${isSearchingDictionary ? "animate-spin" : ""}`} />
              <span>Try Again</span>
            </button>
          </div>
        )}

        {dictionaryResult && (
          <div className="bg-[#f3f7f5] border border-[#2d7a64]/30 p-5 space-y-4 animate-fade-in">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#0f241d05] pb-3">
              <div>
                <span className="text-[8px] font-mono bg-black text-white px-2 py-0.5 uppercase tracking-wider">
                  {dictionaryResult.partOfSpeech || "Vocabulary"}
                </span>
                <span className="text-[8px] font-mono bg-[#2d7a64]/15 text-[#2d7a64] px-2 py-0.5 uppercase tracking-wider ml-2">
                  Level: {dictionaryResult.level || "beginner"}
                </span>
              </div>
              <span className="text-[8px] font-mono text-emerald-600 uppercase tracking-widest font-bold flex items-center gap-0.5">
                ● LIVE VERIFIED
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <span className="text-[8px] font-mono text-[#0f241d40] uppercase">Search Query Result</span>
                <h3 className="font-sans font-semibold tracking-tight font-bold text-2xl text-black">
                  {dictionaryResult.word}
                </h3>
                <p className="text-[10px] font-mono text-[#2d7a64]">
                  Pronunciation: [{dictionaryResult.pronunciation}]
                </p>
                <p className="text-xs text-[#0f241d80] font-sans font-semibold tracking-tight pt-1">
                  Translation: "{dictionaryResult.translation}"
                </p>
              </div>

              {dictionaryResult.culturalContext && (
                <div className="bg-white border border-[#0f241d05] p-3 space-y-1">
                  <span className="text-[8px] font-mono text-[#2d7a64] uppercase block font-bold">Cultural Etymology</span>
                  <p className="text-xs text-[#0f241d70] leading-relaxed font-sans font-semibold tracking-tight">
                    {dictionaryResult.culturalContext}
                  </p>
                </div>
              )}
            </div>

            {dictionaryResult.exampleSentence && (
              <div className="bg-white border border-[#0f241d05] p-3 space-y-1.5">
                <span className="text-[8px] font-mono text-[#0f241d40] uppercase block">Usage Example</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-black">{dictionaryResult.exampleSentence}</span>
                  <button
                    onClick={() => handleSpeak(dictionaryResult.exampleSentence, activeLanguage.id)}
                    className="p-1 rounded-full hover:bg-[#0f241d05] text-[#0f241d40] hover:text-[#0f241d] transition-colors cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <span className="text-xs text-[#0f241d60] font-sans font-semibold tracking-tight block">"{dictionaryResult.exampleTranslation}"</span>
              </div>
            )}

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setDictionaryResult(null)}
                className="text-[9px] font-mono uppercase tracking-widest px-3 py-2 border border-[#0f241d10] hover:border-[#0f241d] cursor-pointer"
              >
                Dismiss
              </button>
              <button
                type="button"
                onClick={() => handleAddDictionaryToBoard(dictionaryResult)}
                className="bg-[#2d7a64] hover:bg-[#B3966E] text-white text-[9px] font-mono uppercase tracking-widest px-4 py-2 cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add to Learning Board (+10 XP)
              </button>
            </div>
          </div>
        )}
      </div>

      {/* AI INSTANT FLASHCARD COMPILER (QUICK ADD) */}
      <div className="bg-white border border-[#0f241d10] p-6 space-y-4">
        <div className="flex items-center gap-2 text-[#2d7a64]">
          <Sparkles className="w-4 h-4" />
          <span className="text-[10px] font-mono uppercase tracking-widest font-bold">AI Quick-Add Studio</span>
        </div>
        <div>
          <h2 className="font-sans font-semibold tracking-tight text-lg font-medium text-black">
            Instant Flashcard Compiler
          </h2>
          <p className="text-xs text-[#0f241d50]">
            Paste a raw list of vocabulary words, conversational phrases, or expressions in English or {activeLanguage.name} (one per line, comma-separated, or as an unstructured list). The Gemini engine will parse, translate, phoneticize, and categorize them into structured flashcards inside the learning boards below.
          </p>
        </div>

        <form onSubmit={handleQuickAddCompile} className="space-y-4">
          <textarea
            value={quickAddText}
            onChange={(e) => setQuickAddText(e.target.value)}
            disabled={isCompilingQuickAdd}
            placeholder={`Paste items here...\ne.g.\n- namaskara\n- oota aaytha?\n- beautiful garden\n- thank you very much`}
            rows={4}
            className="w-full bg-[#f3f7f5] border border-[#0f241d10] p-4 text-xs font-mono focus:border-[#2d7a64] focus:outline-none min-h-[100px] leading-relaxed resize-y"
          />

          <div className="flex justify-between items-center gap-4 flex-wrap">
            <span className="text-[10px] font-mono text-[#0f241d40] uppercase">
              Target Language: <span className="font-bold text-[#0f241d80]">{activeLanguage.name}</span>
            </span>
            <button
              type="submit"
              disabled={isCompilingQuickAdd || !quickAddText.trim()}
              className="bg-[#0f241d] hover:bg-[#25332e] disabled:opacity-40 disabled:cursor-not-allowed text-[#f3f7f5] px-5 py-3 text-xs font-mono uppercase tracking-wider cursor-pointer flex items-center gap-1.5 transition-colors font-semibold"
            >
              {isCompilingQuickAdd ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white/20 border-t-white rounded-full animate-spin"></span>
                  Compiling...
                </>
              ) : (
                <>
                  <Plus className="w-3.5 h-3.5" />
                  Compile & Inject Cards (+10 XP / word)
                </>
              )}
            </button>
          </div>
        </form>

        {quickAddError && (
          <div className="text-xs font-mono text-rose-500 bg-rose-50 border border-rose-100 p-3 space-y-2">
            <p>⚠️ {quickAddError}</p>
            <button
              onClick={() => handleQuickAddCompile()}
              disabled={isCompilingQuickAdd}
              className="text-rose-700 hover:text-rose-900 underline font-mono text-[10px] uppercase tracking-wider cursor-pointer flex items-center gap-1 font-bold"
            >
              <RefreshCw className={`w-3 h-3 ${isCompilingQuickAdd ? "animate-spin" : ""}`} />
              <span>Try Again</span>
            </button>
          </div>
        )}

        {quickAddSuccess && (
          <div className="text-xs font-mono text-emerald-600 bg-emerald-50 border border-emerald-100 p-4 space-y-2">
            <p className="font-bold">✨ {quickAddSuccess}</p>
            <p className="text-[#0f241d60] font-sans">
              Go ahead and click the tabs below (**Beginner**, **Middleware**, or **Pro**) to view and practice with your new custom-tailored cards!
            </p>
          </div>
        )}
      </div>

      {/* AI COMPOSITION STUDIO */}
      <div className="bg-white border border-[#0f241d10] p-6 space-y-6">
        <div className="flex items-center gap-2 text-[#2d7a64]">
          <PenTool className="w-4 h-4" />
          <span className="text-[10px] font-mono uppercase tracking-widest font-bold">AI Composition Studio</span>
        </div>
        <div>
          <h2 className="font-sans font-semibold tracking-tight text-lg font-medium text-black">
            Linguistic Essay Critique
          </h2>
          <p className="text-xs text-[#0f241d50]">
            Draft a short paragraph, diary entry, or creative essay in {activeLanguage.name}. The Gemini editor will perform a real-time deep philological analysis—scoring your proficiency, identifying precise grammatical corrections, proposing stylistic vocabulary alternatives, and providing a masterfully polished version.
          </p>
        </div>

        <form onSubmit={handleCompositionSubmit} className="space-y-4">
          <textarea
            value={compositionText}
            onChange={(e) => setCompositionText(e.target.value)}
            disabled={isAnalyzingComposition}
            placeholder={`Type your paragraph in ${activeLanguage.name} here...\ne.g. write about your day, a hobby, or why you're learning this language.`}
            rows={5}
            className="w-full bg-[#f3f7f5] border border-[#0f241d10] p-4 text-xs font-sans font-semibold tracking-tight focus:border-[#2d7a64] focus:outline-none min-h-[120px] leading-relaxed resize-y"
          />

          <div className="flex justify-between items-center gap-4 flex-wrap">
            <span className="text-[10px] font-mono text-[#0f241d40] uppercase">
              Analyzing in: <span className="font-bold text-[#0f241d80]">{activeLanguage.name}</span>
            </span>
            <div className="flex gap-2">
              {compositionText.trim() && (
                <button
                  type="button"
                  onClick={() => {
                    setCompositionText("");
                    setCompositionCritique(null);
                    setCompositionError("");
                    setCompositionSuccess("");
                  }}
                  className="px-4 py-3 border border-[#0f241d15] text-[#0f241d60] hover:text-[#0f241d] font-mono text-xs uppercase tracking-wider cursor-pointer transition-colors"
                >
                  Clear
                </button>
              )}
              <button
                type="submit"
                disabled={isAnalyzingComposition || !compositionText.trim()}
                className="bg-[#0f241d] hover:bg-[#25332e] disabled:opacity-40 disabled:cursor-not-allowed text-[#f3f7f5] px-5 py-3 text-xs font-mono uppercase tracking-wider cursor-pointer flex items-center gap-1.5 transition-colors font-semibold"
              >
                {isAnalyzingComposition ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white/20 border-t-white rounded-full animate-spin"></span>
                    Analyzing Composition...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    Critique & Polish Paragraph
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {compositionError && (
          <div className="text-xs font-mono text-rose-500 bg-rose-50 border border-rose-100 p-3 space-y-2">
            <p>⚠️ {compositionError}</p>
            <button
              onClick={() => handleCompositionSubmit()}
              disabled={isAnalyzingComposition}
              className="text-rose-700 hover:text-rose-900 underline font-mono text-[10px] uppercase tracking-wider cursor-pointer flex items-center gap-1 font-bold"
            >
              <RefreshCw className={`w-3 h-3 ${isAnalyzingComposition ? "animate-spin" : ""}`} />
              <span>Try Again</span>
            </button>
          </div>
        )}

        {compositionSuccess && (
          <p className="text-xs font-mono text-emerald-600 bg-emerald-50 border border-emerald-100 p-3">
            ✨ {compositionSuccess}
          </p>
        )}

        {/* COMPOSITION CRITIQUE REPORT RESULTS */}
        {compositionCritique && (
          <div className="border border-[#0f241d15] p-5 md:p-6 bg-[#f3f7f5] space-y-6 animate-fade-in">
            {/* Score and CEFR Level Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#0f241d10] pb-4">
              <div className="flex items-center gap-4">
                <div className="bg-[#0f241d] text-[#f3f7f5] w-14 h-14 flex flex-col items-center justify-center border border-[#0f241d] shrink-0">
                  <span className="text-[8px] font-mono uppercase text-[#f3f7f5]/60 leading-none">Score</span>
                  <span className="text-xl font-mono font-bold leading-none">{compositionCritique.score}</span>
                  <span className="text-[7px] font-mono text-[#f3f7f5]/40 leading-none">/100</span>
                </div>
                <div>
                  <h3 className="font-sans font-semibold tracking-tight text-lg font-medium text-black">Editorial Assessment Report</h3>
                  <p className="text-[10px] font-mono text-[#0f241d50] uppercase tracking-wider">
                    Linguistic Level Index: <span className="text-[#2d7a64] font-bold">{compositionCritique.cefrLevel} (CEFR)</span>
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 bg-[#2d7a64]/10 border border-[#2d7a64]/30 px-3 py-1.5 self-start sm:self-center">
                <CheckCircle className="w-3.5 h-3.5 text-[#2d7a64]" />
                <span className="text-[9px] font-mono text-[#2d7a64] uppercase tracking-widest font-bold">Linguistic Critique Ready</span>
              </div>
            </div>

            {/* Three Pillars Analysis */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Grammar Critique */}
              <div className="bg-white border border-[#0f241d08] p-4 space-y-2">
                <div className="flex items-center gap-1.5 text-[#0f241d70]">
                  <span className="text-[9px] font-mono uppercase tracking-widest font-bold">I. Syntactic Grammar</span>
                </div>
                <p className="text-xs text-[#0f241d70] leading-relaxed font-sans font-semibold tracking-tight">
                  {compositionCritique.critique.grammar}
                </p>
              </div>

              {/* Vocabulary Critique */}
              <div className="bg-white border border-[#0f241d08] p-4 space-y-2">
                <div className="flex items-center gap-1.5 text-[#0f241d70]">
                  <span className="text-[9px] font-mono uppercase tracking-widest font-bold">II. Lexical Vocabulary</span>
                </div>
                <p className="text-xs text-[#0f241d70] leading-relaxed font-sans font-semibold tracking-tight">
                  {compositionCritique.critique.vocabulary}
                </p>
              </div>

              {/* Flow & Rhythm Critique */}
              <div className="bg-white border border-[#0f241d08] p-4 space-y-2">
                <div className="flex items-center gap-1.5 text-[#0f241d70]">
                  <span className="text-[9px] font-mono uppercase tracking-widest font-bold">III. Stylistic Flow</span>
                </div>
                <p className="text-xs text-[#0f241d70] leading-relaxed font-sans font-semibold tracking-tight">
                  {compositionCritique.critique.flow}
                </p>
              </div>
            </div>

            {/* Grammatical Corrections */}
            {compositionCritique.errors && compositionCritique.errors.length > 0 ? (
              <div className="space-y-3">
                <h4 className="text-[10px] font-mono uppercase tracking-widest text-[#2d7a64] font-bold">
                  Grammatical & Morphological Fixes ({compositionCritique.errors.length})
                </h4>
                <div className="space-y-3">
                  {compositionCritique.errors.map((err, i) => (
                    <div key={i} className="bg-white border border-[#0f241d08] p-4 space-y-2.5">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                        <div className="p-2.5 bg-rose-50/50 border border-rose-100 font-mono text-[#0f241d80] line-through">
                          <span className="text-[8px] uppercase tracking-wider block text-rose-400 mb-0.5">Original</span>
                          {err.original}
                        </div>
                        <div className="p-2.5 bg-emerald-50/50 border border-emerald-100 font-mono text-black font-semibold">
                          <span className="text-[8px] uppercase tracking-wider block text-emerald-600 mb-0.5 font-bold">Correction</span>
                          {err.correction}
                        </div>
                      </div>
                      <p className="text-xs text-[#0f241d60] font-sans font-semibold tracking-tight pl-1 leading-relaxed">
                        <span className="font-sans font-bold text-[9px] uppercase text-[#0f241d40] mr-1">Explanation:</span>
                        {err.explanation}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-emerald-50/30 border border-emerald-100 p-4 text-xs font-sans font-semibold tracking-tight text-emerald-800 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Pristine syntax! No major grammatical faults were detected. Your structural construction is remarkably sound.</span>
              </div>
            )}

            {/* Vocabulary Enhancements */}
            {compositionCritique.vocabularySuggestions && compositionCritique.vocabularySuggestions.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-[10px] font-mono uppercase tracking-widest text-[#2d7a64] font-bold">
                  Lexical Enhancements
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {compositionCritique.vocabularySuggestions.map((sug, i) => (
                    <div key={i} className="bg-white border border-[#0f241d08] p-3 space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-[#0f241d50] font-mono">{sug.word}</span>
                        <span className="text-[9px] font-mono text-[#0f241d40] uppercase">→</span>
                        <span className="text-[#2d7a64] font-mono font-bold">{sug.suggestion}</span>
                      </div>
                      <p className="text-[11px] text-[#0f241d60] font-sans font-semibold tracking-tight leading-relaxed pt-1">
                        {sug.explanation}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Polished Masterpiece */}
            <div className="border-t border-[#0f241d10] pt-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-[#2d7a64] font-bold">
                  The Polished Masterpiece
                </span>
                <button
                  type="button"
                  onClick={() => handleSpeak(compositionCritique.polishedVersion, activeLanguage.id)}
                  className="px-3 py-1 bg-white border border-[#0f241d10] hover:border-[#0f241d] text-xs font-mono uppercase tracking-widest cursor-pointer flex items-center gap-1.5 transition-colors"
                >
                  <Volume2 className="w-3.5 h-3.5" /> Speak
                </button>
              </div>

              {/* Editorial drop-cap, multi-column magazine display */}
              <div className="bg-white border border-[#0f241d10] p-5 md:p-6 space-y-4">
                {(() => {
                  const polished = compositionCritique.polishedVersion || "";
                  const firstLetter = polished.charAt(0);
                  const remainingText = polished.slice(1);

                  return (
                    <div className="md:columns-2 gap-8 [column-rule:1px_solid_#0f241d10] text-justify space-y-4">
                      <p className="font-sans font-semibold tracking-tight text-sm text-black leading-relaxed break-inside-avoid">
                        <span className="float-left text-4xl md:text-5xl font-sans font-semibold tracking-tight font-bold text-[#2d7a64] mr-2 mt-1 leading-[0.8] select-none border-b-2 border-[#2d7a64]/30 pb-1">
                          {firstLetter}
                        </span>
                        {remainingText}
                      </p>
                      <div className="break-inside-avoid pt-4 md:pt-0 border-t md:border-t-0 border-[#0f241d10]">
                        <span className="text-[8px] font-mono text-[#0f241d40] uppercase block mb-1">
                          English Translation
                        </span>
                        <p className="font-sans font-semibold tracking-tight text-xs text-[#0f241d50] leading-relaxed">
                          "{compositionCritique.translationOfPolished}"
                        </p>
                      </div>
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ACTIVE TAB DISPLAY CARD GRID */}
      <div className="space-y-6">
        
        {/* BEGINNER VIEW */}
        {activeTab === "beginner" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {combinedBeginner.map((vocab, idx) => {
              const itemKey = `${activeLanguage.id}_beg_${idx}`;
              const isLearned = markedLearned[itemKey];

              return (
                <div
                  key={idx}
                  className="bg-[#f3f7f5] border border-[#0f241d08] p-5 flex flex-col justify-between gap-4 hover:border-[#0f241d30] transition-all"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-mono bg-[#0f241d05] border border-[#0f241d10] px-2 py-0.5 text-[#0f241d60] uppercase tracking-wider">
                        {vocab.partOfSpeech}
                      </span>
                      
                      <div className="flex gap-2">
                        {/* Speech audio helper */}
                        <button
                          onClick={() => handleSpeak(vocab.word, activeLanguage.id)}
                          className="p-1 rounded-full hover:bg-[#0f241d08] text-[#0f241d60] hover:text-[#0f241d] transition-colors cursor-pointer"
                          title="Listen Pronunciation"
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                        
                        {/* NEW VIDEO GUIDE TRIGGER BUTTON */}
                        <button
                          onClick={() => {
                            setActiveVideoItem({
                              wordOrPhrase: vocab.word,
                              pronunciation: vocab.pronunciation,
                              translation: vocab.translation,
                              type: "word",
                              info: vocab.partOfSpeech
                            });
                            // Trigger speech automatically inside guide
                            setIsPlaying(true);
                            setPlaybackSpeed(1.0);
                            handleSpeak(vocab.word, activeLanguage.id, 1.0);
                          }}
                          className="p-1 rounded-full hover:bg-[#2d7a64]/15 text-[#2d7a64]/80 hover:text-black transition-colors cursor-pointer flex items-center justify-center"
                          title="Watch Accent Video Coach"
                        >
                          <Video className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <h3 
                      onClick={() => handleOpenSentenceExamples(vocab.word, vocab.translation, vocab.pronunciation, vocab.partOfSpeech)}
                      className="font-sans font-semibold tracking-tight font-bold text-xl text-[#0f241d] hover:text-[#2d7a64] transition-colors cursor-pointer flex items-center gap-1.5 group"
                      title="Generate 100 AI Context Sentences"
                    >
                      {vocab.word}
                      <Sparkles className="w-3.5 h-3.5 text-[#2d7a64] opacity-0 group-hover:opacity-100 transition-opacity" />
                    </h3>
                    <p className="text-[10px] font-mono text-[#0f241d50] uppercase tracking-wide">
                      Phonetic guide: <span className="text-[#2d7a64] font-semibold">[{vocab.pronunciation}]</span>
                    </p>
                    <p className="text-xs text-[#0f241d70] font-sans font-semibold tracking-tight pt-1 border-t border-[#0f241d05]">
                      Meaning: "{vocab.translation}"
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-[#0f241d05]">
                    <span className="text-[8px] font-mono text-[#0f241d40] uppercase tracking-wider">
                      Reward: +10 XP
                    </span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleOpenSentenceExamples(vocab.word, vocab.translation, vocab.pronunciation, vocab.partOfSpeech)}
                        className="text-[9px] font-mono uppercase tracking-widest px-3 py-1.5 transition-colors border border-[#2d7a64]/30 hover:border-[#2d7a64] hover:bg-[#2d7a64]/5 text-[#2d7a64] font-semibold cursor-pointer"
                      >
                        100 AI Sentences
                      </button>
                      <button
                        onClick={() => handleMarkAsLearned(itemKey, 10)}
                        disabled={isLearned}
                        className={`text-[9px] font-mono uppercase tracking-widest px-3 py-1.5 transition-colors border cursor-pointer ${
                          isLearned
                            ? "bg-[#0f241d] text-[#f3f7f5] border-[#0f241d]"
                            : "bg-white text-[#0f241d] border-[#0f241d15] hover:border-[#0f241d]"
                        }`}
                      >
                        {isLearned ? "✓ Learned" : "Mark Learned"}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
            {renderExpansionEngineBox()}
          </div>
        )}

        {/* MIDDLEWARE VIEW */}
        {activeTab === "middleware" && (
          <div className="space-y-4">
            {combinedMiddleware.map((expr, idx) => {
              const itemKey = `${activeLanguage.id}_mid_${idx}`;
              const isLearned = markedLearned[itemKey];

              return (
                <div
                  key={idx}
                  className="bg-[#f3f7f5] border border-[#0f241d08] p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-[#0f241d30] transition-colors"
                >
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-[#2d7a64]/10 text-[#2d7a64] text-[8px] font-mono uppercase tracking-widest px-2 py-0.5">
                        {expr.context}
                      </span>
                      
                      {/* Audio helper */}
                      <button
                        onClick={() => handleSpeak(expr.phrase, activeLanguage.id)}
                        className="p-1 rounded-full hover:bg-[#0f241d08] text-[#0f241d60] hover:text-[#0f241d] transition-colors cursor-pointer"
                        title="Listen voice"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>

                      {/* NEW VIDEO GUIDE TRIGGER BUTTON */}
                      <button
                        onClick={() => {
                          setActiveVideoItem({
                            wordOrPhrase: expr.phrase,
                            pronunciation: expr.pronunciation,
                            translation: expr.translation,
                            type: "phrase",
                            info: expr.context
                          });
                          setIsPlaying(true);
                          setPlaybackSpeed(1.0);
                          handleSpeak(expr.phrase, activeLanguage.id, 1.0);
                        }}
                        className="p-1 rounded-full hover:bg-[#2d7a64]/15 text-[#2d7a64] hover:text-black transition-colors cursor-pointer flex items-center justify-center"
                        title="Watch Accent Video Coach"
                      >
                        <Video className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <h3 className="font-sans font-semibold tracking-tight font-bold text-lg text-[#0f241d]">
                      {expr.phrase}
                    </h3>
                    <p className="text-[10px] font-mono text-[#0f241d50] uppercase tracking-wide">
                      Phonetic pronunciation: <span className="text-[#2d7a64] font-semibold">[{expr.pronunciation}]</span>
                    </p>
                    <p className="text-xs text-[#0f241d70] font-sans font-semibold tracking-tight pt-1 border-t border-[#0f241d05]">
                      English equivalent: "{expr.translation}"
                    </p>
                  </div>

                  <div className="flex md:flex-col justify-between items-end gap-2 shrink-0 pt-4 md:pt-0 border-t md:border-t-0 border-[#0f241d05]">
                    <span className="text-[8px] font-mono text-[#0f241d40] uppercase tracking-wider">
                      Reward: +15 XP
                    </span>
                    <button
                      onClick={() => handleMarkAsLearned(itemKey, 15)}
                      disabled={isLearned}
                      className={`text-[9px] font-mono uppercase tracking-widest px-3 py-1.5 transition-colors border cursor-pointer ${
                        isLearned
                          ? "bg-[#0f241d] text-[#f3f7f5] border-[#0f241d]"
                          : "bg-white text-[#0f241d] border-[#0f241d15] hover:border-[#0f241d]"
                      }`}
                    >
                      {isLearned ? "✓ Learned" : "Mark Learned"}
                    </button>
                  </div>
                </div>
              );
            })}
            {renderExpansionEngineBox()}
            </div>
        )}

        {/* PRO VIEW - BLOCKED BY GORGEOUS GOLDEN PREMIUM LOCK IF NOT PREMIUM */}
        {activeTab === "pro" && (
          <>
            {!userProfile?.premium ? (
              <div className="bg-white border border-[#0f241d15] p-8 md:p-12 text-center space-y-6 relative overflow-hidden">
                <div className="absolute inset-0 bg-[#f3f7f5]/30 backdrop-blur-xs z-0 pointer-events-none" />
                
                <div className="relative z-10 space-y-4">
                  <div className="w-14 h-14 bg-[#f3f7f5] border border-[#2d7a64] text-[#2d7a64] flex items-center justify-center mx-auto shadow-md">
                    <Lock className="w-6 h-6 animate-pulse" />
                  </div>
                  
                  <div className="space-y-2">
                    <span className="text-[9px] font-mono uppercase tracking-widest text-[#2d7a64] font-bold">
                      🔒 PREMIUM SCHOLAR BENEFIT
                    </span>
                    <h3 className="font-sans font-semibold tracking-tight font-medium text-2xl text-black">
                      Elite Sentence Framing & Grammars
                    </h3>
                    <p className="text-xs text-[#0f241d60] max-w-md mx-auto leading-relaxed">
                      Advanced grammatical matrix rules, complex verb conjugation charts, formal-to-informal dialect suffixes, and cultural context formulas are exclusive to Pro Scholar subscribers.
                    </p>
                  </div>

                  <div className="flex flex-col items-center gap-3 pt-3">
                    <div className="flex items-center gap-2 bg-[#e8f0eb] border border-[#0f241d10] px-4 py-1.5">
                      <span className="text-[10px] font-mono text-[#0f241d60]">PRICING TIER:</span>
                      <span className="font-mono text-xs font-bold text-[#0f241d]">₹49 / Month ($0.59)</span>
                    </div>

                    <button
                      onClick={onOpenBilling}
                      className="px-8 py-4 bg-black hover:bg-[#25332e] text-white font-mono text-xs uppercase tracking-widest border border-black cursor-pointer transition-colors flex items-center gap-2 shadow-md hover:scale-101 duration-300"
                    >
                      Unlock Pro Scholar Elite <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {combinedPro.map((rule, idx) => {
                  const itemKey = `${activeLanguage.id}_pro_${idx}`;
                  const isLearned = markedLearned[itemKey];

                  return (
                    <div
                      key={idx}
                      className="bg-[#f3f7f5] border border-[#0f241d08] p-6 space-y-5 hover:border-[#0f241d20] transition-colors"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-[#2d7a64]">
                          <Sparkles className="w-4 h-4" />
                          <span className="text-[9px] font-mono uppercase tracking-widest font-semibold">Sentence Structure Pattern</span>
                        </div>
                        <h3 className="font-sans font-semibold tracking-tight font-medium text-xl text-[#0f241d]">
                          {rule.ruleName}
                        </h3>
                        <p className="text-xs text-[#0f241d70] leading-relaxed font-sans font-semibold tracking-tight">
                          {rule.explanation}
                        </p>
                      </div>

                      <div className="border border-[#0f241d10] bg-white p-4 space-y-1">
                        <span className="text-[8px] font-mono text-[#0f241d40] uppercase tracking-wider block">Formula Matrix</span>
                        <code className="text-[11px] font-mono text-[#0f241d] block bg-[#f3f7f5] p-2 border border-[#0f241d05]">
                          {rule.structure}
                        </code>
                      </div>

                      <div className="space-y-3">
                        <span className="text-[9px] font-mono text-[#0f241d50] uppercase tracking-wider block">Context Examples</span>
                        <div className="grid grid-cols-1 gap-3">
                          {rule.examples.map((ex, exIdx) => (
                            <div key={exIdx} className="border-l-2 border-l-[#2d7a64] pl-3 py-1 space-y-1 bg-white p-3 border border-[#0f241d05]">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <span className="text-xs font-mono font-bold text-[#0f241d]">{ex.native}</span>
                                  <button
                                    onClick={() => handleSpeak(ex.native, activeLanguage.id)}
                                    className="p-1 rounded-full hover:bg-[#0f241d05] text-[#0f241d40] hover:text-[#0f241d] transition-colors cursor-pointer"
                                  >
                                    <Volume2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>

                                {/* Video guide for formula example */}
                                <button
                                  onClick={() => {
                                    setActiveVideoItem({
                                      wordOrPhrase: ex.native,
                                      pronunciation: ex.pronunciation,
                                      translation: ex.translation,
                                      type: "phrase",
                                      info: rule.ruleName
                                    });
                                    setIsPlaying(true);
                                    setPlaybackSpeed(1.0);
                                    handleSpeak(ex.native, activeLanguage.id, 1.0);
                                  }}
                                  className="text-[9px] font-mono text-[#2d7a64] hover:text-black flex items-center gap-1 cursor-pointer"
                                >
                                  <Video className="w-3 h-3" /> Coach
                                </button>
                              </div>
                              <span className="text-[9px] font-mono text-[#2d7a64] block">[{ex.pronunciation}]</span>
                              <span className="text-xs text-[#0f241d60] font-sans font-semibold tracking-tight block">"{ex.translation}"</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="pt-4 border-t border-[#0f241d05] flex justify-between items-center">
                        <div className="flex items-center gap-1 text-[8px] font-mono text-[#0f241d40] uppercase tracking-wider">
                          <Star className="w-3 h-3 text-[#2d7a64] fill-current" />
                          Reward: +25 XP
                        </div>
                        <button
                          onClick={() => handleMarkAsLearned(itemKey, 25)}
                          disabled={isLearned}
                          className={`text-[9px] font-mono uppercase tracking-widest px-4 py-2 transition-colors border cursor-pointer ${
                            isLearned
                              ? "bg-[#0f241d] text-[#f3f7f5] border-[#0f241d]"
                              : "bg-white text-[#0f241d] border-[#0f241d15] hover:border-[#0f241d]"
                          }`}
                        >
                          {isLearned ? "✓ Pattern Learned" : "Mark Pattern Learned"}
                        </button>
                      </div>
                    </div>
                  );
                })}
                {renderExpansionEngineBox()}
            </div>
            )}
          </>
        )}

        {activeTab === "pronunciation" && (
          <PronunciationPractice
            userProfile={userProfile}
            onUpdateUserProfile={onUpdateUserProfile}
            selectedLanguageId={selectedLanguageId}
            activeLanguage={activeLanguage}
            handleSpeak={handleSpeak}
            activeTutor={activeTutor}
          />
        )}
      </div>

      {/* Multilingual Info Footer Portal Link */}
      <section className="bg-[#f3f7f5] border border-[#0f241d15] p-6 space-y-4">
        <h3 className="font-sans font-semibold tracking-tight text-lg font-semibold text-[#0f241d]">
          Global Online Resource Hubs
        </h3>
        <p className="text-xs text-[#0f241d60] leading-relaxed">
          Glosway curates dictionaries and dynamic portals across the web. Explore external portals to expand your corpora:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <a
            href="https://glosbe.com"
            target="_blank"
            rel="noopener noreferrer"
            className="p-4 bg-white border border-[#0f241d10] hover:border-[#2d7a64] transition-all flex justify-between items-center group cursor-pointer"
          >
            <div>
              <span className="font-mono text-xs font-bold text-[#0f241d] block">Glosbe Polyglot Dictionary</span>
              <span className="text-[10px] text-[#0f241d50] block mt-1">Concur translation databases for all 10 target languages.</span>
            </div>
            <span className="text-[9px] font-mono uppercase tracking-wider bg-[#e8f0eb] border border-[#0f241d05] px-2 py-1 text-[#0f241d60] group-hover:text-black">
              Visit Portal
            </span>
          </a>

          <a
            href="https://www.wordreference.com"
            target="_blank"
            rel="noopener noreferrer"
            className="p-4 bg-white border border-[#0f241d10] hover:border-[#2d7a64] transition-all flex justify-between items-center group cursor-pointer"
          >
            <div>
              <span className="font-mono text-xs font-bold text-[#0f241d] block">WordReference Portal</span>
              <span className="text-[10px] text-[#0f241d50] block mt-1">Advanced conjugation matrices and active grammatical forums.</span>
            </div>
            <span className="text-[9px] font-mono uppercase tracking-wider bg-[#e8f0eb] border border-[#0f241d05] px-2 py-1 text-[#0f241d60] group-hover:text-black">
              Visit Portal
            </span>
          </a>
        </div>
      </section>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
