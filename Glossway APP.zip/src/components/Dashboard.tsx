import { useState, useEffect, useMemo } from "react";
import ReactMarkdown from "react-markdown";
import { motion } from "motion/react";
import { UserProfile } from "../types";
import DailyGoalProgress from "./DailyGoalProgress";
import MilestoneCelebration from "./MilestoneCelebration";
import confetti from "canvas-confetti";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";
import { apiFetch } from "../utils/api";
import { LANGUAGES_BLUEPRINTS, LanguageBlueprint } from "../data/languagesData";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from "recharts";
import {
  Sparkles,
  BookOpen,
  Award,
  MessageSquare,
  Headphones,
  Compass,
  Play,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Target,
  Clock,
  Plus,
  Minus,
  Check,
  TrendingUp,
  ExternalLink,
  Brain,
  Info,
  Bell,
  BellOff,
  Flame,
  BookMarked,
  Crown,
  Globe,
  Trophy,
  Shield,
  Trash2,
  AlertCircle,
  ShieldCheck,
} from "lucide-react";

interface DashboardProps {
  userProfile: UserProfile | null;
  onUpdateUserProfile?: (updates: Partial<UserProfile>) => void;
  onNavigate: (screen: string) => void;
  completedDates: string[];
  onToggleDate: (dateStr: string) => void;
  onSelectLanguage?: (langId: string) => void;
  showToast?: (msg: string) => void;
}

const FLAG_MAP: Record<string, string> = {
  kannada: "🇮🇳",
  hindi: "🇮🇳",
  english: "🇬🇧",
  spanish: "🇪🇸",
  french: "🇫🇷",
  german: "🇩🇪",
  mandarin: "🇨🇳",
  japanese: "🇯🇵",
  arabic: "🇸🇦",
  russian: "🇷🇺",
};

const PROTOCOL_WORDS: Record<string, {
  beginner: { word: string; translation: string; pronunciation: string }[];
  mid: { word: string; translation: string; pronunciation: string }[];
  pro: { word: string; translation: string; pronunciation: string }[];
}> = {
  kannada: {
    beginner: [
      { word: "Namaskara (ನಮಸ್ಕಾರ)", translation: "Hello / Greetings", pronunciation: "nuh-muhs-KAH-ruh" },
      { word: "Dhanyavada (ಧನ್ಯವಾದ)", translation: "Thank you", pronunciation: "dhun-yuh-VAH-duh" },
      { word: "Kanna (ಕಣ್ಣು)", translation: "Eye / Sight", pronunciation: "KUN-nu" },
      { word: "Mane (ಮನೆ)", translation: "House / Home", pronunciation: "muh-neh" },
      { word: "Niru (ನೀರು)", translation: "Water", pronunciation: "nee-ru" }
    ],
    mid: [
      { word: "Santhosha (ಸಂತೋಷ)", translation: "Happiness / Joy", pronunciation: "suhn-TOH-shuh" },
      { word: "Parichaya (ಪರಿಚಯ)", translation: "Familiarity / Intro", pronunciation: "puh-ree-CHUH-yuh" },
      { word: "Sahaya (ಸಹಾಯ)", translation: "Help / Assistance", pronunciation: "suh-hah-yuh" }
    ],
    pro: [
      { word: "Adhyatmika (ಆಧ್ಯಾತ್ಮಿಕ)", translation: "Spiritual / Transcendental", pronunciation: "ahd-YAHTH-mee-kuh" },
      { word: "Samskruti (ಸಂಸ್ಕೃತಿ)", translation: "Culture / Tradition", pronunciation: "suhms-KROO-thee" },
      { word: "Swatantrya (ಸ್ವಾತಂತ್ರ್ಯ)", translation: "Independence / Liberty", pronunciation: "swah-thun-thryuh" }
    ]
  },
  hindi: {
    beginner: [
      { word: "Namaste (नमस्ते)", translation: "Hello / Greetings", pronunciation: "nuh-muh-STAY" },
      { word: "Dhanyavaad (धन्यवाद)", translation: "Thank you", pronunciation: "dhun-yuh-VAHD" },
      { word: "Prem (प्रेम)", translation: "Love", pronunciation: "PRAYM" },
      { word: "Ghar (घर)", translation: "House", pronunciation: "ghur" },
      { word: "Paani (पानी)", translation: "Water", pronunciation: "pah-nee" }
    ],
    mid: [
      { word: "Astitva (अस्तित्व)", translation: "Existence / Identity", pronunciation: "uh-STITH-vuh" },
      { word: "Anubhav (अनुभव)", translation: "Experience", pronunciation: "uh-noo-BHUV" },
      { word: "Pratibha (प्रतिभा)", translation: "Talent / Genius", pronunciation: "pruh-tib-hah" }
    ],
    pro: [
      { word: "Prakalp (प्रकल्प)", translation: "Venture / Grand Project", pronunciation: "pruh-KULP" },
      { word: "Atmanirbhar (आत्मनिर्भर)", translation: "Self-reliant / Autonomous", pronunciation: "aht-muh-NIR-bhur" },
      { word: "Sankalp (संकल्प)", translation: "Solemn Resolution / Vow", pronunciation: "sun-KULP" }
    ]
  },
  english: {
    beginner: [
      { word: "Hello", translation: "Greeting of arrival", pronunciation: "huh-LOH" },
      { word: "Gratitude", translation: "Quality of being thankful", pronunciation: "GRAT-i-tood" },
      { word: "Friend", translation: "A person whom one knows and likes", pronunciation: "frend" }
    ],
    mid: [
      { word: "Resilient", translation: "Able to withstand difficulties", pronunciation: "ri-ZIL-yuhnt" },
      { word: "Subtle", translation: "Delicate and precise", pronunciation: "SUHT-l" },
      { word: "Pristine", translation: "In its original clean state", pronunciation: "pris-TEEN" }
    ],
    pro: [
      { word: "Ephemeral", translation: "Lasting for a very short time", pronunciation: "i-FEM-er-uhl" },
      { word: "Serendipity", translation: "Occurring by a happy chance", pronunciation: "ser-uhn-DIP-i-tee" },
      { word: "Ethereal", translation: "Extremely delicate and light", pronunciation: "i-THEER-ee-uhl" }
    ]
  },
  spanish: {
    beginner: [
      { word: "Hola", translation: "Hello", pronunciation: "OH-lah" },
      { word: "Gracias", translation: "Thank you", pronunciation: "GRAH-syahs" },
      { word: "Amor", translation: "Love", pronunciation: "ah-MOHR" },
      { word: "Casa", translation: "House", pronunciation: "KAH-sah" },
      { word: "Amigo", translation: "Friend", pronunciation: "ah-MEE-goh" }
    ],
    mid: [
      { word: "Esperanza", translation: "Hope / Expectation", pronunciation: "es-peh-RAHN-thah" },
      { word: "Desarrollo", translation: "Development / Growth", pronunciation: "deh-sah-RROH-yoh" },
      { word: "Compartir", translation: "To share", pronunciation: "kom-par-TEER" }
    ],
    pro: [
      { word: "Inmarcesible", translation: "Unfading / Everlasting", pronunciation: "een-mar-theh-SEE-bleh" },
      { word: "Acomodamiento", translation: "Accommodation / Adjustment", pronunciation: "ah-koh-moh-dah-MYEN-toh" },
      { word: "Muchedumbre", translation: "Multitude / Great crowd", pronunciation: "moo-cheh-DOOM-breh" }
    ]
  },
  french: {
    beginner: [
      { word: "Bonjour", translation: "Hello / Good morning", pronunciation: "bohn-ZHOOR" },
      { word: "Merci", translation: "Thank you", pronunciation: "mair-SEE" },
      { word: "Ami", translation: "Friend", pronunciation: "ah-MEE" },
      { word: "Famille", translation: "Family", pronunciation: "fah-MEE-yuh" }
    ],
    mid: [
      { word: "Espoir", translation: "Hope", pronunciation: "es-PWAHR" },
      { word: "Bienveillance", translation: "Benevolence / Kindness", pronunciation: "byeh-vay-YAHNSS" },
      { word: "Quotidien", translation: "Daily life / Everyday", pronunciation: "koh-tee-DYEHN" }
    ],
    pro: [
      { word: "Éphémère", translation: "Ephemeral / Fleeting", pronunciation: "ay-fay-MAIR" },
      { word: "S'émerveiller", translation: "To wonder at / Be amazed", pronunciation: "say-mair-vay-YAY" },
      { word: "Dépassement", translation: "Surpassing oneself / Overcoming", pronunciation: "day-pahss-MAHN" }
    ]
  },
  german: {
    beginner: [
      { word: "Hallo", translation: "Hello", pronunciation: "HAH-loh" },
      { word: "Danke", translation: "Thank you", pronunciation: "DAHN-keh" },
      { word: "Freund", translation: "Friend", pronunciation: "froynd" },
      { word: "Wasser", translation: "Water", pronunciation: "VUSS-er" }
    ],
    mid: [
      { word: "Heimat", translation: "Homeland / Sense of belonging", pronunciation: "HY-maht" },
      { word: "Sehnsucht", translation: "Deep yearning / Nostalgia", pronunciation: "ZAYN-zookht" },
      { word: "Gemeinschaft", translation: "Community / Fellowship", pronunciation: "geh-MYN-shuft" }
    ],
    pro: [
      { word: "Zeitgeist", translation: "Spirit of the times", pronunciation: "TSYT-gyst" },
      { word: "Schadenfreude", translation: "Joy at another's misfortune", pronunciation: "SHAH-den-froy-deh" },
      { word: "Weltschmerz", translation: "Weariness of the world", pronunciation: "VELT-shmairts" }
    ]
  },
  mandarin: {
    beginner: [
      { word: "Nǐ hǎo (你好)", translation: "Hello", pronunciation: "nee how" },
      { word: "Xièxie (谢谢)", translation: "Thank you", pronunciation: "shyeh-shyeh" },
      { word: "Péngyǒu (朋友)", translation: "Friend", pronunciation: "pung-yo" },
      { word: "Jiā (家)", translation: "Family / Home", pronunciation: "jyah" }
    ],
    mid: [
      { word: "Xīnwàng (兴旺)", translation: "Prosperous / Flourishing", pronunciation: "sheen-wahng" },
      { word: "Jiānqiáng (坚强)", translation: "Strong / Resilient", pronunciation: "jyen-chyahng" },
      { word: "Xīwàng (希望)", translation: "Hope / Expectation", pronunciation: "shee-wahng" }
    ],
    pro: [
      { word: "Cháorán (超然)", translation: "Transcendent / Detached", pronunciation: "chaow-ran" },
      { word: "Péngbó (蓬勃)", translation: "Vigorous / Booming", pronunciation: "pung-bo" },
      { word: "Zhìhuì (智慧)", translation: "Wisdom / Intellect", pronunciation: "jee-hway" }
    ]
  },
  japanese: {
    beginner: [
      { word: "Konnichiwa (こんにちは)", translation: "Hello / Good afternoon", pronunciation: "kon-nee-chee-wah" },
      { word: "Arigatou (ありがとう)", translation: "Thank you", pronunciation: "ah-ree-gah-toh" },
      { word: "Tomodachi (友達)", translation: "Friend", pronunciation: "toh-moh-dah-chee" },
      { word: "Inu (犬)", translation: "Dog", pronunciation: "ee-noo" }
    ],
    mid: [
      { word: "Natsukashii (懐かしい)", translation: "Nostalgic / Sweetly missed", pronunciation: "nah-tsu-kah-shee" },
      { word: "Komorebi (木漏れ日)", translation: "Sunlight filtering through trees", pronunciation: "ko-mo-reh-bee" },
      { word: "Kizuna (絆)", translation: "Bonds / Emotional connections", pronunciation: "kee-zoo-nah" }
    ],
    pro: [
      { word: "Yūgen (幽玄)", translation: "Profound grace and subtlety", pronunciation: "yoo-gen" },
      { word: "Mono no aware (物の哀れ)", translation: "Pathos and beauty of impermanence", pronunciation: "mo-no no ah-wah-reh" },
      { word: "Wabi-sabi (侘寂)", translation: "Finding beauty in imperfection", pronunciation: "wah-bee sah-bee" }
    ]
  },
  arabic: {
    beginner: [
      { word: "Marhaban (مرحباً)", translation: "Hello / Welcome", pronunciation: "MAR-hah-bahn" },
      { word: "Shukran (شكراً)", translation: "Thank you", pronunciation: "SHOO-kran" },
      { word: "Sadeeq (صديق)", translation: "Friend", pronunciation: "sah-DEEQ" },
      { word: "Bayt (بيت)", translation: "House", pronunciation: "bayt" }
    ],
    mid: [
      { word: "Amal (أمل)", translation: "Hope / Dream", pronunciation: "AH-mahl" },
      { word: "Sadaqah (صدقة)", translation: "Voluntary Charity", pronunciation: "SAH-dah-qah" },
      { word: "Salam (سلام)", translation: "Peace", pronunciation: "sah-LAHM" }
    ],
    pro: [
      { word: "Istishraq (استشراق)", translation: "Orientalism / Deep illumination", pronunciation: "is-tish-RAHQ" },
      { word: "Mustaqbal (مستقبل)", translation: "The Future", pronunciation: "moos-TAQ-bahl" },
      { word: "Hadarah (حضارة)", translation: "Civilization / Culture", pronunciation: "hah-DAH-rah" }
    ]
  },
  russian: {
    beginner: [
      { word: "Privet (Привет)", translation: "Hello (informal)", pronunciation: "pree-VYET" },
      { word: "Spasibo (Спасибо)", translation: "Thank you", pronunciation: "spuh-SEE-buh" },
      { word: "Drug (Друг)", translation: "Friend (male)", pronunciation: "droog" },
      { word: "Dom (Дом)", translation: "House", pronunciation: "dom" }
    ],
    mid: [
      { word: "Nadezhda (Надежда)", translation: "Hope", pronunciation: "nah-DYEZH-duh" },
      { word: "Doverie (Доверие)", translation: "Trust / Confidence", pronunciation: "DOH-vyeh-ryeh" },
      { word: "Uvazhenie (Уважение)", translation: "Respect / Esteem", pronunciation: "oo-vuh-ZHEH-nyeh" }
    ],
    pro: [
      { word: "Bespredel (Беспредел)", translation: "Limitlessness / Total freedom", pronunciation: "byes-pree-DYEL" },
      { word: "Toska (Тоска)", translation: "Melancholy / Spiritual longing", pronunciation: "tah-SKAH" },
      { word: "Sostradanie (Сострадание)", translation: "Compassion / Sympathy", pronunciation: "suh-struh-DAH-nyeh" }
    ]
  }
};

export default function Dashboard({
  userProfile,
  onUpdateUserProfile,
  onNavigate,
  completedDates,
  onToggleDate,
  onSelectLanguage,
  showToast,
}: DashboardProps) {
  const [currentYearMonth, setCurrentYearMonth] = useState({
    year: 2026,
    month: 6, // 0-indexed, so 6 is July 2026
  });

  const [targetMinutes, setTargetMinutes] = useState(userProfile?.dailyGoalMinutes || 15);
  const [todaySeconds, setTodaySeconds] = useState(0);
  const [savingGoal, setSavingGoal] = useState(false);
  const [savingNotifications, setSavingNotifications] = useState(false);
  const [selectedBlueprint, setSelectedBlueprint] = useState<LanguageBlueprint | null>(null);
  const [activeCelebration, setActiveCelebration] = useState<{
    id: string;
    title: string;
    description: string;
    icon: any;
    color: string;
  } | null>(null);
  const [, setIsAddingLanguage] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ message: string; type: "success" | "info" } | null>(null);
  const [manualMinutes, setManualMinutes] = useState("");
  const [simulatePost8PM, setSimulatePost8PM] = useState(false);
  
  // Custom Study Slots & Permission States
  const [newSlotTime, setNewSlotTime] = useState("09:00");
  const [notifPermission, setNotifPermission] = useState<string>(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      return Notification.permission;
    }
    return "default";
  });

  // Learning Protocol State
  const [activeProtocolLang, setActiveProtocolLang] = useState<LanguageBlueprint | null>(null);
  const [protocolTab, setProtocolTab] = useState<"beginner" | "mid" | "pro">("beginner");

  // AI Sentence Framer State
  const [framerWord, setFramerWord] = useState<{ word: string; translation: string; level: string } | null>(null);
  const [framerCount, setFramerCount] = useState<number>(5);
  const [framerModel, setFramerModel] = useState<"chatgpt" | "claude" | "gemini">("gemini");
  const [framerResult, setFramerResult] = useState<string>("");
  const [framerLoading, setFramerLoading] = useState<boolean>(false);

  // Confidence diagnostics tab state
  const [selectedConfidenceTab, setSelectedConfidenceTab] = useState<"vocabulary" | "grammar" | "phrases" | "listening">("vocabulary");

  // AI Mentor State
  const [isMentorOpen, setIsMentorOpen] = useState(false);
  const [isQuickContextMode, setIsQuickContextMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("glossway_mentor_quick_context_enabled");
      return saved !== "false";
    } catch (e) {
      return true;
    }
  });
  const [mentorSuggestions, setMentorSuggestions] = useState<string>(() => {
    try {
      return localStorage.getItem("glossway_mentor_suggestions_cache") || "";
    } catch (e) {
      return "";
    }
  });
  const [isMentorLoading, setIsMentorLoading] = useState(false);
  const [mentorError, setMentorError] = useState<string | null>(null);

  const achievements = useMemo(() => {
    const streak = userProfile?.streak || 0;
    const wordsLearned = userProfile?.wordsLearned || 0;
    const level = userProfile?.level || 1;
    const xp = userProfile?.xp || 0;
    const languagesCount = Object.keys(userProfile?.languages || {}).length;

    return [
      {
        id: "first_word",
        title: "Initiate Scholar",
        description: "Learn your first foreign vocabulary word.",
        icon: Sparkles,
        current: wordsLearned >= 1 ? 1 : 0,
        target: 1,
        unlocked: wordsLearned >= 1,
        suffix: "word",
        accent: "text-emerald-500 bg-emerald-50/50 border-emerald-100",
        color: "#3B82F6",
      },
      {
        id: "streak_10",
        title: "Decastride Champion",
        description: "Maintain an active study streak of 10 days.",
        icon: Flame,
        current: streak,
        target: 10,
        unlocked: streak >= 10,
        suffix: "days",
        accent: "text-amber-600 bg-amber-50/50 border-amber-100",
        color: "#D97706",
      },
      {
        id: "words_100",
        title: "Lexicon Guildmaster",
        description: "Master 100 or more foreign vocabulary words.",
        icon: BookMarked,
        current: wordsLearned,
        target: 100,
        unlocked: wordsLearned >= 100,
        suffix: "words",
        accent: "text-emerald-600 bg-emerald-50/50 border-emerald-100",
        color: "#059669",
      },
      {
        id: "level_5",
        title: "Ascending Scholar",
        description: "Reach proficiency Level 5 in your profile.",
        icon: Crown,
        current: level,
        target: 5,
        unlocked: level >= 5,
        suffix: "level",
        accent: "text-purple-600 bg-purple-50/50 border-purple-100",
        color: "#7C3AED",
      },
      {
        id: "polyglot_2",
        title: "Cosmopolitan",
        description: "Pursue 2 or more language learning pathways.",
        icon: Globe,
        current: languagesCount,
        target: 2,
        unlocked: languagesCount >= 2,
        suffix: "languages",
        accent: "text-teal-600 bg-teal-50/50 border-teal-100",
        color: "#0D9488",
      },
      {
        id: "xp_500",
        title: "Elite Prestige",
        description: "Amass 500 or more total Experience Points (XP).",
        icon: Shield,
        current: xp,
        target: 500,
        unlocked: xp >= 500,
        suffix: "XP",
        accent: "text-[#2d7a64] bg-[#f3f7f5] border-[#2d7a64]/20",
        color: "#2d7a64",
      },
    ];
  }, [userProfile]);

  // Monitor achievements for new unlocks and trigger the celebration once
  useEffect(() => {
    if (!userProfile) return;
    achievements.forEach((ach) => {
      if (ach.unlocked) {
        const key = `glossway_celebrated_${userProfile.uid || "guest"}_${ach.id}`;
        if (!localStorage.getItem(key)) {
          setActiveCelebration({
            id: ach.id,
            title: ach.title,
            description: ach.description,
            icon: ach.icon,
            color: ach.color,
          });
          localStorage.setItem(key, "true");
        }
      }
    });
  }, [achievements, userProfile]);

  // Trigger physical canvas-confetti bursts whenever an active celebration is set
  useEffect(() => {
    if (activeCelebration) {
      // Nice side-angle sequence
      const duration = 2.5 * 1000;
      const end = Date.now() + duration;

      const frame = () => {
        confetti({
          particleCount: 5,
          angle: 60,
          spread: 55,
          origin: { x: 0, y: 0.85 },
          colors: ["#2d7a64", "#FFD700", "#FFDF00", "#0f241d", "#E5A93B"]
        });
        confetti({
          particleCount: 5,
          angle: 120,
          spread: 55,
          origin: { x: 1, y: 0.85 },
          colors: ["#2d7a64", "#FFD700", "#FFDF00", "#0f241d", "#E5A93B"]
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };

      // Big main initial burst
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
        colors: ["#2d7a64", "#FFD700", "#FFDF00", "#0f241d", "#E5A93B"]
      });

      frame();
    }
  }, [activeCelebration]);

  const handleToggleQuickContext = () => {
    const newValue = !isQuickContextMode;
    setIsQuickContextMode(newValue);
    try {
      localStorage.setItem("glossway_mentor_quick_context_enabled", String(newValue));
    } catch (e) {
      console.error(e);
    }
    if (newValue && !mentorSuggestions) {
      fetchMentorSuggestions();
    }
  };

  const fetchMentorSuggestions = async () => {
    setIsMentorLoading(true);
    setMentorError(null);
    try {
      const response = await apiFetch("/api/mentor-suggestions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recentSearches: userProfile?.recentSearches || [],
          streak: userProfile?.streak || 0,
          wordsLearned: userProfile?.wordsLearned || 0,
          studyTimeToday: Math.round(todaySeconds / 60),
          activeLanguages: userProfile?.languages || {},
        }),
        retryAction: () => fetchMentorSuggestions(),
        actionName: "Linguistic Mentor Suggestions"
      });
      const data = await response.json();
      if (data && data.text) {
        setMentorSuggestions(data.text);
        try {
          localStorage.setItem("glossway_mentor_suggestions_cache", data.text);
        } catch (e) {
          console.error(e);
        }
      } else {
        setMentorError(data.error || "Failed to generate suggestions.");
      }
    } catch (err) {
      console.error(err);
      setMentorError("Network error: Could not reach mentor service.");
    } finally {
      setIsMentorLoading(false);
    }
  };

  useEffect(() => {
    if (isMentorOpen && isQuickContextMode && !mentorSuggestions && !isMentorLoading) {
      fetchMentorSuggestions();
    }
  }, [isMentorOpen, isQuickContextMode]);

  // Premium Markdown renderer for AI suggestions


  const showNotification = (message: string, type: "success" | "info" = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Keep targetMinutes in sync with userProfile
  useEffect(() => {
    if (userProfile?.dailyGoalMinutes) {
      setTargetMinutes(userProfile.dailyGoalMinutes);
    }
  }, [userProfile?.dailyGoalMinutes]);

  // Load and refresh today's active study time
  const loadTodaySeconds = () => {
    try {
      const todayStr = new Date().toISOString().split("T")[0];
      const lsKey = `glossway_study_seconds_${todayStr}`;
      const saved = parseInt(localStorage.getItem(lsKey) || "0", 10);
      setTodaySeconds(saved);
      return saved;
    } catch (e) {
      console.error(e);
      return 0;
    }
  };

  useEffect(() => {
    const initialSecs = loadTodaySeconds();
    // Poll localstorage periodically in case they studied in tutor
    const interval = setInterval(loadTodaySeconds, 5000);

    // Trigger subtle 'Daily Goal' reminder toast once per session/day if not yet completed
    const todayStr = new Date().toISOString().split("T")[0];
    const sessionKey = `glossway_goal_reminder_shown_${todayStr}`;
    const initialMins = Math.round(initialSecs / 60);
    const initialTarget = userProfile?.dailyGoalMinutes || 15;

    if (initialMins < initialTarget) {
      try {
        if (sessionStorage.getItem(sessionKey) !== "true") {
          sessionStorage.setItem(sessionKey, "true");
          const remaining = initialTarget - initialMins;
          if (showToast) {
            setTimeout(() => {
              showToast(`🎯 Daily Goal Reminder: You have ${remaining} minutes remaining to fulfill today's study commitment of ${initialTarget} minutes.`);
            }, 1200);
          }
        }
      } catch (e) {
        console.error(e);
      }
    }

    return () => clearInterval(interval);
  }, [userProfile?.dailyGoalMinutes, showToast]);

  // Trigger toast notification when hitting 'dailyGoalMinutes' target
  useEffect(() => {
    if (todaySeconds === 0) return;
    const todayStr = new Date().toISOString().split("T")[0];
    const todayMinutes = Math.round(todaySeconds / 60);
    if (todayMinutes >= targetMinutes) {
      const storageKey = `glossway_goal_toast_shown_${todayStr}`;
      try {
        if (localStorage.getItem(storageKey) !== "true") {
          localStorage.setItem(storageKey, "true");
          if (showToast) {
            showToast("✨ Beautifully done! Your daily commitment is fulfilled. Consistency is the architect of language mastery.");
          }
        }
      } catch (e) {
        console.error(e);
      }
    }
  }, [todaySeconds, targetMinutes, showToast]);

  // Seed past week with study minutes if user has no history
  useEffect(() => {
    try {
      let total = 0;
      for (let i = 0; i < 7; i++) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const dateStr = d.toISOString().split("T")[0];
        const val = localStorage.getItem(`glossway_study_seconds_${dateStr}`);
        if (val) total += parseInt(val, 10);
      }
      if (total === 0) {
        const seed = [12, 18, 8, 25, 15, 20];
        seed.forEach((m, idx) => {
          const d = new Date();
          d.setDate(d.getDate() - (6 - idx));
          localStorage.setItem(`glossway_study_seconds_${d.toISOString().split("T")[0]}`, String(m * 60));
        });
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  // Compute past 7 days study minutes dynamically
  const weeklyData = useMemo(() => {
    const data = [];
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split("T")[0];
      let secs = 0;
      try {
        secs = parseInt(localStorage.getItem(`glossway_study_seconds_${dateStr}`) || "0", 10);
      } catch (e) {
        console.error(e);
      }
      data.push({
        date: dateStr,
        shortLabel: `${days[d.getDay()]} ${d.getDate()}`,
        duration: Math.round(secs / 60),
      });
    }
    return data;
  }, [todaySeconds]);

  const handleUpdateGoal = async (minutes: number) => {
    if (minutes < 5) return;
    setTargetMinutes(minutes);
    if (!userProfile?.uid) {
      showNotification(`Goal updated to ${minutes} mins (offline)`);
      return;
    }

    setSavingGoal(true);
    try {
      const userRef = doc(db, "users", userProfile.uid);
      await updateDoc(userRef, {
        dailyGoalMinutes: minutes
      });
      showNotification("Daily study goal saved successfully!");
    } catch (err) {
      console.error("Failed to save daily goal:", err);
      showNotification("Failed to save goal to cloud", "info");
    } finally {
      setSavingGoal(false);
    }
  };

  const handleToggleNotifications = async () => {
    const nextState = !userProfile?.notificationsEnabled;
    
    // Optimistic local state update
    if (onUpdateUserProfile) {
      onUpdateUserProfile({ notificationsEnabled: nextState });
    }

    if (!userProfile?.uid) {
      showNotification(nextState ? "Daily study reminders enabled (offline)" : "Daily study reminders disabled (offline)");
      return;
    }

    setSavingNotifications(true);
    try {
      const userRef = doc(db, "users", userProfile.uid);
      await updateDoc(userRef, {
        notificationsEnabled: nextState
      });
      showNotification(
        nextState 
          ? "🔔 Daily push reminders activated! We'll send you study alerts."
          : "🔕 Study reminders disabled.",
        "success"
      );
    } catch (err) {
      console.error("Failed to update notification settings:", err);
      showNotification("Failed to save reminder preference", "info");
      // Revert optimistic update on failure
      if (onUpdateUserProfile) {
        onUpdateUserProfile({ notificationsEnabled: !nextState });
      }
    } finally {
      setSavingNotifications(false);
    }
  };

  const handleRequestNotifPermission = async () => {
    if (!("Notification" in window)) {
      showNotification("Browser push notifications are not supported in this browser.", "info");
      return;
    }
    try {
      const permission = await Notification.requestPermission();
      setNotifPermission(permission);
      if (permission === "granted") {
        showNotification("Desktop study reminders successfully authorized! 🎉", "success");
      } else if (permission === "denied") {
        showNotification("Notifications blocked. Please enable them in your browser settings.", "info");
      }
    } catch (err) {
      console.error("Error requesting notification permission:", err);
    }
  };

  const handleTriggerTestNotification = () => {
    if (!("Notification" in window)) {
      showNotification("Browser push notifications are not supported in this browser.", "info");
      return;
    }
    if (Notification.permission !== "granted") {
      showNotification("Please authorize desktop notifications first!", "info");
      return;
    }
    try {
      new Notification("Glossway Test Reminder 🎯", {
        body: "Your daily study slots notification system is active and ready to go!",
        icon: "/favicon.ico",
      });
      showNotification("Test push notification dispatched! Check your desktop.", "success");
    } catch (e) {
      console.error(e);
      showNotification("Failed to trigger test notification.", "info");
    }
  };

  const handleAddTimeSlot = async (timeToAdd?: string) => {
    const slot = timeToAdd || newSlotTime;
    if (!slot) return;

    // Retrieve current slots or default to [reminderTime]
    const currentSlots = userProfile?.studyTimeSlots || [userProfile?.reminderTime || "19:00"];
    
    if (currentSlots.includes(slot)) {
      showNotification("This study time slot is already planned!", "info");
      return;
    }

    const updatedSlots = [...currentSlots, slot].sort();

    // Optimistic local state update
    if (onUpdateUserProfile) {
      onUpdateUserProfile({ studyTimeSlots: updatedSlots });
    }

    if (!userProfile?.uid) {
      showNotification(`Time slot ${slot} added (offline)`);
      return;
    }

    try {
      const userRef = doc(db, "users", userProfile.uid);
      await updateDoc(userRef, {
        studyTimeSlots: updatedSlots
      });
      showNotification(`Study time slot ${slot} saved successfully!`);
    } catch (err) {
      console.error("Failed to save time slot:", err);
      showNotification("Failed to save time slot to cloud", "info");
      // Revert optimistic update
      if (onUpdateUserProfile) {
        onUpdateUserProfile({ studyTimeSlots: currentSlots });
      }
    }
  };

  const handleRemoveTimeSlot = async (slotToRemove: string) => {
    const currentSlots = userProfile?.studyTimeSlots || [userProfile?.reminderTime || "19:00"];
    const updatedSlots = currentSlots.filter(s => s !== slotToRemove);

    // Optimistic local update
    if (onUpdateUserProfile) {
      onUpdateUserProfile({ studyTimeSlots: updatedSlots });
    }

    if (!userProfile?.uid) {
      showNotification(`Time slot ${slotToRemove} removed (offline)`);
      return;
    }

    try {
      const userRef = doc(db, "users", userProfile.uid);
      await updateDoc(userRef, {
        studyTimeSlots: updatedSlots
      });
      showNotification(`Study time slot ${slotToRemove} removed.`);
    } catch (err) {
      console.error("Failed to remove time slot:", err);
      showNotification("Failed to remove time slot from cloud", "info");
      // Revert optimistic update
      if (onUpdateUserProfile) {
        onUpdateUserProfile({ studyTimeSlots: currentSlots });
      }
    }
  };

  const handleLogManualTime = () => {
    const mins = parseInt(manualMinutes, 10);
    if (isNaN(mins) || mins <= 0) return;

    try {
      const todayStr = new Date().toISOString().split("T")[0];
      const lsKey = `glossway_study_seconds_${todayStr}`;
      const currentTodaySecs = parseInt(localStorage.getItem(lsKey) || "0", 10);
      const addedSecs = mins * 60;
      localStorage.setItem(lsKey, String(currentTodaySecs + addedSecs));
      setTodaySeconds(currentTodaySecs + addedSecs);
      setManualMinutes("");
      showNotification(`Successfully logged ${mins} minutes of offline study!`);

      // If user profile is loaded, save also in total studyTime (optional but amazing!)
      if (userProfile?.uid) {
        const userRef = doc(db, "users", userProfile.uid);
        const totalSecs = (userProfile.studyTime || 0) + addedSecs;
        updateDoc(userRef, {
          studyTime: totalSecs
        }).catch(err => console.error(err));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleFrameSentencesAI = async () => {
    if (!framerWord || !activeProtocolLang) return;
    setFramerLoading(true);
    setFramerResult("");
    try {
      const response = await apiFetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: `Please frame exactly ${framerCount} illustrative example sentences in ${activeProtocolLang.name} using the ${framerWord.level} level word "${framerWord.word}" (translation: "${framerWord.translation}"). 
Each of the ${framerCount} examples MUST follow this exact format:
- Foreign sentence (bolded using **): [Sentence]
- English translation: [Translation]
- Pronunciation guide: [Pronunciation]

Ensure the vocabulary and grammar structure of the sentences match a ${framerWord.level} level language curriculum. Give very clear, educational, and complete sentences.`,
          modelType: framerModel,
          language: activeProtocolLang.name
        }),
        retryAction: () => handleFrameSentencesAI(),
        actionName: "Linguistic Example Framer"
      });
      const data = await response.json();
      if (data && data.text) {
        setFramerResult(data.text);
      } else {
        setFramerResult("Error: Received an invalid response from the AI framing engine.");
      }
    } catch (err) {
      console.error(err);
      setFramerResult("Connection failed: could not reach the AI framing service. Please ensure the backend is running.");
    } finally {
      setFramerLoading(false);
    }
  };

  const handleAddLanguage = async (langId: string, langName: string) => {
    if (!userProfile?.uid) {
      showNotification("Please sign in to add languages", "info");
      return;
    }
    setIsAddingLanguage(langId);
    try {
      const userRef = doc(db, "users", userProfile.uid);
      const currentLanguages = userProfile.languages || {};
      
      if (currentLanguages[langId]) {
        showNotification(`${langName} is already on your active path!`, "info");
        return;
      }

      const updatedLanguages = {
        ...currentLanguages,
        [langId]: {
          name: langName,
          levelName: "Beginner",
          progress: 0,
        }
      };

      await updateDoc(userRef, {
        languages: updatedLanguages
      });
      showNotification(`${langName} added to your Language Progress path!`);
    } catch (err) {
      console.error("Failed to add language:", err);
      showNotification("Failed to add language", "info");
    } finally {
      setIsAddingLanguage(null);
    }
  };

  // Month labels
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  // Render a calendar month
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    let day = new Date(year, month, 1).getDay();
    return day === 0 ? 6 : day - 1; // Align to Mon
  };

  const daysInMonth = getDaysInMonth(currentYearMonth.year, currentYearMonth.month);
  const firstDayOffset = getFirstDayOfMonth(currentYearMonth.year, currentYearMonth.month);

  const prevMonthDays = getDaysInMonth(currentYearMonth.year, currentYearMonth.month - 1);

  // Generate calendar days
  const calendarDays = [];

  // Previous month padding
  for (let i = firstDayOffset - 1; i >= 0; i--) {
    calendarDays.push({
      day: prevMonthDays - i,
      isCurrentMonth: false,
      dateStr: "",
    });
  }

  // Current month days
  for (let i = 1; i <= daysInMonth; i++) {
    const formattedMonth = String(currentYearMonth.month + 1).padStart(2, "0");
    const formattedDay = String(i).padStart(2, "0");
    const dateStr = `${currentYearMonth.year}-${formattedMonth}-${formattedDay}`;

    calendarDays.push({
      day: i,
      isCurrentMonth: true,
      dateStr,
    });
  }

  // Next month padding
  const totalDaysCount = calendarDays.length;
  const nextMonthPadding = totalDaysCount % 7 === 0 ? 0 : 7 - (totalDaysCount % 7);
  for (let i = 1; i <= nextMonthPadding; i++) {
    calendarDays.push({
      day: i,
      isCurrentMonth: false,
      dateStr: "",
    });
  }

  const handlePrevMonth = () => {
    setCurrentYearMonth((prev) => {
      if (prev.month === 0) {
        return { year: prev.year - 1, month: 11 };
      }
      return { ...prev, month: prev.month - 1 };
    });
  };

  const handleNextMonth = () => {
    setCurrentYearMonth((prev) => {
      if (prev.month === 11) {
        return { year: prev.year + 1, month: 0 };
      }
      return { ...prev, month: prev.month + 1 };
    });
  };

  const today = new Date();
  const formattedMonth = String(today.getMonth() + 1).padStart(2, "0");
  const formattedDay = String(today.getDate()).padStart(2, "0");
  const todayStr = `${today.getFullYear()}-${formattedMonth}-${formattedDay}`;
  const todayCompleted = completedDates.includes(todayStr);

  const userHasReminder = userProfile?.notificationsEnabled;
  const userReminderTime = userProfile?.reminderTime || "19:00";

  // Parse hours and minutes of custom reminder time
  const [remHour, remMin] = userReminderTime.split(":").map(Number);
  const currentHour = today.getHours();
  const currentMin = today.getMinutes();
  const isPastReminderTime = currentHour > remHour || (currentHour === remHour && currentMin >= remMin);

  const isAlertActive = userHasReminder
    ? (isPastReminderTime || simulatePost8PM)
    : (today.getHours() >= 20 || simulatePost8PM);

  const hasntMetGoal = Math.round(todaySeconds / 60) < targetMinutes;

  return (
    <div className="space-y-12 animate-fade-in pb-12 relative">
      {/* Toast Notification overlay */}
      {notification && (
        <div className="fixed top-24 right-6 z-50 bg-[#0f241d] text-[#f3f7f5] border border-[#2d7a64] px-5 py-3.5 shadow-2xl animate-fade-in flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-[#2d7a64] animate-pulse shrink-0"></div>
          <span className="font-mono text-xs uppercase tracking-wider">{notification.message}</span>
        </div>
      )}

      {/* Evening study goal check (subtle banner notification) or Scheduled reminder alert */}
      {isAlertActive && hasntMetGoal && (
        <div className="bg-[#f3f7f5] border border-amber-200 p-5 animate-fade-in flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-[#0f241d] shadow-sm">
          <div className="flex items-start gap-3.5">
            <div className="w-9 h-9 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center shrink-0 mt-0.5">
              <Clock className="w-4 h-4 text-amber-600 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-amber-700 uppercase tracking-wider font-extrabold bg-amber-100/50 px-2 py-0.5 rounded-xs">
                  {userHasReminder
                    ? `Scheduled Reminder Alert (${userReminderTime})`
                    : "Evening Study Check (8:00 PM)"
                  }
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping"></span>
              </div>
              <p className="text-xs text-[#0f241d80] font-sans font-semibold tracking-tight mt-1.5 leading-relaxed">
                You haven't completed your daily learning target of <strong className="text-black font-semibold">{targetMinutes} minutes</strong> yet. You've completed <strong className="text-black font-semibold">{Math.round(todaySeconds / 60)} minutes</strong> today. Take a quick study session now to keep your streak!
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate("learning")}
            className="w-full sm:w-auto px-5 py-2.5 bg-black hover:bg-[#25332e] text-white font-mono text-[10px] uppercase tracking-widest cursor-pointer transition-all font-semibold whitespace-nowrap border border-black"
          >
            Study with AI Tutor &rarr;
          </button>
        </div>
      )}

      {/* Subtle Daily Goal Reminder Banner for daytime */}
      {!isAlertActive && hasntMetGoal && (
        <div className="bg-[#f3f7f5] border border-[#0f241d10] p-5 animate-fade-in flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-[#0f241d] shadow-sm">
          <div className="flex items-start gap-3.5">
            <div className="w-9 h-9 rounded-full bg-[#2d7a64]/10 border border-[#2d7a64]/20 flex items-center justify-center shrink-0 mt-0.5">
              <Target className="w-4.5 h-4.5 text-[#2d7a64]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-[#2d7a64] uppercase tracking-[0.15em] font-extrabold bg-[#2d7a64]/5 px-2 py-0.5 border border-[#2d7a64]/15 rounded-xs">
                  Daily Goal Remaining
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#2d7a64]"></span>
                <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-wider">
                  {Math.round(todaySeconds / 60)}m of {targetMinutes}m complete
                </span>
              </div>
              <p className="text-xs text-[#0f241d80] font-sans font-semibold tracking-tight mt-1.5 leading-relaxed">
                Take a quick study session with your AI tutor to complete your remaining <strong className="text-black font-semibold">{Math.max(1, targetMinutes - Math.round(todaySeconds / 60))} minutes</strong> and secure today's learning milestone.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate("learning")}
            className="w-full sm:w-auto px-5 py-2.5 bg-black hover:bg-[#25332e] text-white font-mono text-[10px] uppercase tracking-widest cursor-pointer transition-all font-semibold whitespace-nowrap border border-black"
          >
            Practice with AI Tutor &rarr;
          </button>
        </div>
      )}

      {/* Daily Goal Progress (Minimal Editorial Style Visualizer) */}
      <DailyGoalProgress
        todaySeconds={todaySeconds}
        targetMinutes={targetMinutes}
        onUpdateGoal={handleUpdateGoal}
        onNavigate={onNavigate}
      />



      {/* Scholar Honors & Milestones Bento Section */}
      <section className="space-y-6">
        <div className="pb-4 border-b border-[#0f241d10]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-[#2d7a64]">
              <Trophy className="w-4 h-4" />
              <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-semibold">Academic Distinction</span>
            </div>
            <span className="text-[10px] font-mono uppercase text-[#0f241d50]">
              {achievements.filter(a => a.unlocked).length} of {achievements.length} Earned
            </span>
          </div>
          <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d] mt-1">
            Scholar Honors & Academic Milestones
          </h2>
          <p className="text-xs text-[#0f241d50] mt-0.5">
            Unlock exclusive distinction badges by mastering words, maintaining active streaks, and elevating your academic profile. Click any earned badge to trigger a celebratory golden particle shower.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map((ach) => {
            const AchIcon = ach.icon || Trophy;
            return (
              <motion.div
                key={ach.id}
                onClick={() => {
                  if (ach.unlocked) {
                    setActiveCelebration({
                      id: ach.id,
                      title: ach.title,
                      description: ach.description,
                      icon: ach.icon,
                      color: ach.color,
                    });
                    if (showToast) {
                      showToast(`✨ Replaying celebration: ${ach.title}!`);
                    }
                  } else {
                    if (showToast) {
                      showToast(`Keep studying to earn the "${ach.title}" distinction!`);
                    }
                  }
                }}
                whileHover={{ scale: 1.015 }}
                className={`border p-6 flex flex-col justify-between space-y-6 transition-all relative cursor-pointer select-none overflow-hidden ${
                  ach.unlocked
                    ? "bg-gradient-to-br from-white to-[#f3f7f5] border-[#2d7a64]/40 shadow-[0_4px_25px_rgba(197,168,128,0.12)] hover:border-[#2d7a64] hover:shadow-[0_8px_30px_rgba(197,168,128,0.2)]"
                    : "bg-white border-[#0f241d10] hover:border-black/30 animate-fade-in"
                }`}
              >
                {/* Visual Unlocked Ribbon Tag */}
                {ach.unlocked && (
                  <div className="absolute top-0 right-0 bg-[#2d7a64] text-white text-[8px] font-mono font-bold uppercase tracking-widest px-2.5 py-1">
                    Earned
                  </div>
                )}

                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 border flex items-center justify-center rounded-xs transition-colors ${
                      ach.unlocked
                        ? "border-[#2d7a64]/30 bg-[#2d7a64]/5 text-[#2d7a64]"
                        : "border-[#0f241d10] bg-[#f3f7f5] text-[#0f241d40]"
                    }`}>
                      <AchIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className={`font-sans font-semibold tracking-tight font-bold text-base transition-colors ${
                        ach.unlocked ? "text-[#0f241d]" : "text-neutral-500"
                      }`}>
                        {ach.title}
                      </h3>
                      <span className="text-[9px] font-mono uppercase text-[#0f241d40] tracking-wider block">
                        Milestone badge
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-[#0f241d60] leading-relaxed font-sans font-semibold tracking-tight">
                    "{ach.description}"
                  </p>
                </div>

                {/* Progress bar block */}
                <div className="space-y-2 pt-2 border-t border-[#0f241d05]">
                  <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="text-[#0f241d50]">Progress:</span>
                    <span className={`font-bold ${ach.unlocked ? "text-[#2d7a64]" : "text-neutral-600"}`}>
                      {ach.unlocked ? `${ach.target} / ${ach.target}` : `${ach.current} / ${ach.target}`} {ach.suffix}
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-[#0f241d05] border border-[#0f241d08] overflow-hidden">
                    <div
                      className={`h-full transition-all duration-1000 ${
                        ach.unlocked ? "bg-[#2d7a64]" : "bg-[#0f241d40]"
                      }`}
                      style={{
                        width: `${Math.min(100, (ach.unlocked ? ach.target : ach.current) / ach.target * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Language Study Blueprints Reference Center */}
      <section className="space-y-6">
        <div className="pb-4 border-b border-[#0f241d10]">
          <div className="flex items-center gap-2 text-[#2d7a64]">
            <Compass className="w-4 h-4" />
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-semibold">Curriculum Guides</span>
          </div>
          <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d] mt-1">
            Language Study Blueprints
          </h2>
          <p className="text-xs text-[#0f241d50] mt-0.5">
            Explore FSI Difficulty categories, optimal study timelines, professional app dictionaries, and beginner learning paths.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {LANGUAGES_BLUEPRINTS.map((blueprint) => {
            const isAdded = !!userProfile?.languages?.[blueprint.id];
            const flag = FLAG_MAP[blueprint.id] || "🏳️";

            return (
              <div 
                key={blueprint.id} 
                className="bg-white border border-[#0f241d15] p-6 flex flex-col justify-between space-y-6 hover:shadow-md transition-shadow relative animate-fade-in"
              >
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-[#e8f0eb] border border-[#0f241d10] flex items-center justify-center text-lg">
                        {flag}
                      </div>
                      <div>
                        <h3 className="font-sans font-semibold tracking-tight font-bold text-lg text-[#0f241d]">
                          {blueprint.name}
                        </h3>
                        <span className="text-[9px] font-mono uppercase text-[#0f241d50] tracking-wider block">
                          {blueprint.difficulty}
                        </span>
                      </div>
                    </div>
                    {isAdded && (
                      <span className="bg-[#0f241d] text-white px-2.5 py-1 text-[9px] font-mono uppercase tracking-widest flex items-center gap-1">
                        <Check className="w-2.5 h-2.5 animate-pulse" /> Active
                      </span>
                    )}
                  </div>

                  <div className="space-y-2 pt-2 border-t border-[#0f241d08]">
                    <div className="flex justify-between items-center text-[10px] font-mono">
                      <span className="text-[#0f241d50]">Timeline commitment:</span>
                      <span className="text-[#0f241d] font-semibold">{blueprint.timeCommitment}</span>
                    </div>
                    <div className="flex justify-between items-center text-[10px] font-mono">
                      <span className="text-[#0f241d50]">Recommended Dictionary:</span>
                      <span className="text-[#0f241d] font-semibold underline decoration-[#2d7a64]/40">{blueprint.bestDictionary}</span>
                    </div>
                  </div>

                  <p className="text-xs text-[#0f241d70] line-clamp-3 leading-relaxed font-sans font-semibold tracking-tight pt-1">
                    "{blueprint.learningPath}"
                  </p>
                </div>

                <div className="flex gap-2 pt-4 border-t border-[#0f241d08]">
                  <button
                    onClick={() => setSelectedBlueprint(blueprint)}
                    className="flex-1 bg-[#f3f7f5] hover:bg-[#e8f0eb] text-[#0f241d] border border-[#0f241d15] hover:border-[#0f241d] py-2.5 text-[10px] font-mono uppercase tracking-wider cursor-pointer transition-colors flex items-center justify-center gap-1"
                  >
                    Guide <ExternalLink className="w-2.5 h-2.5 text-[#2d7a64]" />
                  </button>
                  
                  <button
                    onClick={() => {
                      if (onSelectLanguage) {
                        onSelectLanguage(blueprint.id);
                      }
                      onNavigate("learning");
                    }}
                    className="flex-1 bg-[#0f241d] hover:bg-[#25332e] text-white py-2.5 text-[10px] font-mono uppercase tracking-wider cursor-pointer transition-colors font-semibold"
                  >
                    Start Now
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Daily Study Goal Tracker Widget */}
      <section className="bg-white border border-[#0f241d15] p-6 md:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#0f241d10]">
          <div>
            <div className="flex items-center gap-2 text-[#2d7a64]">
              <Target className="w-4 h-4" />
              <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-semibold">Study Goal Engine</span>
            </div>
            <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d] mt-1">
              Daily Study Goal Tracker
            </h2>
            <p className="text-xs text-[#0f241d50] mt-0.5">
              Set your target learning minutes and track study sessions in real-time.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-end sm:items-center gap-4">
            <button
              onClick={() => {
                setSimulatePost8PM(prev => !prev);
                showNotification(
                  !simulatePost8PM 
                    ? (userHasReminder 
                        ? `Simulated study alert time reached (${userReminderTime})` 
                        : "Simulated time set: Evening Hours (Post 8:00 PM)") 
                    : "Reset simulation to active system clock.", 
                  "info"
                );
              }}
              className={`px-3 py-2 font-mono text-[10px] uppercase tracking-wider border transition-all cursor-pointer ${
                simulatePost8PM
                  ? "bg-amber-600 text-white border-amber-600 font-bold animate-pulse"
                  : "bg-white text-neutral-500 border-[#0f241d15] hover:border-black"
              }`}
            >
              🕒 {simulatePost8PM 
                ? (userHasReminder ? "Simulating Study Alert (Click to Reset)" : "Simulating After 8 PM (Click to Reset)") 
                : (userHasReminder ? `Simulate Alert (${userReminderTime})` : "Simulate Post-8 PM Check")
              }
            </button>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-[#0f241d60] uppercase">Active Goal:</span>
              <span className="font-mono text-xs font-bold text-[#0f241d] bg-[#e8f0eb] border border-[#0f241d10] px-3 py-1.5 whitespace-nowrap">
                {targetMinutes} Minutes / Day
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Today's Progress Meter */}
          <div className="lg:col-span-5 bg-[#f3f7f5] border border-[#0f241d08] p-5 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between items-end pb-2 border-b border-[#0f241d05]">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#0f241d60]">
                  STUDIED TODAY
                </span>
                <span className="font-mono text-xs font-bold text-[#0f241d] bg-[#f3f7f5] border border-[#0f241d08] px-2 py-0.5">
                  {Math.round(todaySeconds / 60)}m / {targetMinutes}m
                </span>
              </div>

              {/* Dynamic SVG Visual Progress Ring Component */}
              <div className="flex flex-col items-center justify-center py-4 relative group">
                <div className="relative w-40 h-40 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90 select-none" viewBox="0 0 160 160">
                    {/* Ticking scale lines / watch sub-dial markers */}
                    <line x1="80" y1="12" x2="80" y2="18" stroke="#0f241d25" strokeWidth="1.5" />
                    <line x1="148" y1="80" x2="142" y2="80" stroke="#0f241d25" strokeWidth="1.5" />
                    <line x1="80" y1="148" x2="80" y2="142" stroke="#0f241d25" strokeWidth="1.5" />
                    <line x1="12" y1="80" x2="18" y2="80" stroke="#0f241d25" strokeWidth="1.5" />
                    
                    {/* Tiny dial ticks for visual micro-detail */}
                    <circle cx="122.4" cy="37.6" r="1.5" className="fill-[#0f241d15]" />
                    <circle cx="122.4" cy="122.4" r="1.5" className="fill-[#0f241d15]" />
                    <circle cx="37.6" cy="122.4" r="1.5" className="fill-[#0f241d15]" />
                    <circle cx="37.6" cy="37.6" r="1.5" className="fill-[#0f241d15]" />

                    {/* Outer ambient decorative glow ring */}
                    <circle
                      cx="80"
                      cy="80"
                      r="60"
                      className="stroke-[#0f241d03]"
                      strokeWidth="12"
                      fill="transparent"
                    />

                    {/* Back track ring */}
                    <circle
                      cx="80"
                      cy="80"
                      r="60"
                      className="stroke-[#0f241d08]"
                      strokeWidth="6"
                      fill="transparent"
                    />

                    {/* Progress ring with smooth stroke animation and adaptive coloring */}
                    <motion.circle
                      cx="80"
                      cy="80"
                      r="60"
                      className={`${
                        Math.round(todaySeconds / 60) >= targetMinutes
                          ? "stroke-emerald-600"
                          : "stroke-[#2d7a64]"
                      } transition-colors duration-500`}
                      strokeWidth="6"
                      fill="transparent"
                      strokeDasharray={2 * Math.PI * 60}
                      initial={{ strokeDashoffset: 2 * Math.PI * 60 }}
                      animate={{ 
                        strokeDashoffset: 2 * Math.PI * 60 - (Math.min(100, Math.round(((todaySeconds / 60) / targetMinutes) * 100)) / 100) * (2 * Math.PI * 60) 
                      }}
                      transition={{ duration: 1.2, ease: "easeOut" }}
                      strokeLinecap="round"
                    />

                    {/* Small pulsing locator marker at the leading edge of progress */}
                    {Math.round(todaySeconds / 60) > 0 && Math.round(todaySeconds / 60) < targetMinutes && (
                      <circle
                        cx={80 + 60 * Math.cos(((Math.min(100, Math.round(((todaySeconds / 60) / targetMinutes) * 100)) / 100) * 360 - 90) * (Math.PI / 180))}
                        cy={80 + 60 * Math.sin(((Math.min(100, Math.round(((todaySeconds / 60) / targetMinutes) * 100)) / 100) * 360 - 90) * (Math.PI / 180))}
                        r="4.5"
                        className="fill-[#2d7a64] stroke-white stroke-2 shadow-xs animate-pulse"
                      />
                    )}
                  </svg>
                  
                  {/* Central status / text (Default View) */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-2 select-none pointer-events-none transition-all duration-300 group-hover:scale-90 group-hover:opacity-0">
                    <div className="flex items-center justify-center gap-1.5 mb-0.5">
                      {Math.round(todaySeconds / 60) >= targetMinutes ? (
                        <Award className="w-4 h-4 text-emerald-600 animate-pulse" />
                      ) : (
                        <Clock className="w-3.5 h-3.5 text-[#2d7a64]" />
                      )}
                    </div>
                    <span className={`text-2xl font-sans font-semibold tracking-tight font-bold tracking-tight ${
                      Math.round(todaySeconds / 60) >= targetMinutes ? "text-emerald-700" : "text-[#0f241d]"
                    }`}>
                      {Math.min(100, Math.round(((todaySeconds / 60) / targetMinutes) * 100))}%
                    </span>
                    <span className="text-[8px] font-mono uppercase tracking-[0.15em] text-[#0f241d40] mt-0.5 font-semibold">
                      {Math.round(todaySeconds / 60)}m of {targetMinutes}m
                    </span>
                  </div>

                  {/* Central status / text (Hover Detail View) */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-2 select-none pointer-events-none transition-all duration-300 opacity-0 group-hover:opacity-100 group-hover:scale-100">
                    <span className="text-[8px] font-mono uppercase tracking-[0.12em] text-[#2d7a64] font-bold">
                      {Math.round(todaySeconds / 60) >= targetMinutes ? "Vow Fulfilled" : "Time Pending"}
                    </span>
                    <span className="text-xs font-sans font-semibold tracking-tight text-[#0f241d] font-semibold mt-1">
                      {Math.round(todaySeconds / 60) >= targetMinutes 
                        ? "Excellent consistency!" 
                        : `${Math.max(1, targetMinutes - Math.round(todaySeconds / 60))} mins remaining`
                      }
                    </span>
                  </div>
                </div>
              </div>
              
              {/* Premium Progress Meter (Linear Indicator) */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center text-[8px] font-mono text-[#0f241d40] uppercase tracking-wider">
                  <span>Linear track</span>
                  <span>{Math.min(100, Math.round(((todaySeconds / 60) / targetMinutes) * 100))}%</span>
                </div>
                <div className="h-3 w-full bg-[#0f241d08] border border-[#0f241d10] p-0.5 overflow-hidden relative">
                  <div 
                    className={`h-full transition-all duration-500 ease-out ${
                      Math.round(todaySeconds / 60) >= targetMinutes ? "bg-emerald-600" : "bg-[#0f241d]"
                    }`}
                    style={{ width: `${Math.min(100, Math.round(((todaySeconds / 60) / targetMinutes) * 100))}%` }}
                  />
                  {Math.round(todaySeconds / 60) >= targetMinutes && (
                    <div className="absolute inset-0 flex items-center justify-center text-[8px] font-mono uppercase text-white font-semibold bg-emerald-600 tracking-widest">
                      🎉 Daily Goal Achieved!
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-4 border-t border-[#0f241d08]">
              <div className="w-8 h-8 bg-white border border-[#0f241d10] flex items-center justify-center shrink-0">
                <Clock className="w-4 h-4 text-[#2d7a64]" />
              </div>
              <div>
                <span className="text-[9px] font-mono text-[#0f241d40] uppercase tracking-wider block">Progress Feedback</span>
                <span className="text-xs font-sans font-semibold tracking-tight text-[#0f241d]">
                  {Math.round(todaySeconds / 60) >= targetMinutes 
                    ? "Incredible! Your study goal for today has been reached."
                    : `You need ${Math.max(1, targetMinutes - Math.round(todaySeconds / 60))} more minutes to achieve today's goal.`
                  }
                </span>
              </div>
            </div>
          </div>

          {/* Configuration Controls */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-3">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#0f241d60] block">
                Select Your Goal Target
              </span>
              <div className="flex flex-wrap gap-2">
                {[10, 15, 20, 30, 45, 60, 90].map((mins) => (
                  <button
                    key={mins}
                    onClick={() => handleUpdateGoal(mins)}
                    disabled={savingGoal}
                    className={`px-3 py-2 text-xs font-mono uppercase transition-colors tracking-wider cursor-pointer border ${
                      targetMinutes === mins
                        ? "bg-[#0f241d] text-[#f3f7f5] border-[#0f241d]"
                        : "bg-white text-[#0f241d] border-[#0f241d15] hover:border-[#0f241d]"
                    }`}
                  >
                    {mins}m
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => handleUpdateGoal(Math.max(5, targetMinutes - 5))}
                  disabled={savingGoal}
                  className="p-2 bg-[#f3f7f5] hover:bg-[#e8f0eb] border border-[#0f241d15] cursor-pointer transition-colors"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="font-mono text-[10px] uppercase tracking-wider text-[#0f241d60] px-2">Fine-tune goal</span>
                <button
                  onClick={() => handleUpdateGoal(targetMinutes + 5)}
                  disabled={savingGoal}
                  className="p-2 bg-[#f3f7f5] hover:bg-[#e8f0eb] border border-[#0f241d15] cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Offline manual study logging */}
            <div className="p-4 bg-[#f3f7f5] border border-[#0f241d08] space-y-3">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#0f241d60] block">
                Log Offline Study (Self-Study, Books, Dictionary)
              </span>
              <div className="flex gap-2">
                <input
                  type="number"
                  min="1"
                  max="480"
                  value={manualMinutes}
                  onChange={(e) => setManualMinutes(e.target.value)}
                  placeholder="Minutes studied"
                  className="bg-white border border-[#0f241d15] px-3 py-2 text-xs font-mono w-44"
                />
                <button
                  onClick={handleLogManualTime}
                  className="bg-[#0f241d] hover:bg-[#25332e] text-white text-[10px] font-mono uppercase tracking-widest px-4 py-2 cursor-pointer transition-colors border border-[#0f241d]"
                >
                  Log Minutes
                </button>
              </div>
            </div>

            {/* Daily Study Session Notification Reminders */}
            <div className="space-y-4">
              <div className="p-4 bg-[#f3f7f5] border border-[#0f241d08] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-[#2d7a64]">
                    {userProfile?.notificationsEnabled ? (
                      <Bell className="w-3.5 h-3.5 animate-bounce" />
                    ) : (
                      <BellOff className="w-3.5 h-3.5 text-[#0f241d40]" />
                    )}
                    <span className="text-[10px] font-mono uppercase tracking-[0.15em] font-semibold">
                      Study Session Reminders
                    </span>
                  </div>
                  <h4 className="font-sans font-semibold tracking-tight font-medium text-sm text-[#0f241d]">
                    Daily Push Notifications
                  </h4>
                  <p className="text-[11px] text-[#0f241d50] leading-relaxed max-w-md">
                    Enable system alerts to remind you of your daily study sessions so you can protect your learning streak.
                  </p>
                </div>
                <button
                  onClick={handleToggleNotifications}
                  disabled={savingNotifications}
                  className={`px-4 py-2.5 font-mono text-[9px] uppercase tracking-widest cursor-pointer transition-all border shrink-0 ${
                    userProfile?.notificationsEnabled
                      ? "bg-[#0f241d] text-white border-[#0f241d] hover:bg-neutral-800"
                      : "bg-white text-neutral-500 border-[#0f241d15] hover:border-black"
                  }`}
                >
                  {savingNotifications ? (
                    <span className="animate-pulse">Updating...</span>
                  ) : userProfile?.notificationsEnabled ? (
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Enabled
                    </span>
                  ) : (
                    "Disabled"
                  )}
                </button>
              </div>

              {userProfile?.notificationsEnabled && (
                <div className="p-6 bg-[#f3f7f5] border border-[#0f241d08] space-y-6 animate-fade-in">
                  
                  {/* Browser Push Auth & Status */}
                  <div className="pb-4 border-b border-[#0f241d08] flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h5 className="font-mono text-[10px] uppercase tracking-wider text-[#2d7a64] font-bold">
                        Browser Push Connection
                      </h5>
                      <p className="text-[11px] text-[#0f241d60] mt-1">
                        Configure browser alerts to show notifications directly in your system tray even when working offline.
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      {notifPermission === "granted" ? (
                        <div className="flex items-center gap-2">
                          <span className="flex items-center gap-1 text-[10px] font-mono bg-emerald-50 text-emerald-700 px-2.5 py-1.5 border border-emerald-200">
                            <ShieldCheck className="w-3.5 h-3.5" /> Authorized
                          </span>
                          <button
                            onClick={handleTriggerTestNotification}
                            className="bg-white hover:bg-neutral-50 text-[#0f241d] text-[9px] font-mono uppercase tracking-wider px-3 py-1.5 border border-[#0f241d15] transition-colors"
                          >
                            Send Test Notification
                          </button>
                        </div>
                      ) : notifPermission === "denied" ? (
                        <span className="flex items-center gap-1 text-[10px] font-mono bg-rose-50 text-rose-700 px-2.5 py-1.5 border border-rose-200">
                          <AlertCircle className="w-3.5 h-3.5" /> Blocked by Browser
                        </span>
                      ) : (
                        <button
                          onClick={handleRequestNotifPermission}
                          className="bg-[#2d7a64] hover:bg-[#b59870] text-white text-[9px] font-mono uppercase tracking-wider px-4 py-2 font-semibold transition-colors"
                        >
                          🔑 Authorize Browser Alerts
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Informational warning for inside iframe context */}
                  {typeof window !== "undefined" && window.self !== window.top && (
                    <div className="p-3 bg-[#f3f7f5] border border-amber-200 text-[#0f241d70] text-[10px] font-mono leading-relaxed flex items-start gap-2">
                      <Info className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                      <div>
                        Note: Because this application is running inside an AI Studio preview iframe, browser desktop alerts may require you to click <strong className="text-black font-semibold">"Open in New Tab"</strong> in the top right corner of the screen to work correctly.
                      </div>
                    </div>
                  )}

                  {/* Daily Study Time Slots Planner */}
                  <div className="space-y-4">
                    <div>
                      <h5 className="font-sans font-semibold tracking-tight font-medium text-sm text-[#0f241d]">
                        Daily Study Time Slots
                      </h5>
                      <p className="text-[11px] text-[#0f241d50]">
                        Plan multiple study windows during the day. We'll trigger a notification exactly when these times arrive.
                      </p>
                    </div>

                    {/* Active Slots list */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {(userProfile.studyTimeSlots || [userProfile.reminderTime || "19:00"]).map((slot, index) => {
                        // 12h time format conversion
                        const [hStr, mStr] = slot.split(":");
                        const h = parseInt(hStr, 10);
                        const m = parseInt(mStr, 10);
                        const ampm = h >= 12 ? "PM" : "AM";
                        const h12 = h % 12 || 12;
                        const formatted12h = `${h12}:${String(m).padStart(2, "0")} ${ampm}`;

                        return (
                          <div 
                            key={index} 
                            className="bg-white border border-[#0f241d08] hover:border-[#0f241d20] p-3 flex items-center justify-between transition-all"
                          >
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4 text-[#2d7a64]" />
                              <div>
                                <span className="font-mono text-xs font-semibold text-[#0f241d]">
                                  {formatted12h}
                                </span>
                                <span className="text-[9px] font-mono text-neutral-400 block uppercase">
                                  Slot #{index + 1} ({slot})
                                </span>
                              </div>
                            </div>
                            <button
                              onClick={() => handleRemoveTimeSlot(slot)}
                              className="text-neutral-400 hover:text-rose-600 p-1.5 transition-colors cursor-pointer border-0 bg-transparent"
                              title="Delete study slot"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        );
                      })}
                    </div>

                    {/* Quick Presets section */}
                    <div className="space-y-2 pt-2">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-[#0f241d50] block">
                        Quick Preset Suggestions
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { label: "🌅 Morning Session", time: "08:30" },
                          { label: "🥗 Lunch Break", time: "12:30" },
                          { label: "🍵 Evening Practice", time: "17:30" },
                          { label: "🌃 Night Review", time: "21:30" },
                        ].map((preset) => (
                          <button
                            key={preset.time}
                            onClick={() => handleAddTimeSlot(preset.time)}
                            className="text-[9px] font-mono text-[#0f241d80] bg-white hover:bg-neutral-50 hover:text-black border border-[#0f241d10] px-2.5 py-1 rounded-sm transition-all cursor-pointer"
                          >
                            {preset.label} ({preset.time})
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Add Custom Time Slot section */}
                    <div className="pt-3 border-t border-[#0f241d08] flex flex-col sm:flex-row items-start sm:items-center gap-3">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono text-[#0f241d60]">
                          Add Custom Slot:
                        </span>
                        <input
                          type="time"
                          value={newSlotTime}
                          onChange={(e) => setNewSlotTime(e.target.value)}
                          className="bg-white border border-[#0f241d15] px-3 py-1.5 text-xs font-mono rounded-xs focus:border-[#2d7a64] focus:outline-none"
                        />
                      </div>
                      <button
                        onClick={() => handleAddTimeSlot()}
                        className="bg-[#0f241d] hover:bg-[#25332e] text-white text-[9px] font-mono uppercase tracking-widest px-4 py-2 cursor-pointer transition-colors border border-[#0f241d] flex items-center gap-1 font-semibold"
                      >
                        <Plus className="w-3.5 h-3.5" /> Add Slot
                      </button>
                    </div>

                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Divider and Weekly Study Activity Line Chart */}
        <div className="pt-8 border-t border-[#0f241d10] space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 text-[#2d7a64]">
                <TrendingUp className="w-4 h-4" />
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-semibold">Weekly Study Duration Analytics</span>
              </div>
              <h3 className="font-sans font-semibold tracking-tight font-medium text-xl text-[#0f241d] mt-0.5">
                Weekly Study Activity
              </h3>
              <p className="text-xs text-[#0f241d50] mt-0.5 font-sans font-semibold tracking-tight">
                Your daily study duration (in minutes) over the past week.
              </p>
            </div>
            
            <div className="flex flex-wrap items-center gap-4 text-[10px] font-mono text-[#0f241d50]">
              <div className="flex items-center gap-1.5 bg-[#f3f7f5] border border-[#0f241d08] px-2.5 py-1">
                <span className="w-2 h-2 rounded-full bg-[#0f241d]"></span>
                <span className="text-[#0f241d70]">STUDIED MINUTES</span>
              </div>
              <div className="flex items-center gap-1.5 bg-[#f3f7f5] border border-[#0f241d08] px-2.5 py-1">
                <span className="w-2.5 h-[1.5px] bg-[#2d7a64] border-t border-dashed border-[#2d7a64]"></span>
                <span className="text-[#0f241d70]">DAILY GOAL ({targetMinutes}m)</span>
              </div>
            </div>
          </div>

          {/* Recharts Line Chart Container */}
          <div className="w-full h-[260px] bg-[#f3f7f5] border border-[#0f241d08] p-4 relative">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weeklyData} margin={{ top: 15, right: 15, left: -20, bottom: 5 }}>
                <CartesianGrid stroke="#0f241d06" strokeDasharray="3 3" vertical={false} />
                <XAxis 
                  dataKey="shortLabel" 
                  stroke="#0f241d40"
                  fontSize={10}
                  fontFamily="JetBrains Mono, ui-monospace, SFMono-Regular, monospace"
                  tickLine={false}
                  axisLine={{ stroke: "#0f241d10" }}
                />
                <YAxis 
                  stroke="#0f241d40"
                  fontSize={10}
                  fontFamily="JetBrains Mono, ui-monospace, SFMono-Regular, monospace"
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) => `${val}m`}
                />
                <Tooltip 
                  content={({ active, payload }: any) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-[#0f241d] text-[#f3f7f5] border border-[#2d7a64] p-3 shadow-xl font-mono text-[10px] tracking-wide">
                          <p className="font-semibold uppercase text-[#2d7a64] mb-1">
                            {payload[0].payload.shortLabel}
                          </p>
                          <p className="flex justify-between gap-4">
                            <span>STUDIED:</span>
                            <span className="font-bold text-white">{payload[0].value} MINS</span>
                          </p>
                          <p className="flex justify-between gap-4 text-[#f3f7f5]/50">
                            <span>GOAL:</span>
                            <span>{targetMinutes} MINS</span>
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }} 
                  cursor={{ stroke: "#0f241d10", strokeWidth: 1 }} 
                />
                <ReferenceLine 
                  y={targetMinutes} 
                  stroke="#2d7a64" 
                  strokeWidth={1.5}
                  strokeDasharray="4 4" 
                />
                <Line 
                  type="monotone" 
                  dataKey="duration" 
                  stroke="#0f241d" 
                  strokeWidth={2}
                  dot={{ r: 4, strokeWidth: 1.5, fill: "#f3f7f5", stroke: "#0f241d" }}
                  activeDot={{ r: 6, fill: "#2d7a64", stroke: "#0f241d", strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Daily Goal Tracker (Calendar) */}
      <section className="space-y-4">
        <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4">
          <div>
            <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d]">
              Daily Habit Tracker
            </h2>
            <p className="text-[#0f241d60] text-xs font-mono uppercase tracking-wider mt-1">
              {completedDates.length}/30 Days Completed • Click any day to toggle checkmark!
            </p>
          </div>
          <div className="flex gap-1.5">
            <button
              onClick={handlePrevMonth}
              className="p-2.5 bg-white border border-[#0f241d15] hover:border-[#0f241d] text-[#0f241d60] hover:text-[#0f241d] transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-4 py-2 self-center font-mono text-xs uppercase tracking-wider text-[#0f241d] border border-[#0f241d15] bg-[#e8f0eb]">
              {monthNames[currentYearMonth.month]} {currentYearMonth.year}
            </span>
            <button
              onClick={handleNextMonth}
              className="p-2.5 bg-white border border-[#0f241d15] hover:border-[#0f241d] text-[#0f241d60] hover:text-[#0f241d] transition-colors cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Dynamic Present Alert Banner */}
        {!todayCompleted ? (
          <div className="p-5 border border-[#2d7a64] bg-[#2d7a64]/5 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <span className="text-2xl mt-0.5">🎁</span>
              <div>
                <h4 className="font-sans font-semibold tracking-tight font-semibold text-sm text-[#0f241d]">
                  Today's Scholar Present is Unclaimed!
                </h4>
                <p className="text-xs text-[#0f241d60] mt-0.5">
                  Complete today's challenge quiz now to unbox your bonus rewards, earn +100 XP, and stamp today as completed with a present.
                </p>
              </div>
            </div>
            <button
              onClick={() => onNavigate("quiz")}
              className="px-5 py-2.5 bg-black hover:bg-neutral-800 text-[#f3f7f5] font-mono text-[10px] uppercase tracking-widest transition-colors cursor-pointer whitespace-nowrap"
            >
              Take Daily Quiz 🎁
            </button>
          </div>
        ) : (
          <div className="p-5 border border-emerald-600/30 bg-emerald-500/5 flex items-center gap-3">
            <span className="text-2xl">🎉</span>
            <div>
              <h4 className="font-sans font-semibold tracking-tight font-semibold text-sm text-emerald-800">
                Today's Present Claimed!
              </h4>
              <p className="text-xs text-emerald-600/80 mt-0.5">
                Outstanding! You completed today's challenge and unboxed your daily premium gift box. Keep this streak alive tomorrow!
              </p>
            </div>
          </div>
        )}

        <div className="bg-white p-6 border border-[#0f241d15]">
          <div className="grid grid-cols-7 gap-2 mb-2 pb-2 border-b border-[#0f241d10]">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
              <div
                key={day}
                className="text-center text-[10px] font-mono font-semibold text-[#0f241d50] uppercase tracking-widest"
              >
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {calendarDays.map((item, index) => {
              const isCompleted = item.isCurrentMonth && completedDates.includes(item.dateStr);

              return (
                <div
                  key={index}
                  onClick={() => {
                    if (item.isCurrentMonth && item.dateStr) {
                      onToggleDate(item.dateStr);
                    }
                  }}
                  className={`aspect-square relative flex flex-col items-center justify-center text-xs font-mono border transition-all cursor-pointer ${
                    item.isCurrentMonth
                      ? isCompleted
                        ? "bg-[#2d7a64] border-[#2d7a64] text-[#0f241d] font-bold scale-105 shadow-sm"
                        : "bg-white border-[#0f241d10] hover:border-[#0f241d] text-[#0f241d]"
                      : "text-[#0f241d20] border-transparent pointer-events-none"
                  }`}
                >
                  <span className={isCompleted ? "text-[9px] font-bold text-white absolute top-1 left-1.5" : ""}>
                    {item.day}
                  </span>
                  {isCompleted && (
                    <span className="text-lg mt-2 leading-none animate-bounce">🎁</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Learning Protocol Modal Overlay */}
      {activeProtocolLang && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white border border-[#0f241d15] max-w-4xl w-full p-6 md:p-8 space-y-6 max-h-[92vh] overflow-y-auto shadow-2xl relative rounded-sm">
            <button
              onClick={() => setActiveProtocolLang(null)}
              className="absolute top-6 right-6 font-mono text-xs uppercase tracking-widest hover:text-red-600 transition-colors cursor-pointer text-[#0f241d60] bg-neutral-100 hover:bg-neutral-200 px-2.5 py-1"
            >
              [ Close Protocol ]
            </button>

            <div className="flex items-center gap-4 border-b border-[#0f241d10] pb-5">
              <div className="w-14 h-14 bg-[#e8f0eb] border border-[#0f241d10] flex items-center justify-center text-3xl">
                {FLAG_MAP[activeProtocolLang.id] || "🏳️"}
              </div>
              <div>
                <span className="text-[10px] font-mono uppercase text-[#2d7a64] tracking-[0.2em] font-semibold">
                  Interactive Language protocol
                </span>
                <h3 className="font-sans font-semibold tracking-tight font-medium text-3xl text-[#0f241d] leading-none mt-1">
                  {activeProtocolLang.name} Learning Path
                </h3>
              </div>
            </div>

            {/* Level Selector Tabs */}
            <div className="flex border-b border-[#0f241d10] -mx-8 px-8">
              {(["beginner", "mid", "pro"] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => setProtocolTab(level)}
                  className={`py-3 px-6 font-mono text-xs uppercase tracking-widest border-b-2 transition-all cursor-pointer ${
                    protocolTab === level
                      ? "border-[#0f241d] text-[#0f241d] font-bold"
                      : "border-transparent text-[#0f241d40] hover:text-[#0f241d]"
                  }`}
                >
                  {level === "beginner" ? "膜 Beginner Level" : level === "mid" ? "⚡ Mid Level" : "💎 Pro Level"}
                </button>
              ))}
            </div>

            {/* Explicit Level Curriculum Requirements */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-[#f3f7f5] border border-[#0f241d08] p-4 space-y-2">
                <span className="text-[9px] font-mono text-[#2d7a64] uppercase tracking-wider block font-bold">Vocabulary Requirements</span>
                <p className="text-xs text-[#0f241d80] leading-relaxed">
                  {protocolTab === "beginner" && "Must master 500+ basic nouns, adjectives, numbers, colors, and key family descriptors."}
                  {protocolTab === "mid" && "Must master 2,500+ abstract words, professional terms, emotional verbs, and descriptive adjectives."}
                  {protocolTab === "pro" && "Achieve unlimited coverage containing millions of words, rare literary prose, and specialized terminology."}
                </p>
              </div>

              <div className="bg-[#f3f7f5] border border-[#0f241d08] p-4 space-y-2">
                <span className="text-[9px] font-mono text-[#2d7a64] uppercase tracking-wider block font-bold">Grammar Focus</span>
                <p className="text-xs text-[#0f241d80] leading-relaxed">
                  {protocolTab === "beginner" && "Present tense conjugations, personal pronouns, basic question syntax, and noun-adjective alignment."}
                  {protocolTab === "mid" && "Past & future tenses, conditional structures, reflexive verbs, and core subordinating conjunctions."}
                  {protocolTab === "pro" && "Subjunctive mood, passive voice nuances, classical sentence structures, and advanced prefixes."}
                </p>
              </div>

              <div className="bg-[#f3f7f5] border border-[#0f241d08] p-4 space-y-2">
                <span className="text-[9px] font-mono text-[#2d7a64] uppercase tracking-wider block font-bold">Phrase Targets</span>
                <p className="text-xs text-[#0f241d80] leading-relaxed">
                  {protocolTab === "beginner" && "Introductions, asking for directions, ordering food, expressing basic likes and dislikes."}
                  {protocolTab === "mid" && "Expressing opinions, describing life experiences, giving advice, making reservations, bargaining."}
                  {protocolTab === "pro" && "Navigating business negotiations, diplomatic humor, cultural jokes, and literary criticisms."}
                </p>
              </div>

              <div className="bg-[#f3f7f5] border border-[#0f241d08] p-4 space-y-2">
                <span className="text-[9px] font-mono text-[#2d7a64] uppercase tracking-wider block font-bold">Sentence Complexity</span>
                <p className="text-xs text-[#0f241d80] leading-relaxed">
                  {protocolTab === "beginner" && "Simple Subject-Verb-Object clauses (e.g., \"I live here\" or \"What is this?\")."}
                  {protocolTab === "mid" && "Compound sentences linked with connectors (e.g., \"I went to the store because I needed water\")."}
                  {protocolTab === "pro" && "Intricate multi-clause nesting, hypothetical clauses, poetic inversions, and absolute modifiers."}
                </p>
              </div>
            </div>

            {/* Curated Interactive Word Database for Level */}
            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between">
                <h4 className="font-sans font-semibold tracking-tight font-bold text-lg text-[#0f241d] flex items-center gap-2">
                  <Brain className="w-5 h-5 text-[#2d7a64]" />
                  Curated Vocabulary Database ({protocolTab === "beginner" ? "Beginner" : protocolTab === "mid" ? "Mid-level" : "Pro level"})
                </h4>
                <span className="text-[10px] font-mono uppercase bg-[#0f241d] text-white px-2.5 py-1">
                  Click a word to frame sentences with AI
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                {(PROTOCOL_WORDS[activeProtocolLang.id]?.[protocolTab] || []).map((wordObj) => (
                  <button
                    key={wordObj.word}
                    onClick={() => {
                      setFramerWord({ word: wordObj.word, translation: wordObj.translation, level: protocolTab });
                      setFramerResult("");
                    }}
                    className="p-4 text-left border border-[#0f241d15] hover:border-black hover:bg-neutral-50 transition-all cursor-pointer group space-y-1 bg-[#f3f7f5]/30"
                  >
                    <span className="font-sans font-bold text-sm text-[#0f241d] block group-hover:text-[#2d7a64] transition-colors">
                      {wordObj.word}
                    </span>
                    <span className="text-xs text-[#0f241d60] block">
                      {wordObj.translation}
                    </span>
                    <span className="text-[10px] font-mono text-[#0f241d40] block">
                      IPA: {wordObj.pronunciation}
                    </span>
                    <div className="pt-2 flex items-center justify-between text-[9px] font-mono text-[#2d7a64] uppercase tracking-wider font-semibold opacity-60 group-hover:opacity-100 transition-opacity">
                      <span>Frame with AI</span>
                      <span>&rarr;</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* AI Sentence Framer Modal */}
      {framerWord && activeProtocolLang && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white border border-[#0f241d15] max-w-2xl w-full p-6 md:p-8 space-y-6 max-h-[90vh] overflow-y-auto shadow-2xl relative rounded-sm">
            <button
              onClick={() => setFramerWord(null)}
              className="absolute top-6 right-6 font-mono text-xs uppercase tracking-widest hover:text-red-600 transition-colors cursor-pointer text-[#0f241d60] bg-neutral-100 hover:bg-neutral-200 px-2.5 py-1"
            >
              [ Close Framer ]
            </button>

            <div>
              <span className="text-[10px] font-mono uppercase text-[#2d7a64] tracking-[0.2em] font-semibold">
                AI CO-PILOT SENTENCE GENERATOR
              </span>
              <h3 className="font-sans font-semibold tracking-tight font-medium text-2xl text-[#0f241d] mt-1">
                Sentence Framer: "{framerWord.word}"
              </h3>
              <p className="text-xs text-[#0f241d50] mt-0.5">
                Generate high-quality bilingual illustrative sentences with active grammar rules using your preferred state-of-the-art AI.
              </p>
            </div>

            {/* Control Panel */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#f3f7f5] p-4 border border-[#0f241d08]">
              {/* AI Model Selector */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-[#0f241d60] uppercase tracking-wider block font-bold">Choose AI Assistant</label>
                <div className="flex gap-2">
                  {(["gemini", "chatgpt", "claude"] as const).map((model) => (
                    <button
                      key={model}
                      onClick={() => setFramerModel(model)}
                      className={`flex-1 py-1.5 text-[10px] font-mono uppercase tracking-wider border cursor-pointer transition-all ${
                        framerModel === model
                          ? "bg-black text-white border-black font-semibold"
                          : "bg-white text-neutral-600 border-neutral-200 hover:border-black"
                      }`}
                    >
                      {model === "gemini" ? "Gemini ✨" : model === "chatgpt" ? "ChatGPT 🤖" : "Claude 🎭"}
                    </button>
                  ))}
                </div>
              </div>

              {/* Count Selector */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-[#0f241d60] uppercase tracking-wider block font-bold">Example Count / Request</label>
                <div className="flex gap-1.5 flex-wrap">
                  {[1, 5, 10].map((num) => (
                    <button
                      key={num}
                      onClick={() => setFramerCount(num)}
                      className={`px-2.5 py-1.5 text-[10px] font-mono border cursor-pointer transition-all ${
                        framerCount === num && framerCount !== 100
                          ? "bg-black text-white border-black"
                          : "bg-white text-neutral-600 border-neutral-200 hover:border-black"
                      }`}
                    >
                      {num} Example{num > 1 ? "s" : ""}
                    </button>
                  ))}
                  <button
                    onClick={() => {
                      setFramerCount(100);
                      showNotification("Requested maximum exemplar set (100 examples)!", "success");
                    }}
                    className={`px-3 py-1.5 text-[10px] font-mono border cursor-pointer transition-all ${
                      framerCount === 100
                        ? "bg-emerald-600 text-white border-emerald-600 font-bold"
                        : "bg-emerald-50 text-emerald-800 border-emerald-100 hover:border-emerald-600"
                    }`}
                  >
                    Give 100 Examples! 📚
                  </button>
                </div>
              </div>
            </div>

            {/* Trigger Button */}
            <button
              onClick={handleFrameSentencesAI}
              disabled={framerLoading}
              className="w-full bg-[#0f241d] text-white hover:bg-neutral-800 py-3.5 text-xs font-mono uppercase tracking-widest transition-all font-bold cursor-pointer flex items-center justify-center gap-2 border border-black disabled:opacity-50"
            >
              {framerLoading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Synthesizing illustrative sentences...
                </>
              ) : (
                `Frame Illustrative Sentences via ${framerModel.toUpperCase()} ⚡`
              )}
            </button>

            {/* Interactive Response Terminal */}
            {framerResult && (
              <div className="p-5 bg-[#f3f7f5] border border-[#0f241d15] space-y-3 font-sans font-semibold tracking-tight rounded-sm animate-fade-in text-sm text-[#0f241d] leading-relaxed max-h-[40vh] overflow-y-auto">
                <div className="flex items-center justify-between border-b border-[#0f241d10] pb-2 mb-3">
                  <span className="font-mono text-[9px] uppercase tracking-widest text-[#2d7a64] font-bold">
                    Generated via {framerModel.toUpperCase()} AI
                  </span>
                  <span className="font-mono text-[9px] uppercase tracking-widest text-[#0f241d40]">
                    Language: {activeProtocolLang.name} ({framerWord.level})
                  </span>
                </div>
                <div className="whitespace-pre-line text-neutral-800 space-y-2 font-sans text-xs">
                  {framerResult}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Blueprint Detail Drawer Overlay Modal */}
      {selectedBlueprint && (
        <div className="fixed inset-0 bg-[#0f241d70] backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white border border-[#0f241d15] max-w-2xl w-full p-8 md:p-10 space-y-6 max-h-[90vh] overflow-y-auto shadow-2xl relative">
            <button
              onClick={() => setSelectedBlueprint(null)}
              className="absolute top-6 right-6 font-mono text-xs uppercase tracking-widest hover:text-red-600 transition-colors cursor-pointer text-[#0f241d60]"
            >
              [ Close ]
            </button>

            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-[#e8f0eb] border border-[#0f241d10] flex items-center justify-center text-3xl">
                {FLAG_MAP[selectedBlueprint.id] || "🏳️"}
              </div>
              <div>
                <span className="text-[10px] font-mono uppercase text-[#2d7a64] tracking-[0.2em] font-semibold">
                  OFFICIAL STUDY GUIDE
                </span>
                <h3 className="font-sans font-semibold tracking-tight font-medium text-3xl text-[#0f241d] leading-tight">
                  {selectedBlueprint.name} Blueprint
                </h3>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 bg-[#f3f7f5] p-5 border border-[#0f241d08]">
              <div className="space-y-1">
                <span className="text-[9px] font-mono text-[#0f241d50] uppercase tracking-wider block">
                  Difficulty Level (FSI)
                </span>
                <span className="text-xs font-mono font-bold text-[#0f241d]">
                  {selectedBlueprint.difficulty}
                </span>
              </div>
              <div className="space-y-1">
                <span className="text-[9px] font-mono text-[#0f241d50] uppercase tracking-wider block">
                  Recommended Time
                </span>
                <span className="text-xs font-mono font-bold text-[#0f241d]">
                  {selectedBlueprint.timeCommitment}
                </span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <h4 className="font-sans font-semibold tracking-tight font-bold text-base text-[#0f241d]">
                  Dictionary Recommendation
                </h4>
                <div className="border border-[#0f241d10] p-4 bg-white flex items-center justify-between">
                  <div>
                    <span className="font-mono text-xs font-bold text-[#0f241d] block">
                      {selectedBlueprint.bestDictionary}
                    </span>
                    <span className="text-[10px] text-[#0f241d50] block mt-0.5">
                      Curated smartphone & web platform dictionary for fluent pronunciation and corpus examples.
                    </span>
                  </div>
                  <span className="text-[10px] font-mono uppercase bg-[#e8f0eb] border border-[#0f241d10] px-2 py-1 text-[#0f241d70]">
                    Highly Recommended
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-sans font-semibold tracking-tight font-bold text-base text-[#0f241d]">
                  Curated Learning Path
                </h4>
                <p className="text-sm text-[#0f241d80] leading-relaxed font-sans font-semibold tracking-tight">
                  "{selectedBlueprint.learningPath}"
                </p>
              </div>

              <div className="space-y-2 pt-2">
                <h4 className="font-sans font-semibold tracking-tight font-bold text-sm text-[#0f241d]">
                  Suggested Routine for {selectedBlueprint.name} Mastery:
                </h4>
                <ul className="text-xs font-mono text-[#0f241d70] space-y-2 list-disc list-inside">
                  <li>Dedicate <strong className="text-[#0f241d] font-semibold">15-30 minutes daily</strong> using Glosway's AI Chat Tutor to build syntax structure.</li>
                  <li>Use <strong className="text-[#0f241d] font-semibold">{selectedBlueprint.bestDictionary}</strong> to bookmark 5-10 core nouns daily.</li>
                  <li>Incorporate podcasts or classical literature to build auditory comprehension.</li>
                </ul>
              </div>
            </div>

            <div className="pt-6 border-t border-[#0f241d10] flex gap-3">
              <button
                onClick={() => setSelectedBlueprint(null)}
                className="flex-1 bg-[#f3f7f5] border border-[#0f241d15] hover:bg-[#e8f0eb] text-[#0f241d60] hover:text-[#0f241d] text-xs font-mono uppercase tracking-widest py-3 cursor-pointer transition-colors"
              >
                Go Back
              </button>
              
              {!userProfile?.languages?.[selectedBlueprint.id] ? (
                <button
                  onClick={() => {
                    handleAddLanguage(selectedBlueprint.id, selectedBlueprint.name);
                    setSelectedBlueprint(null);
                  }}
                  className="flex-1 bg-[#0f241d] hover:bg-[#25332e] text-[#f3f7f5] text-xs font-mono uppercase tracking-widest py-3 cursor-pointer transition-all"
                >
                  Unlock & Start Learning
                </button>
              ) : (
                <button
                  onClick={() => {
                    onNavigate("tutor");
                    setSelectedBlueprint(null);
                  }}
                  className="flex-1 bg-[#2d7a64] hover:bg-[#b0936b] text-white text-xs font-mono uppercase tracking-widest py-3 cursor-pointer transition-all"
                >
                  Start Active Session
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Interactive Skill Confidence Diagnostics */}
      <section className="space-y-6">
        <div className="pb-4 border-b border-[#0f241d10]">
          <div className="flex items-center gap-2 text-[#2d7a64]">
            <Info className="w-4 h-4" />
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] font-semibold font-bold">Confidence Diagnostics Center</span>
          </div>
          <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d] mt-1">
            Skill Categories & Confidence Analytics
          </h2>
          <p className="text-xs text-[#0f241d50] mt-0.5">
            Click any skill category to see the precise pedagogical calculation rules explaining how your confidence scores are generated.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Vocabulary Card */}
          <button
            onClick={() => setSelectedConfidenceTab("vocabulary")}
            className={`text-left p-5 border transition-all cursor-pointer block space-y-4 w-full ${
              selectedConfidenceTab === "vocabulary"
                ? "bg-black text-[#f3f7f5] border-black shadow-md scale-102"
                : "bg-white text-[#0f241d] border-[#0f241d15] hover:border-black"
            }`}
          >
            <div className={`w-10 h-10 border flex items-center justify-center ${
              selectedConfidenceTab === "vocabulary" ? "border-neutral-800 bg-neutral-900" : "border-[#0f241d15] bg-[#e8f0eb]"
            }`}>
              <BookOpen className="w-5 h-5 text-[#2d7a64]" />
            </div>
            <div>
              <h3 className="font-sans font-semibold tracking-tight font-semibold text-lg">Vocabulary Progress</h3>
              <p className={`text-xs font-mono uppercase tracking-wider mt-1 ${
                selectedConfidenceTab === "vocabulary" ? "text-neutral-400" : "text-[#0f241d50]"
              }`}>
                {userProfile ? userProfile.wordsLearned : 842} words learned
              </p>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-[10px] font-mono uppercase tracking-wider">
                <span>Confidence Index</span>
                <span className="font-bold">78%</span>
              </div>
              <div className="h-1.5 w-full bg-[#f3f7f5]/20 border border-neutral-800/10 overflow-hidden">
                <div className="h-full bg-[#2d7a64] transition-all duration-500" style={{ width: "78%" }}></div>
              </div>
            </div>
          </button>

          {/* Grammar Card */}
          <button
            onClick={() => setSelectedConfidenceTab("grammar")}
            className={`text-left p-5 border transition-all cursor-pointer block space-y-4 w-full ${
              selectedConfidenceTab === "grammar"
                ? "bg-black text-[#f3f7f5] border-black shadow-md scale-102"
                : "bg-white text-[#0f241d] border-[#0f241d15] hover:border-black"
            }`}
          >
            <div className={`w-10 h-10 border flex items-center justify-center ${
              selectedConfidenceTab === "grammar" ? "border-neutral-800 bg-neutral-900" : "border-[#0f241d15] bg-[#e8f0eb]"
            }`}>
              <Award className="w-5 h-5 text-[#2d7a64]" />
            </div>
            <div>
              <h3 className="font-sans font-semibold tracking-tight font-semibold text-lg">Grammar Structures</h3>
              <p className={`text-xs font-mono uppercase tracking-wider mt-1 ${
                selectedConfidenceTab === "grammar" ? "text-neutral-400" : "text-[#0f241d50]"
              }`}>
                Past Tenses & Modals
              </p>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-[10px] font-mono uppercase tracking-wider">
                <span>Confidence Index</span>
                <span className="font-bold">42%</span>
              </div>
              <div className="h-1.5 w-full bg-[#f3f7f5]/20 border border-neutral-800/10 overflow-hidden">
                <div className="h-full bg-[#2d7a64] transition-all duration-500" style={{ width: "42%" }}></div>
              </div>
            </div>
          </button>

          {/* Phrases Card */}
          <button
            onClick={() => setSelectedConfidenceTab("phrases")}
            className={`text-left p-5 border transition-all cursor-pointer block space-y-4 w-full ${
              selectedConfidenceTab === "phrases"
                ? "bg-black text-[#f3f7f5] border-black shadow-md scale-102"
                : "bg-white text-[#0f241d] border-[#0f241d15] hover:border-black"
            }`}
          >
            <div className={`w-10 h-10 border flex items-center justify-center ${
              selectedConfidenceTab === "phrases" ? "border-neutral-800 bg-neutral-900" : "border-[#0f241d15] bg-[#e8f0eb]"
            }`}>
              <MessageSquare className="w-5 h-5 text-[#2d7a64]" />
            </div>
            <div>
              <h3 className="font-sans font-semibold tracking-tight font-semibold text-lg">Conversational Phrases</h3>
              <p className={`text-xs font-mono uppercase tracking-wider mt-1 ${
                selectedConfidenceTab === "phrases" ? "text-neutral-400" : "text-[#0f241d50]"
              }`}>
                Ordering & Household
              </p>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-[10px] font-mono uppercase tracking-wider">
                <span>Confidence Index</span>
                <span className="font-bold">91%</span>
              </div>
              <div className="h-1.5 w-full bg-[#f3f7f5]/20 border border-neutral-800/10 overflow-hidden">
                <div className="h-full bg-[#2d7a64] transition-all duration-500" style={{ width: "91%" }}></div>
              </div>
            </div>
          </button>

          {/* Listening Card */}
          <button
            onClick={() => setSelectedConfidenceTab("listening")}
            className={`text-left p-5 border transition-all cursor-pointer block space-y-4 w-full ${
              selectedConfidenceTab === "listening"
                ? "bg-black text-[#f3f7f5] border-black shadow-md scale-102"
                : "bg-white text-[#0f241d] border-[#0f241d15] hover:border-black"
            }`}
          >
            <div className={`w-10 h-10 border flex items-center justify-center ${
              selectedConfidenceTab === "listening" ? "border-neutral-800 bg-neutral-900" : "border-[#0f241d15] bg-[#e8f0eb]"
            }`}>
              <Headphones className="w-5 h-5 text-[#2d7a64]" />
            </div>
            <div>
              <h3 className="font-sans font-semibold tracking-tight font-semibold text-lg">Listening Clarity</h3>
              <p className={`text-xs font-mono uppercase tracking-wider mt-1 ${
                selectedConfidenceTab === "listening" ? "text-neutral-400" : "text-[#0f241d50]"
              }`}>
                Intermediate Dialogues
              </p>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-[10px] font-mono uppercase tracking-wider">
                <span>Confidence Index</span>
                <span className="font-bold">65%</span>
              </div>
              <div className="h-1.5 w-full bg-[#f3f7f5]/20 border border-neutral-800/10 overflow-hidden">
                <div className="h-full bg-[#2d7a64] transition-all duration-500" style={{ width: "65%" }}></div>
              </div>
            </div>
          </button>
        </div>

        {/* Dynamic Explanation Panel Box */}
        <div className="bg-[#f3f7f5] border border-[#0f241d15] p-6 animate-fade-in space-y-4 rounded-sm">
          <div className="flex items-center gap-3 border-b border-[#0f241d10] pb-3">
            <div className="w-2.5 h-2.5 bg-[#2d7a64] rounded-full animate-ping"></div>
            <h4 className="font-sans font-semibold tracking-tight font-bold text-[#0f241d] text-base uppercase tracking-wider">
              How is your {selectedConfidenceTab.toUpperCase()} confidence calculated?
            </h4>
          </div>

          {selectedConfidenceTab === "vocabulary" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
              <div className="md:col-span-2 space-y-3">
                <p className="text-neutral-700 leading-relaxed font-sans font-semibold tracking-tight text-sm">
                  "Your Vocabulary Confidence sits at <strong className="text-black">78%</strong>. This represents a highly accurate lexical grasp of active words based on your interactive study sessions."
                </p>
                <div className="font-mono text-[11px] bg-white p-3 border border-neutral-200 text-neutral-600 space-y-1">
                  <p className="font-bold text-black uppercase">🧮 PEDAGOGICAL CALCULATION RULE:</p>
                  <p className="text-emerald-700 font-bold">Confidence = (Active Review Words / Ideal Word Interval) × Average Quiz Accuracy × Interval Retention Weight</p>
                  <p>• Active Review Words: {userProfile ? userProfile.wordsLearned : 842} words parsed</p>
                  <p>• Average Quiz Accuracy: 88.63% over active vocabulary tests</p>
                  <p>• Interval Retention Weight: 1.0 (Optimal spaced repetition recall schedule)</p>
                </div>
              </div>
              <div className="border-l border-[#0f241d10] pl-6 space-y-2">
                <span className="font-mono text-[10px] uppercase text-[#2d7a64] block font-bold">TO ADVANCE CONFIDENCE:</span>
                <ul className="list-disc list-inside space-y-1 text-neutral-600 leading-relaxed font-sans">
                  <li>Complete 3 consecutive vocabulary quiz sheets.</li>
                  <li>Click "Start Now" on any blueprint and tap core words to frame sentences.</li>
                </ul>
              </div>
            </div>
          )}

          {selectedConfidenceTab === "grammar" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
              <div className="md:col-span-2 space-y-3">
                <p className="text-neutral-700 leading-relaxed font-sans font-semibold tracking-tight text-sm">
                  "Your Grammar Confidence is <strong className="text-black">42%</strong>. This represents a solid beginner foundation with structural tenses, but intermediate moods are currently locked."
                </p>
                <div className="font-mono text-[11px] bg-white p-3 border border-neutral-200 text-neutral-600 space-y-1">
                  <p className="font-bold text-black uppercase">🧮 PEDAGOGICAL CALCULATION RULE:</p>
                  <p className="text-emerald-700 font-bold">Confidence = (Successfully Applied Grammar Rules / Standard Curriculum Path) × Success Margin × Structural Score</p>
                  <p>• Rules Explored: Present Indicative conjugations, singular/plural pronouns</p>
                  <p>• Success Margin: 92% accurate structure output in tutor conversations</p>
                  <p>• Standard Path: Past Subjunctive, Conditional, and Indirect Discourse are still pending active study</p>
                </div>
              </div>
              <div className="border-l border-[#0f241d10] pl-6 space-y-2">
                <span className="font-mono text-[10px] uppercase text-[#2d7a64] block font-bold">TO ADVANCE CONFIDENCE:</span>
                <ul className="list-disc list-inside space-y-1 text-neutral-600 leading-relaxed font-sans">
                  <li>Initiate conversations about past/future hypothetical scenarios.</li>
                  <li>Request advanced grammar worksheets via the AI Chat Tutor.</li>
                </ul>
              </div>
            </div>
          )}

          {selectedConfidenceTab === "phrases" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
              <div className="md:col-span-2 space-y-3">
                <p className="text-neutral-700 leading-relaxed font-sans font-semibold tracking-tight text-sm">
                  "Your Phrase Confidence sits at an exceptional <strong className="text-black">91%</strong>. This indicates high fluency in typical household scenarios and service situations."
                </p>
                <div className="font-mono text-[11px] bg-white p-3 border border-neutral-200 text-neutral-600 space-y-1">
                  <p className="font-bold text-black uppercase">🧮 PEDAGOGICAL CALCULATION RULE:</p>
                  <p className="text-emerald-700 font-bold">Confidence = (Idomatic Collocations Used / Fluent Conversational Targets) × Pronunciation Clarity score</p>
                  <p>• Idioms Expressed: "Ordering at cafes", "Family descriptors", "Greeting strangers"</p>
                  <p>• Pronunciation Clarity score: 91% (based on precise audio feedback inputs)</p>
                </div>
              </div>
              <div className="border-l border-[#0f241d10] pl-6 space-y-2">
                <span className="font-mono text-[10px] uppercase text-[#2d7a64] block font-bold">TO ADVANCE CONFIDENCE:</span>
                <ul className="list-disc list-inside space-y-1 text-neutral-600 leading-relaxed font-sans">
                  <li>Explore the "Pro level" phrases under any Language Protocol guide.</li>
                  <li>Incorporate local slang into Chat Tutor sessions.</li>
                </ul>
              </div>
            </div>
          )}

          {selectedConfidenceTab === "listening" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
              <div className="md:col-span-2 space-y-3">
                <p className="text-neutral-700 leading-relaxed font-sans font-semibold tracking-tight text-sm">
                  "Your Listening Confidence is <strong className="text-black">65%</strong>. You understand slow fluent speech, but real-time radio streams or slurred speech remain challenging."
                </p>
                <div className="font-mono text-[11px] bg-white p-3 border border-neutral-200 text-neutral-600 space-y-1">
                  <p className="font-bold text-black uppercase">🧮 PEDAGOGICAL CALCULATION RULE:</p>
                  <p className="text-emerald-700 font-bold">Confidence = (Completed Listening Drills / Speed/Accent Modulations) × Audio Retries Ratio</p>
                  <p>• Completed Drills: 14 auditory exercises checked</p>
                  <p>• Speed/Accent Modulations: Tested up to 1.1x speed without failure</p>
                  <p>• Retries Ratio: 1.3 attempts per audio snippet average</p>
                </div>
              </div>
              <div className="border-l border-[#0f241d10] pl-6 space-y-2">
                <span className="font-mono text-[10px] uppercase text-[#2d7a64] block font-bold">TO ADVANCE CONFIDENCE:</span>
                <ul className="list-disc list-inside space-y-1 text-neutral-600 leading-relaxed font-sans">
                  <li>Ask the AI Tutor to play audio transcripts in fast-conversational mode.</li>
                  <li>Translate complex audio quizzes directly under the Listening View.</li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Bento Layout Lower Section */}
      <div className="w-full bg-white border border-[#0f241d15] p-6 md:p-8 flex flex-col justify-between group">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="font-sans font-semibold tracking-tight text-2xl font-medium text-[#0f241d]">Continue Learning</h2>
            <p className="text-[#0f241d60] mt-1 text-xs">
              Resume where you left off: Unit 4 - At the Airport
            </p>
          </div>
          <div className="w-12 h-12 border border-[#0f241d10] bg-[#e8f0eb] flex items-center justify-center text-[#0f241d]">
            <Compass className="w-6 h-6" />
          </div>
        </div>
        <div className="bg-[#f3f7f5] border border-[#0f241d10] p-5 mb-6 flex items-center gap-4">
          <div className="w-12 h-12 bg-white border border-[#0f241d] flex items-center justify-center text-[#0f241d] hover:bg-[#e8f0eb] cursor-pointer active:scale-95 transition-all">
            <Play className="w-5 h-5 fill-[#0f241d] text-[#0f241d]" />
          </div>
          <div className="flex-1 space-y-2">
            <div className="h-1.5 w-full bg-[#e8f0eb] border border-[#0f241d05] overflow-hidden">
              <div className="h-full bg-[#0f241d]" style={{ width: "65%" }}></div>
            </div>
            <div className="flex justify-between text-xs font-mono uppercase text-[#0f241d60]">
              <span>Part 2: Check-in Procedures</span>
              <span>65% Complete</span>
            </div>
          </div>
        </div>
        <button
          onClick={() => onNavigate("tutor")}
          className="w-full bg-[#0f241d] text-[#f3f7f5] hover:bg-[#25332e] font-mono text-xs uppercase tracking-widest py-4 transition-all flex items-center justify-center gap-2 cursor-pointer border border-[#0f241d]"
        >
          Continue Learning
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* AI Mentor Floating Action Button */}
      <button
        id="ai-mentor-fab"
        onClick={() => setIsMentorOpen(true)}
        className="fixed bottom-6 right-6 z-40 bg-[#0f241d] text-[#f3f7f5] hover:bg-[#2d7a64] hover:text-[#0f241d] border border-[#2d7a64]/30 shadow-2xl p-4 rounded-full flex items-center justify-center cursor-pointer transition-all hover:scale-105 active:scale-95 group"
        title="AI Mentor"
      >
        <Brain className="w-6 h-6 animate-pulse group-hover:rotate-6 transition-transform text-[#2d7a64] group-hover:text-[#0f241d]" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 ease-out whitespace-nowrap font-mono text-[10px] uppercase tracking-widest pl-0 group-hover:pl-2">
          AI Mentor
        </span>
      </button>

      {/* AI Mentor Drawer */}
      {isMentorOpen && (
        <div 
          className="fixed inset-0 bg-black/40 backdrop-blur-xs z-50 flex justify-end" 
          onClick={() => setIsMentorOpen(false)}
        >
          <div 
            className="w-full max-w-md bg-[#f3f7f5] h-full shadow-2xl border-l border-[#0f241d15] flex flex-col justify-between overflow-hidden relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Drawer Header */}
            <div className="p-6 border-b border-[#0f241d10] flex items-center justify-between bg-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#0f241d] border border-[#2d7a64]/30 flex items-center justify-center">
                  <Brain className="w-5 h-5 text-[#2d7a64]" />
                </div>
                <div>
                  <h3 className="font-sans font-semibold tracking-tight font-bold text-base text-[#0f241d]">
                    ai mentor, Your AI Mentor
                  </h3>
                  <span className="text-[9px] font-mono uppercase text-emerald-600 tracking-widest font-extrabold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    Synchronized & Active
                  </span>
                </div>
              </div>
              <button 
                onClick={() => setIsMentorOpen(false)}
                className="p-2 text-[#0f241d50] hover:text-[#0f241d] hover:bg-neutral-100 transition-colors cursor-pointer"
              >
                <Plus className="w-5 h-5 rotate-45" />
              </button>
            </div>

            {/* Drawer Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              
              {/* Toggle Mode Control */}
              <div className="bg-white border border-[#0f241d10] p-4 space-y-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#2d7a64]" />
                    <span className="text-xs font-mono font-bold uppercase text-[#0f241d]">
                      Quick Context Mode
                    </span>
                  </div>
                  
                  {/* Custom Premium Toggle Switch */}
                  <button
                    onClick={handleToggleQuickContext}
                    className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                      isQuickContextMode ? "bg-[#0f241d]" : "bg-neutral-200"
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                        isQuickContextMode ? "translate-x-5" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>
                <p className="text-[11px] text-[#0f241d60] font-sans font-semibold tracking-tight leading-relaxed">
                  When enabled, ai mentor reviews your 5 most recently searched dictionary words and current study progress to generate tailored suggestions.
                </p>
              </div>

              {/* Quick Context Content or Disabled Notice */}
              {!isQuickContextMode ? (
                <div className="text-center py-10 px-4 space-y-4">
                  <div className="w-12 h-12 bg-[#e8f0eb] border border-dashed border-[#0f241d15] rounded-full flex items-center justify-center mx-auto text-neutral-400">
                    <Sparkles className="w-6 h-6 text-neutral-300" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-sans font-semibold tracking-tight font-bold text-sm text-[#0f241d]">
                      Quick Context Deactivated
                    </h4>
                    <p className="text-xs text-[#0f241d50] leading-relaxed max-w-xs mx-auto">
                      Turn on Quick Context Mode to let your AI Mentor analyze recent lookups and metrics to generate custom grammar recommendations and vocabulary drills.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  
                  {/* Live Context Stats Panel */}
                  <div className="space-y-2">
                    <span className="text-[9px] font-mono uppercase tracking-wider text-[#0f241d50] font-bold">
                      Feeding Into Mentor Engine:
                    </span>
                    <div className="grid grid-cols-1 gap-2">
                      <div className="bg-white p-2.5 border border-[#0f241d08] flex flex-col justify-between">
                        <div>
                          <span className="text-[8px] font-mono text-[#0f241d40] uppercase block">
                            Study Statistics
                          </span>
                          <span className="text-[10px] font-mono font-bold block mt-1">
                            Streak: {userProfile?.streak || 0}d
                          </span>
                          <span className="text-[10px] font-mono block text-[#0f241d60]">
                            Words: {userProfile?.wordsLearned || 0}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* AI Recommendations Area */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between border-b border-[#0f241d10] pb-2">
                      <span className="text-[9px] font-mono uppercase tracking-wider text-[#2d7a64] font-bold flex items-center gap-1.5">
                        <Brain className="w-3 h-3 animate-pulse" /> ai mentor's Recommendations
                      </span>
                      <button
                        onClick={fetchMentorSuggestions}
                        disabled={isMentorLoading}
                        className="text-[9px] font-mono uppercase text-[#0f241d] hover:text-[#2d7a64] cursor-pointer font-bold underline"
                      >
                        {isMentorLoading ? "Generating..." : "Regenerate"}
                      </button>
                    </div>

                    {isMentorLoading ? (
                      <div className="space-y-4 py-8">
                        <div className="flex items-center justify-center gap-2">
                          <span className="w-1.5 h-1.5 bg-[#2d7a64] rounded-full animate-bounce"></span>
                          <span className="w-1.5 h-1.5 bg-[#2d7a64] rounded-full animate-bounce [animation-delay:0.2s]"></span>
                          <span className="w-1.5 h-1.5 bg-[#2d7a64] rounded-full animate-bounce [animation-delay:0.4s]"></span>
                        </div>
                        <p className="text-[10px] font-mono text-center text-[#0f241d40] uppercase tracking-wider">
                          Analyzing dictionary search list & study metrics...
                        </p>
                      </div>
                    ) : mentorError ? (
                      <div className="p-4 bg-red-50/50 border border-red-100 text-red-700 text-xs text-center space-y-2">
                        <p>{mentorError}</p>
                        <button 
                          onClick={fetchMentorSuggestions} 
                          className="text-[10px] font-mono uppercase underline text-red-800 hover:text-red-950 font-bold"
                        >
                          Try Again
                        </button>
                      </div>
                    ) : mentorSuggestions ? (
                      <div className="space-y-4 font-sans font-semibold tracking-tight text-sm bg-white border border-[#0f241d10] p-4 leading-relaxed shadow-xs text-[#0f241d80] max-h-[45vh] overflow-y-auto">
                        <div className="markdown-body">
                          <ReactMarkdown>{mentorSuggestions}</ReactMarkdown>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-6">
                        <button
                          onClick={fetchMentorSuggestions}
                          className="px-4 py-2 bg-black text-white hover:bg-neutral-800 text-[10px] font-mono uppercase tracking-wider font-semibold cursor-pointer"
                        >
                          Generate First Suggestions
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

            </div>

            {/* Drawer Footer */}
            <div className="p-6 border-t border-[#0f241d10] bg-white">
              <button
                onClick={() => {
                  setIsMentorOpen(false);
                  onNavigate("tutor");
                }}
                className="w-full bg-[#0f241d] hover:bg-[#25332e] text-white py-3.5 text-xs font-mono uppercase tracking-widest font-semibold transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                Open Interactive AI Chat Tutor &rarr;
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Full screen Milestone Celebration Modal & Confetti Overlay */}
      {activeCelebration && (
        <MilestoneCelebration
          milestone={activeCelebration}
          onClose={() => setActiveCelebration(null)}
        />
      )}
    </div>
  );
}
