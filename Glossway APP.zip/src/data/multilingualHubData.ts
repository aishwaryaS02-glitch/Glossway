export interface VocabWord {
  word: string;
  pronunciation: string;
  translation: string;
  partOfSpeech: string;
}

export interface ExpressionPhrase {
  phrase: string;
  pronunciation: string;
  translation: string;
  context: string;
}

export interface GrammarRule {
  ruleName: string;
  explanation: string;
  structure: string;
  examples: {
    native: string;
    pronunciation: string;
    translation: string;
  }[];
}

export interface MultilingualLanguageData {
  id: string;
  name: string;
  flag: string;
  beginner: VocabWord[];
  middleware: ExpressionPhrase[];
  pro: GrammarRule[];
}

export const MULTILINGUAL_DATA: MultilingualLanguageData[] = [
  {
    id: "kannada",
    name: "Kannada",
    flag: "🇮🇳",
    beginner: [
      { word: "Namaskara", pronunciation: "Nah-mah-skah-rah", translation: "Hello / Greetings", partOfSpeech: "Noun" },
      { word: "Dhanyavada", pronunciation: "Dhan-yah-vah-dah", translation: "Thank you", partOfSpeech: "Noun" },
      { word: "Mane", pronunciation: "Mah-neh", translation: "House / Home", partOfSpeech: "Noun" },
      { word: "Oota", pronunciation: "Oo-tah", translation: "Food / Meal", partOfSpeech: "Noun" },
      { word: "Neeru", pronunciation: "Nee-roo", translation: "Water", partOfSpeech: "Noun" },
      { word: "Siri", pronunciation: "See-ree", translation: "Wealth / Prosperity", partOfSpeech: "Noun" },
      { word: "Pustaka", pronunciation: "Poos-tah-kah", translation: "Book", partOfSpeech: "Noun" },
      { word: "Havu", pronunciation: "Haa-voo", translation: "Snake", partOfSpeech: "Noun" },
      { word: "Halli", pronunciation: "Hal-lee", translation: "Village", partOfSpeech: "Noun" },
      { word: "Shaale", pronunciation: "Shaa-leh", translation: "School", partOfSpeech: "Noun" },
      { word: "Kaadu", pronunciation: "Kaa-doo", translation: "Forest / Woods", partOfSpeech: "Noun" },
      { word: "Surya", pronunciation: "Soor-yah", translation: "Sun", partOfSpeech: "Noun" },
      { word: "Chandra", pronunciation: "Chan-drah", translation: "Moon", partOfSpeech: "Noun" },
      { word: "Preethi", pronunciation: "Pree-thee", translation: "Love", partOfSpeech: "Noun" },
      { word: "Sneha", pronunciation: "Sneh-hah", translation: "Friendship", partOfSpeech: "Noun" }
    ],
    middleware: [
      { phrase: "Hegiddeera?", pronunciation: "Heh-gidh-ee-rah", translation: "How are you? (Polite)", context: "Standard greeting" },
      { phrase: "Oota aaytha?", pronunciation: "Oo-tah eye-thah", translation: "Have you eaten?", context: "Very common friendly inquiry" },
      { phrase: "Nanna hesaru...", pronunciation: "Nan-nah heh-sah-roo", translation: "My name is...", context: "Introducing oneself" },
      { phrase: "Innu ondhu kodi", pronunciation: "In-noo on-dhoo koh-dee", translation: "Please give me one more", context: "Ordering food or requesting items" },
      { phrase: "Kannada gotthilla", pronunciation: "Kan-nah-dah goh-theel-lah", translation: "I do not know Kannada", context: "Polite excuse for beginners" },
      { phrase: "Yelli iddeera?", pronunciation: "Yel-lee idh-ee-rah", translation: "Where are you? (Polite)", context: "Locating someone" },
      { phrase: "Idhara bele yestu?", pronunciation: "Ee-dha-rah beh-leh yes-too", translation: "How much is this?", context: "Shopping context" },
      { phrase: "Sahaya madi", pronunciation: "Sah-haa-yah maa-dee", translation: "Please help me", context: "Asking for assistance" },
      { phrase: "Bega banni", pronunciation: "Beh-gah ban-nee", translation: "Come quickly", context: "Urgency call" },
      { phrase: "Thumba santhosha", pronunciation: "Thoom-bah san-thoh-shah", translation: "Very happy", context: "Expressing joy" }
    ],
    pro: [
      {
        ruleName: "Subject-Object-Verb (SOV) Syntax Alignment",
        explanation: "Unlike English (SVO), Kannada strictly places the Verb at the end of the sentence. Nouns and pronouns are declined for eight case categories.",
        structure: "Subject + Object + Verb (e.g. Nanu + Neeru + Kudiyuttene)",
        examples: [
          { native: "Nanu neeru kudiyuttene.", pronunciation: "Naa-noo nee-roo koo-dee-yoot-theh-neh", translation: "I drink water. (Subject: I, Object: Water, Verb: Drink)" },
          { native: "Avaru manege hodharu.", pronunciation: "Ah-vah-roo mah-neh-geh hoh-dhah-roo", translation: "They went to the house. (Subject: They, Object-Case: To house, Verb: Went)" }
        ]
      },
      {
        ruleName: "Politeness Suffix Conjugation",
        explanation: "Verbs change structural suffixes to convey respect. Adding '-eera' or '-iri' signals a formal context.",
        structure: "Root Verb + Respect Suffix",
        examples: [
          { native: "Banni, kootukolli.", pronunciation: "Ban-nee, koo-too-kol-lee", translation: "Please come, please sit down. (Very polite command)" },
          { native: "Neevu yelli iddeera?", pronunciation: "Nee-voo yel-lee idh-ee-rah", translation: "Where are you? (Formal/Polite direct query)" }
        ]
      },
      {
        ruleName: "Locative and Dative Case Declension",
        explanation: "The locative suffix '-alli' (meaning 'in/at') and the dative suffix '-ge' or '-ige' (meaning 'to') alter nouns dynamically.",
        structure: "Noun Root + '-alli' (Locative) OR + '-ge'/'-ige' (Dative)",
        examples: [
          { native: "Nanu maneyalli iddhane.", pronunciation: "Naa-noo mah-neh-yal-lee idh-dhaa-neh", translation: "I am inside the house. (Mane + alli = Maneyalli)" },
          { native: "Avaru Bengaluru-ige hodharu.", pronunciation: "Ah-vah-roo Beng-ah-loo-roo-ee-geh hoh-dhah-roo", translation: "They went to Bangalore." }
        ]
      }
    ]
  },
  {
    id: "hindi",
    name: "Hindi",
    flag: "🇮🇳",
    beginner: [
      { word: "Namaste", pronunciation: "Nah-mah-stay", translation: "Hello", partOfSpeech: "Noun" },
      { word: "Dhanyavaad", pronunciation: "Dhan-yah-vaad", translation: "Thank you", partOfSpeech: "Noun" },
      { word: "Ghar", pronunciation: "Ghur", translation: "House", partOfSpeech: "Noun" },
      { word: "Khana", pronunciation: "Kha-na", translation: "Food / To eat", partOfSpeech: "Noun/Verb" },
      { word: "Paani", pronunciation: "Paa-nee", translation: "Water", partOfSpeech: "Noun" },
      { word: "Shanti", pronunciation: "Shan-tee", translation: "Peace", partOfSpeech: "Noun" },
      { word: "Mitra", pronunciation: "Mee-truh", translation: "Friend", partOfSpeech: "Noun" },
      { word: "Kitab", pronunciation: "Kee-taab", translation: "Book", partOfSpeech: "Noun" },
      { word: "Shahar", pronunciation: "Shah-hur", translation: "City", partOfSpeech: "Noun" },
      { word: "Ped", pronunciation: "Paydh", translation: "Tree", partOfSpeech: "Noun" },
      { word: "Phool", pronunciation: "Phool", translation: "Flower", partOfSpeech: "Noun" },
      { word: "Sooraj", pronunciation: "Soo-ruj", translation: "Sun", partOfSpeech: "Noun" },
      { word: "Pyaar", pronunciation: "Pyahr", translation: "Love", partOfSpeech: "Noun" },
      { word: "Zindagi", pronunciation: "Zeen-dhah-gee", translation: "Life", partOfSpeech: "Noun" },
      { word: "Koshish", pronunciation: "Koh-sheesh", translation: "Effort / Try", partOfSpeech: "Noun" }
    ],
    middleware: [
      { phrase: "Aap kaise hain?", pronunciation: "Aap kay-say hain", translation: "How are you? (Polite)", context: "Formal greeting" },
      { phrase: "Mera naam... hai", pronunciation: "May-rah naam... hai", translation: "My name is...", context: "Introducing oneself" },
      { phrase: "Mujhe paani chahiye", pronunciation: "Moo-jhay paa-nee chaa-hee-yay", translation: "I want water", context: "Expressing immediate need" },
      { phrase: "Aapka swagat hai", pronunciation: "Aap-ka swah-gut hai", translation: "You are welcome", context: "Hospitality response" },
      { phrase: "Phir milenge", pronunciation: "Pheer mee-leng-ay", translation: "See you again", context: "Friendly departure parting" },
      { phrase: "Aap kahan se hain?", pronunciation: "Aap kah-haan say hain?", translation: "Where are you from?", context: "Asking background" },
      { phrase: "Yeh kitne ka hai?", pronunciation: "Yeh keet-nay ka hai?", translation: "How much is this?", context: "Shopping context" },
      { phrase: "Kya aap meri madad karenge?", pronunciation: "Kyah aap may-ree muh-dhudh kah-reng-ay?", translation: "Will you help me?", context: "Asking for help" },
      { phrase: "Mujhe samajh nahi aaya", pronunciation: "Moo-jhay suh-mujh nuh-hee aa-yah", translation: "I did not understand", context: "Language barrier" },
      { phrase: "Aapka din shubh ho", pronunciation: "Aap-ka deen shoobh ho", translation: "Have a nice day", context: "Friendly farewell" }
    ],
    pro: [
      {
        ruleName: "Gender and Verb Agreements",
        explanation: "In Hindi, every noun has an assigned masculine or feminine gender. Verbs must match both the subject's gender and count.",
        structure: "Subject (Masculine/Feminine) + Object + Verb (Conjugated)",
        examples: [
          { native: "Main jata hoon.", pronunciation: "Main jaa-taa hoon", translation: "I go. (Said by a male)" },
          { native: "Main jati hoon.", pronunciation: "Main jaa-tee hoon", translation: "I go. (Said by a female)" }
        ]
      },
      {
        ruleName: "Ergative Case with Ne (ने)",
        explanation: "When utilizing transitive verbs in perfect tenses, the subject takes the marker 'ne' (ने), and the verb agrees with the direct object instead of the subject.",
        structure: "Subject + ne + Object + Verb (agrees with Object)",
        examples: [
          { native: "Maine khana khaya.", pronunciation: "Main-nay khaa-naa khaa-yaa", translation: "I ate food. ('Khana' is masculine, so verb agrees with it)" },
          { native: "Maine roti khayi.", pronunciation: "Main-nay roh-tee khaa-yee", translation: "I ate roti. ('Roti' is feminine, verb modifies accordingly)" }
        ]
      },
      {
        ruleName: "Oblique Case Inflection",
        explanation: "Nouns inflect into the oblique case when followed by a postposition (like 'ko', 'se', 'mein', 'par'). Masculine singular nouns ending in '-aa' change to '-ay'.",
        structure: "Noun Root (Inflected) + Postposition",
        examples: [
          { native: "Ladke ko paani do.", pronunciation: "Lud-kay koh paa-nee doh", translation: "Give water to the boy. ('Ladka' inflects to 'Ladke' before 'ko')" },
          { native: "Kamre mein kaun hai?", pronunciation: "Kum-ray mein kohn hai?", translation: "Who is in the room? ('Kamra' becomes 'Kamre' before 'mein')" }
        ]
      }
    ]
  },
  {
    id: "english",
    name: "English",
    flag: "🇬🇧",
    beginner: [
      { word: "Hello", pronunciation: "Huh-loh", translation: "Friendly greeting", partOfSpeech: "Interjection" },
      { word: "Thanks", pronunciation: "Thangks", translation: "Gratitude", partOfSpeech: "Noun" },
      { word: "Home", pronunciation: "Hohm", translation: "Living place", partOfSpeech: "Noun" },
      { word: "Food", pronunciation: "Food", translation: "Sustenance", partOfSpeech: "Noun" },
      { word: "Water", pronunciation: "Wah-ter", translation: "Liquid hydration", partOfSpeech: "Noun" },
      { word: "Friend", pronunciation: "Frend", translation: "Companion", partOfSpeech: "Noun" },
      { word: "Book", pronunciation: "Book", translation: "Reading bound material", partOfSpeech: "Noun" },
      { word: "School", pronunciation: "Skool", translation: "Educational institution", partOfSpeech: "Noun" },
      { word: "City", pronunciation: "Sit-ee", translation: "Large urban center", partOfSpeech: "Noun" },
      { word: "Time", pronunciation: "Tym", translation: "Continuous sequence of existence", partOfSpeech: "Noun" },
      { word: "Love", pronunciation: "Luv", translation: "Strong affection", partOfSpeech: "Noun" },
      { word: "Nature", pronunciation: "Ney-cher", translation: "The physical world and life", partOfSpeech: "Noun" },
      { word: "Journey", pronunciation: "Jur-nee", translation: "An act of traveling", partOfSpeech: "Noun" },
      { word: "Family", pronunciation: "Fam-lee", translation: "Household relatives group", partOfSpeech: "Noun" },
      { word: "Work", pronunciation: "Wurk", translation: "Activity involving mental/physical effort", partOfSpeech: "Noun/Verb" }
    ],
    middleware: [
      { phrase: "How are you?", pronunciation: "How are you?", translation: "Inquiring of welfare", context: "Everyday conversation starter" },
      { phrase: "What is your name?", pronunciation: "Wot iz yoor neym?", translation: "Asking identity", context: "First introductions" },
      { phrase: "Nice to meet you", pronunciation: "Neys too meet yoo", translation: "Polite welcoming expression", context: "After introducing names" },
      { phrase: "Where is the station?", pronunciation: "Wair iz thuh stey-shuhn?", translation: "Asking directions", context: "Travel scenario" },
      { phrase: "Can you help me?", pronunciation: "Kan yoo help mee?", translation: "Requesting assistance", context: "General emergency or inquiry" },
      { phrase: "Where are you from?", pronunciation: "Wair are yoo fruhm?", translation: "Asking about birthplace or origin", context: "Social icebreaker" },
      { phrase: "How much is this?", pronunciation: "How much iz this?", translation: "Inquiring about price", context: "Shopping / Retail purchase" },
      { phrase: "I don't understand", pronunciation: "Ay dohntuhn-der-stand", translation: "Expressing lack of comprehension", context: "Language clarification" },
      { phrase: "Have a great day", pronunciation: "Hav ay greyt dey", translation: "Polite well-wishing farewell", context: "Closing a conversation" },
      { phrase: "Could you repeat that?", pronunciation: "Kood yoo ree-peet that?", translation: "Asking someone to speak again", context: "Polite clarification" }
    ],
    pro: [
      {
        ruleName: "Subject-Verb-Object (SVO) Active Order",
        explanation: "English relies on standard SVO syntactic arrangements. Changing word positions transforms structural meaning.",
        structure: "Subject + Verb + Direct Object",
        examples: [
          { native: "The scholar reads the manuscript.", pronunciation: "The sko-lar reeds the man-yoo-skript", translation: "The person is actively analyzing the document." },
          { native: "The wind shook the branches.", pronunciation: "The wind shook the bran-chez", translation: "Nature moved the trees." }
        ]
      },
      {
        ruleName: "Present Perfect Continuous Nuance",
        explanation: "Highlights actions that began in the past, continue in the present, and are likely to persist into the future.",
        structure: "Subject + have/has + been + Verb-ing",
        examples: [
          { native: "I have been studying for three hours.", pronunciation: "I hav bin stuh-dee-ing for three ow-ers", translation: "The study started 3 hours ago and is still active." }
        ]
      },
      {
        ruleName: "Conditionals & Subjunctive Mood",
        explanation: "The conditional structures express hypothetical outcomes. The past subjunctive ('were') is used for counter-factual situations.",
        structure: "If + Subject + Past Subjunctive / Past Perfect, Subject + would + Verb",
        examples: [
          { native: "If I were you, I would accept the offer.", pronunciation: "If Ay wur yoo, Ay wood ak-sept the aw-fer", translation: "Advising someone by imagining being in their shoes." },
          { native: "If they had arrived earlier, we would have started.", pronunciation: "If they had uh-ryvd ur-lee-er, we wood hav star-ted", translation: "Speculating on past events." }
        ]
      }
    ]
  },
  {
    id: "spanish",
    name: "Spanish",
    flag: "🇪🇸",
    beginner: [
      { word: "Hola", pronunciation: "Oh-lah", translation: "Hello", partOfSpeech: "Interjection" },
      { word: "Gracias", pronunciation: "Grah-see-ahs", translation: "Thank you", partOfSpeech: "Interjection" },
      { word: "Casa", pronunciation: "Kah-sah", translation: "House / Home", partOfSpeech: "Noun" },
      { word: "Comida", pronunciation: "Koh-mee-dah", translation: "Food / Meal", partOfSpeech: "Noun" },
      { word: "Agua", pronunciation: "Ah-gwah", translation: "Water", partOfSpeech: "Noun" },
      { word: "Amigo", pronunciation: "Ah-mee-goh", translation: "Friend", partOfSpeech: "Noun" },
      { word: "Libro", pronunciation: "Lee-broh", translation: "Book", partOfSpeech: "Noun" },
      { word: "Sol", pronunciation: "Sohl", translation: "Sun", partOfSpeech: "Noun" },
      { word: "Ciudad", pronunciation: "Syoo-dahdh", translation: "City", partOfSpeech: "Noun" },
      { word: "Árbol", pronunciation: "Ahr-bohl", translation: "Tree", partOfSpeech: "Noun" },
      { word: "Flor", pronunciation: "Flohr", translation: "Flower", partOfSpeech: "Noun" },
      { word: "Luna", pronunciation: "Loo-nah", translation: "Moon", partOfSpeech: "Noun" },
      { word: "Amor", pronunciation: "Ah-mohr", translation: "Love", partOfSpeech: "Noun" },
      { word: "Vida", pronunciation: "Vee-dah", translation: "Life", partOfSpeech: "Noun" },
      { word: "Trabajo", pronunciation: "Trah-bah-hoh", translation: "Work / Job", partOfSpeech: "Noun" }
    ],
    middleware: [
      { phrase: "¿Cómo estás?", pronunciation: "Koh-moh ess-tahs", translation: "How are you?", context: "Standard greeting" },
      { phrase: "Me llamo...", pronunciation: "May yah-moh", translation: "My name is...", context: "Introducing oneself" },
      { phrase: "Tengo hambre", pronunciation: "Ten-goh ahm-bray", translation: "I am hungry (Literally: I have hunger)", context: "Expressing physical state" },
      { phrase: "Mucho gusto", pronunciation: "Moo-choh goos-toh", translation: "Nice to meet you", context: "Polite response" },
      { phrase: "¿Cuánto cuesta esto?", pronunciation: "Kwan-toh kwess-tah ess-toh", translation: "How much does this cost?", context: "Shopping / Travel inquiry" },
      { phrase: "¿De dónde eres?", pronunciation: "Deh dohn-deh eh-ress?", translation: "Where are you from?", context: "Social icebreaker" },
      { phrase: "No entiendo", pronunciation: "Noh en-tyen-doh", translation: "I do not understand", context: "Language block" },
      { phrase: "¿Me puedes ayudar?", pronunciation: "Meh pweh-dehs ah-yoo-dhar?", translation: "Can you help me?", context: "Requesting help" },
      { phrase: "Que tengas un buen día", pronunciation: "Keh ten-gahs oon bwen dee-ah", translation: "Have a nice day", context: "Polite sign-off" },
      { phrase: "¿Cómo se dice...?", pronunciation: "Koh-moh seh dee-seh", translation: "How do you say...?", context: "Linguistic assistance" }
    ],
    pro: [
      {
        ruleName: "The Subjunctive Mood for Desires",
        explanation: "Used to express subjective views, doubts, wishes, or emotions. Verbs undergo structural vowel-swaps.",
        structure: "Main Clause (desire) + que + Subjunctive Clause",
        examples: [
          { native: "Espero que vengas.", pronunciation: "Ess-peh-roh keh ven-gahs", translation: "I hope you come. ('Vengas' is subjunctive form of 'venir')" },
          { native: "No creo que sea verdad.", pronunciation: "Noh kray-oh keh seh-ah bair-dahd", translation: "I don't think it is true. ('Sea' is subjunctive form of 'ser')" }
        ]
      },
      {
        ruleName: "Dative Pronoun Placement with Reflexives",
        explanation: "Indirect object pronouns combine with reflexive markers, altering the sentence layout.",
        structure: "Reflexive Pronoun + Indirect Object + Verb",
        examples: [
          { native: "Me lo quedo.", pronunciation: "May loh kyeh-doh", translation: "I will keep it for myself. (Reflexive 'me' + Direct 'lo' + Keep 'quedo')" }
        ]
      },
      {
        ruleName: "Preterite vs. Imperfect Contrast",
        explanation: "Distinguishing completed past actions (Preterite) from ongoing, descriptive, or habitual past events (Imperfect).",
        structure: "Completed Action (Preterite Ending) vs. Background Habit (Imperfect Ending)",
        examples: [
          { native: "Yo estudiaba cuando él llamó.", pronunciation: "Yoh ess-too-dhyeh-bah kwan-doh el yah-moh", translation: "I was studying when he called. ('Estudiaba' is Imperfect background; 'llamó' is Preterite interruption)" }
        ]
      }
    ]
  },
  {
    id: "french",
    name: "French",
    flag: "🇫🇷",
    beginner: [
      { word: "Bonjour", pronunciation: "Bon-zhoor", translation: "Hello / Good day", partOfSpeech: "Interjection" },
      { word: "Merci", pronunciation: "Mair-see", translation: "Thank you", partOfSpeech: "Interjection" },
      { word: "Maison", pronunciation: "May-zon", translation: "House", partOfSpeech: "Noun" },
      { word: "Pain", pronunciation: "Pan", translation: "Bread", partOfSpeech: "Noun" },
      { word: "Eau", pronunciation: "Oh", translation: "Water", partOfSpeech: "Noun" },
      { word: "Ami", pronunciation: "Ah-mee", translation: "Friend", partOfSpeech: "Noun" },
      { word: "Livre", pronunciation: "Lee-vruh", translation: "Book", partOfSpeech: "Noun" },
      { word: "Temps", pronunciation: "Ton", translation: "Time / Weather", partOfSpeech: "Noun" },
      { word: "Ville", pronunciation: "Veel", translation: "City / Town", partOfSpeech: "Noun" },
      { word: "Arbre", pronunciation: "Ahr-bruh", translation: "Tree", partOfSpeech: "Noun" },
      { word: "Fleur", pronunciation: "Flur", translation: "Flower", partOfSpeech: "Noun" },
      { word: "Lune", pronunciation: "Loon", translation: "Moon", partOfSpeech: "Noun" },
      { word: "Amour", pronunciation: "Ah-moor", translation: "Love", partOfSpeech: "Noun" },
      { word: "Vie", pronunciation: "Vee", translation: "Life", partOfSpeech: "Noun" },
      { word: "Travail", pronunciation: "Trah-vye", translation: "Work / Job", partOfSpeech: "Noun" }
    ],
    middleware: [
      { phrase: "Comment ça va?", pronunciation: "Koh-mon sah vah", translation: "How is it going?", context: "Informal friendly check-in" },
      { phrase: "Je m'appelle...", pronunciation: "Zhuh mah-pel", translation: "My name is...", context: "Introducing oneself" },
      { phrase: "S'il vous plaît", pronunciation: "Seel voo play", translation: "Please (Formal)", context: "Requesting politely" },
      { phrase: "Enchanté", pronunciation: "On-shon-tay", translation: "Delighted to meet you", context: "Polite follow up" },
      { phrase: "Où se trouve la gare?", pronunciation: "Oo suh troov lah gar?", translation: "Where is the station?", context: "Asking directions" },
      { phrase: "D'où venez-vous?", pronunciation: "Doo vuh-nay voo?", translation: "Where are you from?", context: "Conversational question" },
      { phrase: "Combien ça coûte?", pronunciation: "Kom-byan sah koot?", translation: "How much does it cost?", context: "Asking about prices" },
      { phrase: "Je ne comprends pas", pronunciation: "Zhuh nuh kom-pron pah", translation: "I don't understand", context: "Language clarification" },
      { phrase: "Passez une bonne journée", pronunciation: "Pah-say zewn bun zhoor-nay", translation: "Have a nice day", context: "Friendly farewell" },
      { phrase: "Comment dit-on...?", pronunciation: "Kom-on dee-ton", translation: "How do we say...?", context: "Asking for translation" }
    ],
    pro: [
      {
        ruleName: "The Partitive Article Agreement",
        explanation: "Used to describe indefinite or uncountable quantities. Alters dynamically with gender and word-starting vowels.",
        structure: "de + definite article (du, de la, de l')",
        examples: [
          { native: "Je bois de l'eau.", pronunciation: "Zhuh bwah duh loh", translation: "I am drinking water. (Unspecified amount)" },
          { native: "Il achète du pain.", pronunciation: "Eel ah-shet dew pan", translation: "He is buying bread." }
        ]
      },
      {
        ruleName: "Past Participle with Être (Auxiliary)",
        explanation: "Verbs of motion and reflexive verbs use 'être' instead of 'avoir' as auxiliary. The past participle must agree with the subject's gender and count.",
        structure: "Subject + Être + Past Participle (Suffix matching)",
        examples: [
          { native: "Elle est allée à Paris.", pronunciation: "El lay tah-lay ah Pah-ree", translation: "She went to Paris. (Added 'e' to past participle 'allé' for feminine subject)" }
        ]
      },
      {
        ruleName: "The Double Pronoun Placement Matrix",
        explanation: "When direct and indirect object pronouns appear together, they follow a strict hierarchy of placement before the conjugated verb.",
        structure: "Subject + [me/te/se/nous/vous] + [le/la/les] + [lui/leur] + [y] + [en] + Verb",
        examples: [
          { native: "Il me l'a donné.", pronunciation: "Eel muh lah doh-nay", translation: "He gave it to me. ('me' indirect before 'le' direct object)" },
          { native: "Je lui en ai parlé.", pronunciation: "Zhuh lwee on ay par-lay", translation: "I spoke to him about it. ('lui' indirect before adverbial pronoun 'en')" }
        ]
      }
    ]
  },
  {
    id: "german",
    name: "German",
    flag: "🇩🇪",
    beginner: [
      { word: "Hallo", pronunciation: "Hah-loh", translation: "Hello", partOfSpeech: "Interjection" },
      { word: "Danke", pronunciation: "Dahn-kuh", translation: "Thank you", partOfSpeech: "Interjection" },
      { word: "Haus", pronunciation: "Howss", translation: "House", partOfSpeech: "Noun" },
      { word: "Brot", pronunciation: "Broht", translation: "Bread", partOfSpeech: "Noun" },
      { word: "Wasser", pronunciation: "Vah-ser", translation: "Water", partOfSpeech: "Noun" },
      { word: "Freund", pronunciation: "Froynd", translation: "Friend", partOfSpeech: "Noun" },
      { word: "Buch", pronunciation: "Book", translation: "Book", partOfSpeech: "Noun" },
      { word: "Zeit", pronunciation: "Tsayt", translation: "Time", partOfSpeech: "Noun" },
      { word: "Stadt", pronunciation: "Shtadt", translation: "City", partOfSpeech: "Noun" },
      { word: "Baum", pronunciation: "Bowm", translation: "Tree", partOfSpeech: "Noun" },
      { word: "Blume", pronunciation: "Bloo-muh", translation: "Flower", partOfSpeech: "Noun" },
      { word: "Mond", pronunciation: "Mohnd", translation: "Moon", partOfSpeech: "Noun" },
      { word: "Liebe", pronunciation: "Lee-buh", translation: "Love", partOfSpeech: "Noun" },
      { word: "Leben", pronunciation: "Lay-ben", translation: "Life", partOfSpeech: "Noun" },
      { word: "Arbeit", pronunciation: "Ahr-byte", translation: "Work", partOfSpeech: "Noun" }
    ],
    middleware: [
      { phrase: "Wie geht es dir?", pronunciation: "Vee gayt es deer", translation: "How are you? (Informal)", context: "Friendly greeting" },
      { phrase: "Ich heiße...", pronunciation: "Ich hye-suh", translation: "My name is...", context: "Introducing oneself" },
      { phrase: "Entschuldigung", pronunciation: "Ent-shool-dee-goong", translation: "Excuse me / Sorry", context: "Attracting attention or apologizing" },
      { phrase: "Was kostet das?", pronunciation: "Vas kos-tet das", translation: "How much does that cost?", context: "Shopping inquiry" },
      { phrase: "Es tut mir leid", pronunciation: "Es toot meer lyt", translation: "I am sorry", context: "Sincere regret" },
      { phrase: "Woher kommen Sie?", pronunciation: "Voh-hair kom-en zee?", translation: "Where are you from? (Formal)", context: "Polite inquiry" },
      { phrase: "Ich verstehe nicht", pronunciation: "Ich fehr-shtay-uh nicht", translation: "I do not understand", context: "Language barrier" },
      { phrase: "Können Sie mir helfen?", pronunciation: "Kun-en zee meer hel-fen?", translation: "Can you help me? (Formal)", context: "Asking for help" },
      { phrase: "Schönen Tag noch!", pronunciation: "Shu-nen tahg nokh!", translation: "Have a nice day!", context: "Farewell wish" },
      { phrase: "Wie sagt man...?", pronunciation: "Vee zahgt man", translation: "How does one say...?", context: "Asking for a word" }
    ],
    pro: [
      {
        ruleName: "Subordinating Clausal Verb Kicker",
        explanation: "In subordinate clauses (triggered by words like weil, dass, wenn), the conjugated verb is kicked to the absolute end of the clause.",
        structure: "Main Clause + Conjunction + Subject + ... + Verb (End)",
        examples: [
          { native: "Ich lerne Deutsch, weil ich in Berlin wohnen will.", pronunciation: "Ich lair-nuh Doytsh, vyle ich in Bair-leen voh-nen vil", translation: "I learn German because I want to live in Berlin. (The auxiliary verb 'will' goes to the end)" }
        ]
      },
      {
        ruleName: "Dative/Accusative Cases for Prepositions",
        explanation: "Two-way prepositions take the dative for state of rest (location) and the accusative for movement (direction).",
        structure: "Preposition + Dative (Rest) OR Accusative (Movement)",
        examples: [
          { native: "Ich sitze auf dem Stuhl.", pronunciation: "Ich zit-suh owf deym Shtool", translation: "I am sitting on the chair. (Dative 'dem' - stationary state)" },
          { native: "Ich setze mich auf den Stuhl.", pronunciation: "Ich zet-suh mich owf deyn Shtool", translation: "I sit down onto the chair. (Accusative 'den' - action of movement)" }
        ]
      },
      {
        ruleName: "Adjective Endings Declension",
        explanation: "Adjective endings change depending on the noun's gender, case, and the preceding article (weak, strong, or mixed declension).",
        structure: "Article + Adjective (Inflected) + Noun",
        examples: [
          { native: "Der gute Mann hilft mir.", pronunciation: "Dair goo-tuh mahn helft meer", translation: "The good man helps me. (Weak declension nominative masculine ending '-e')" },
          { native: "Ein guter Mann hilft mir.", pronunciation: "Ayn goo-tehr mahn helft meer", translation: "A good man helps me. (Mixed declension nominative masculine ending '-er')" }
        ]
      }
    ]
  },
  {
    id: "mandarin",
    name: "Mandarin Chinese",
    flag: "🇨🇳",
    beginner: [
      { word: "Nǐ hǎo", pronunciation: "Nee how", translation: "Hello", partOfSpeech: "Interjection" },
      { word: "Xièxie", pronunciation: "Sheh-sheh", translation: "Thank you", partOfSpeech: "Interjection" },
      { word: "Jiā", pronunciation: "Jyah", translation: "Home / Family", partOfSpeech: "Noun" },
      { word: "Mǐfàn", pronunciation: "Mee-fahn", translation: "Rice / Food", partOfSpeech: "Noun" },
      { word: "Shuǐ", pronunciation: "Shway", translation: "Water", partOfSpeech: "Noun" },
      { word: "Péngyǒu", pronunciation: "Pung-yo", translation: "Friend", partOfSpeech: "Noun" },
      { word: "Shū", pronunciation: "Shoo", translation: "Book", partOfSpeech: "Noun" },
      { word: "Māo", pronunciation: "Mow", translation: "Cat", partOfSpeech: "Noun" },
      { word: "Chéngshì", pronunciation: "Chung-shuh", translation: "City", partOfSpeech: "Noun" },
      { word: "Shù", pronunciation: "Shoo", translation: "Tree", partOfSpeech: "Noun" },
      { word: "Huā", pronunciation: "Hwah", translation: "Flower", partOfSpeech: "Noun" },
      { word: "Yuèliang", pronunciation: "Yweh-lyang", translation: "Moon", partOfSpeech: "Noun" },
      { word: "Ài", pronunciation: "Eye", translation: "Love", partOfSpeech: "Noun" },
      { word: "Shēnghuó", pronunciation: "Shung-hwaw", translation: "Life", partOfSpeech: "Noun" },
      { word: "Gōngzuò", pronunciation: "Goong-dzwaw", translation: "Work / Job", partOfSpeech: "Noun" }
    ],
    middleware: [
      { phrase: "Nǐ hǎo ma?", pronunciation: "Nee how mah?", translation: "How are you?", context: "Basic welfare inquiry" },
      { phrase: "Wǒ jiào...", pronunciation: "Waw jyaw...", translation: "My name is / I am called...", context: "Introducing oneself" },
      { phrase: "Duōshǎo qián?", pronunciation: "Dwaw-shao chyan?", translation: "How much money?", context: "Asking prices" },
      { phrase: "Wǒ bù dǒng", pronunciation: "Waw boo dong", translation: "I do not understand", context: "Polite escape phrase" },
      { phrase: "Méi guānxi", pronunciation: "May gwan-shee", translation: "It does not matter / No problem", context: "Accepting apologies" },
      { phrase: "Nǐ shì nǎ guó rén?", pronunciation: "Nee shee nah gwaw run?", translation: "Which country are you from?", context: "Icebreaker question" },
      { phrase: "Nǐ kěyǐ bāng wǒ ma?", pronunciation: "Nee kuh-yee bahng waw mah?", translation: "Can you help me?", context: "Requesting help" },
      { phrase: "Chóngfù yīxià?", pronunciation: "Chong-foo ee-shyah?", translation: "Can you repeat that?", context: "Clarification" },
      { phrase: "Zàijiàn", pronunciation: "Dzigh-jyan", translation: "Goodbye", context: "Parting" },
      { phrase: "Zhège yòng Zhōngwén zěnme shuō?", pronunciation: "Jay-guh yoong Joong-wen dzen-muh shwaw?", translation: "How do you say this in Chinese?", context: "Learning helper" }
    ],
    pro: [
      {
        ruleName: "Measure Word (Classifier) Integration",
        explanation: "Nouns cannot be numbered directly in Chinese; a measure word appropriate to the shape/category of the object must sit between the number and the noun.",
        structure: "Number + Measure Word + Noun",
        examples: [
          { native: "Yì běn shū.", pronunciation: "Ee bun shoo", translation: "One book. ('běn' is specifically for bound volumes like books)" },
          { native: "Liǎng ge rén.", pronunciation: "Lyahng guh run", translation: "Two people. ('ge' is the general universal classifier)" }
        ]
      },
      {
        ruleName: "The Aspect Marker Le (了)",
        explanation: "Chinese has no verb tenses. Instead, the particle 'le' is appended to signal completed action (aspect change) or situational updates.",
        structure: "Verb + le OR Sentence + le",
        examples: [
          { native: "Wǒ chīle mǐfàn.", pronunciation: "Waw chee-luh mee-fahn", translation: "I ate rice. (Completed action)" },
          { native: "Xià yǔ le.", pronunciation: "Shyah yu luh", translation: "It is raining now. (Situation change)" }
        ]
      },
      {
        ruleName: "The Ba (把) Direct Object Displacer",
        explanation: "The 'bǎ' structure shifts the direct object before the verb, stressing how the object is impacted, disposed of, or manipulated.",
        structure: "Subject + 把 + Object + Verb + Complement / Result",
        examples: [
          { native: "Wǒ bǎ pao hēle.", pronunciation: "Waw bah shway hay-luh", translation: "I drank up the water. (Literally: 'I taking water drank-completed')" },
          { native: "Qǐng bǎ shū fàng zài zhuōzi shàng.", pronunciation: "Ching bah shoo fahng dzigh jwaw-dzuh shahng", translation: "Please put the book on the table." }
        ]
      }
    ]
  },
  {
    id: "japanese",
    name: "Japanese",
    flag: "🇯🇵",
    beginner: [
      { word: "Konnichiwa", pronunciation: "Kon-nee-chee-wah", translation: "Hello", partOfSpeech: "Interjection" },
      { word: "Arigatou", pronunciation: "Ah-ree-gah-toh", translation: "Thank you", partOfSpeech: "Interjection" },
      { word: "Ie", pronunciation: "Ee-yeh", translation: "House / Home", partOfSpeech: "Noun" },
      { word: "Gohan", pronunciation: "Go-hahn", translation: "Rice / Meal", partOfSpeech: "Noun" },
      { word: "Mizu", pronunciation: "Mee-zoo", translation: "Water", partOfSpeech: "Noun" },
      { word: "Tomodachi", pronunciation: "Toh-moh-dah-chee", translation: "Friend", partOfSpeech: "Noun" },
      { word: "Hon", pronunciation: "Hon", translation: "Book", partOfSpeech: "Noun" },
      { word: "Neko", pronunciation: "Neh-koh", translation: "Cat", partOfSpeech: "Noun" },
      { word: "Machi", pronunciation: "Mah-chee", translation: "City / Town", partOfSpeech: "Noun" },
      { word: "Ki", pronunciation: "Kee", translation: "Tree", partOfSpeech: "Noun" },
      { word: "Hana", pronunciation: "Hah-nah", translation: "Flower", partOfSpeech: "Noun" },
      { word: "Tsuki", pronunciation: "Tsoo-kee", translation: "Moon", partOfSpeech: "Noun" },
      { word: "Ai", pronunciation: "Eye", translation: "Love", partOfSpeech: "Noun" },
      { word: "Inochi", pronunciation: "Ee-noh-chee", translation: "Life", partOfSpeech: "Noun" },
      { word: "Shigoto", pronunciation: "Shee-goh-toh", translation: "Work / Job", partOfSpeech: "Noun" }
    ],
    middleware: [
      { phrase: "O-genki desu ka?", pronunciation: "Oh-ghen-kee dess kah", translation: "Are you healthy / How are you?", context: "Polite check-in" },
      { phrase: "Watashi no namae wa... desu", pronunciation: "Wah-tah-shee noh nah-mah-eh wah... dess", translation: "My name is...", context: "Self-introduction" },
      { phrase: "Kore wa ikura desu ka?", pronunciation: "Koh-reh wah ee-koo-rah dess kah", translation: "How much is this?", context: "Shopping inquiry" },
      { phrase: "Sumimasen", pronunciation: "Soo-mee-mah-sen", translation: "Excuse me / I'm sorry", context: "Ubiquitous polite expression" },
      { phrase: "Yoroshiku onegashimasu", pronunciation: "Yoh-roh-shee-koo oh-neh-gah-shee-mah-soo", translation: "Please favor me / Nice to meet you", context: "Essential humble social contract" },
      { phrase: "Doko kara kimashita ka?", pronunciation: "Doh-koh kah-rah kee-mah-shee-tah kah?", translation: "Where did you come from?", context: "Conversation starter" },
      { phrase: "Wakarimasen", pronunciation: "Wah-kah-ree-mah-sen", translation: "I do not understand", context: "Language aid" },
      { phrase: "Tasukete kudasai", pronunciation: "Tah-soo-keh-teh koo-dah-sigh", translation: "Please help me", context: "Emergency / Assistance" },
      { phrase: "Yoi ichinichi wo", pronunciation: "Yoy ee-chee-nee-chee oh", translation: "Have a nice day", context: "Polite parting" },
      { phrase: "Nihongo de nan to iimasu ka?", pronunciation: "Nee-hon-goh deh nahn toh ee-mah-soo kah?", translation: "How do you say it in Japanese?", context: "Vocabulary builder" }
    ],
    pro: [
      {
        ruleName: "Particle System (Wa, Ga, Wo, Ni)",
        explanation: "Markers clarify noun relationships in standard Japanese. 'Wa' marks general topics, 'Ga' marks specific subjects, and 'Wo' marks direct targets.",
        structure: "Noun + Particle + Noun + Particle + Verb (End)",
        examples: [
          { native: "Watashi wa ringo wo tabemasu.", pronunciation: "Wah-tah-shee wah reen-goh oh tab-eh-mah-soo", translation: "As for me, I eat apples. (Topic: Watashi, Direct Object: Ringo, Verb: Tabemasu)" }
        ]
      },
      {
        ruleName: "Keigo (Honorific) Hierarchy Verb Shifting",
        explanation: "Verb endings warp entirely based on social rank. You elevate the listener using Sonkeigo and lower yourself with Kenjougo.",
        structure: "O + Root Verb + ni naru (Honorific elevation)",
        examples: [
          { native: "Sensei ga irashaimashita.", pronunciation: "Sen-say gah ee-rah-shai-mah-shee-tah", translation: "The teacher arrived. (Extremely polite honorific verb for 'arrived')" }
        ]
      },
      {
        ruleName: "Conditional Clauses with 'Tara' and 'Ba'",
        explanation: "The '-tara' conditional signals chronological dependency ('once/when'), while '-ba' focuses on logical hypothetical dependencies ('if').",
        structure: "Past Verb + -ra (tara) OR Verb Stem + -eba (ba)",
        examples: [
          { native: "Nihon ni ittara, Kyoto ni ikitai.", pronunciation: "Nee-hon nee eet-tah-rah, Kyoh-toh nee ee-kee-tigh", translation: "When/if I go to Japan, I want to visit Kyoto. ('ittara' indicates once I arrive)" },
          { native: "Yasukereba, kaimasu.", pronunciation: "Yah-soo-keh-reh-bah, kye-mah-soo", translation: "If it is cheap, I will buy it. ('yasukereba' is conditional cheapness)" }
        ]
      }
    ]
  },
  {
    id: "arabic",
    name: "Arabic",
    flag: "🇸🇦",
    beginner: [
      { word: "Marhaban", pronunciation: "Mar-hah-ban", translation: "Hello", partOfSpeech: "Interjection" },
      { word: "Shukran", pronunciation: "Shoo-kran", translation: "Thank you", partOfSpeech: "Interjection" },
      { word: "Bayt", pronunciation: "Bayt", translation: "House", partOfSpeech: "Noun" },
      { word: "Ta'am", pronunciation: "Tah-ahm", translation: "Food", partOfSpeech: "Noun" },
      { word: "Ma'", pronunciation: "Mah", translation: "Water", partOfSpeech: "Noun" },
      { word: "Sadiq", pronunciation: "Sah-deeq", translation: "Friend", partOfSpeech: "Noun" },
      { word: "Kitab", pronunciation: "Kee-taab", translation: "Book", partOfSpeech: "Noun" },
      { word: "Shams", pronunciation: "Shams", translation: "Sun", partOfSpeech: "Noun" },
      { word: "Madina", pronunciation: "Mah-dee-nah", translation: "City", partOfSpeech: "Noun" },
      { word: "Shajara", pronunciation: "Shah-jah-rah", translation: "Tree", partOfSpeech: "Noun" },
      { word: "Zahra", pronunciation: "Zah-rah", translation: "Flower", partOfSpeech: "Noun" },
      { word: "Qamar", pronunciation: "Qah-mar", translation: "Moon", partOfSpeech: "Noun" },
      { word: "Hubb", pronunciation: "Hoob", translation: "Love", partOfSpeech: "Noun" },
      { word: "Hayat", pronunciation: "Hah-yaat", translation: "Life", partOfSpeech: "Noun" },
      { word: "Amal", pronunciation: "Ah-mal", translation: "Work / Job", partOfSpeech: "Noun" }
    ],
    middleware: [
      { phrase: "Kayfa haluk?", pronunciation: "Kay-fah hah-look?", translation: "How are you?", context: "Standard inquiry" },
      { phrase: "Ismee...", pronunciation: "Is-mee...", translation: "My name is...", context: "Introducing oneself" },
      { phrase: "Min fadlik", pronunciation: "Min fad-lik", translation: "Please", context: "Polite request" },
      { phrase: "Tasharraftu", pronunciation: "Tah-shar-raf-too", translation: "Delighted to meet you", context: "Polite response" },
      { phrase: "Bika munaasib", pronunciation: "Bee-kah moo-nah-sib", translation: "It is fine / suitable", context: "Agreeing to pricing or terms" },
      { phrase: "Min ayna anta?", pronunciation: "Min ay-nah an-tah?", translation: "Where are you from?", context: "Social questioning" },
      { phrase: "La afham", pronunciation: "Lah af-ham", translation: "I do not understand", context: "Language barrier" },
      { phrase: "Hal tasta'tee'u musa'adatee?", pronunciation: "Hal tas-tah-tee-oo moo-sah-ah-dah-tee?", translation: "Can you help me?", context: "Requesting support" },
      { phrase: "Atamanna laka yawman sa'eedan", pronunciation: "Ah-tah-man-nah lah-kah yow-man sah-ee-dan", translation: "Have a nice day", context: "Friendly exit" },
      { phrase: "Kayfa taqoolu...?", pronunciation: "Kay-fah tah-qool-oo", translation: "How do you say...?", context: "Vocab help" }
    ],
    pro: [
      {
        ruleName: "Three-Letter Root (Radical) Morphology",
        explanation: "Virtually all nouns and verbs are derived from a core consonantal root (usually three letters) injected into structural vowel matrices.",
        structure: "Root Consonants (e.g. K-T-B for Writing) + Vowel Pattern",
        examples: [
          { native: "Kataba", pronunciation: "Kah-tah-bah", translation: "He wrote. (Verb form)" },
          { native: "Maktaba", pronunciation: "Mak-tah-bah", translation: "Library / Office. (Place noun form using root K-T-B)" }
        ]
      },
      {
        ruleName: "The Idafa (Noun Construct State)",
        explanation: "Indicates possession or description by joining two nouns directly. The first noun loses its definite article, while the second noun becomes genitive.",
        structure: "Noun (Unmarked) + Noun (Definite & Genitive)",
        examples: [
          { native: "Kitabu al-ustadh.", pronunciation: "Kee-taab-ul-oos-taadh", translation: "The book of the teacher / The teacher's book." }
        ]
      },
      {
        ruleName: "Dual and Sound Plurals Nominal System",
        explanation: "Arabic categorizes quantities into Singular, Dual (exactly two), and Plural. Dual is declared with the suffix '-an' or '-ayn'.",
        structure: "Noun Singular + '-an' (Nominative Dual) OR + '-ayn' (Accusative/Genitive Dual)",
        examples: [
          { native: "Kitaban jameelan.", pronunciation: "Kee-tah-baan jah-mee-laan", translation: "Two beautiful books. ('Kitab' + '-an')" },
          { native: "Mu'allimoona mukhlisoona.", pronunciation: "Moo-al-lee-moo-nah mookh-lee-soo-nah", translation: "Sincere teachers (Plural masculine ending '-oona')" }
        ]
      }
    ]
  },
  {
    id: "russian",
    name: "Russian",
    flag: "🇷🇺",
    beginner: [
      { word: "Privet", pronunciation: "Pree-vyet", translation: "Hi / Hello", partOfSpeech: "Interjection" },
      { word: "Spasibo", pronunciation: "Spah-see-bah", translation: "Thank you", partOfSpeech: "Interjection" },
      { word: "Dom", pronunciation: "Dohm", translation: "House / Home", partOfSpeech: "Noun" },
      { word: "Eda", pronunciation: "Yeh-dah", translation: "Food", partOfSpeech: "Noun" },
      { word: "Voda", pronunciation: "Vah-dah", translation: "Water", partOfSpeech: "Noun" },
      { word: "Drug", pronunciation: "Droog", translation: "Friend", partOfSpeech: "Noun" },
      { word: "Kniga", pronunciation: "Knee-gah", translation: "Book", partOfSpeech: "Noun" },
      { word: "Solntse", pronunciation: "Sohn-tseh", translation: "Sun", partOfSpeech: "Noun" },
      { word: "Gorod", pronunciation: "Goh-ruht", translation: "City / Town", partOfSpeech: "Noun" },
      { word: "Derevo", pronunciation: "Dyeh-ree-vuh", translation: "Tree", partOfSpeech: "Noun" },
      { word: "Cvetok", pronunciation: "Tsvee-tohk", translation: "Flower", partOfSpeech: "Noun" },
      { word: "Luna", pronunciation: "Loo-nah", translation: "Moon", partOfSpeech: "Noun" },
      { word: "Lyubov", pronunciation: "Lyoo-bohf", translation: "Love", partOfSpeech: "Noun" },
      { word: "Zhizn", pronunciation: "Zhyzn", translation: "Life", partOfSpeech: "Noun" },
      { word: "Rabota", pronunciation: "Rah-boh-tah", translation: "Work / Job", partOfSpeech: "Noun" }
    ],
    middleware: [
      { phrase: "Kak dela?", pronunciation: "Kahk-deh-lah?", translation: "How are things? / How are you?", context: "Common greeting" },
      { phrase: "Menya zovut...", pronunciation: "Meen-yah zah-voot", translation: "I am called... / My name is...", context: "Introducing oneself" },
      { phrase: "Pozhaluysta", pronunciation: "Pah-zhahl-oo-ystah", translation: "Please / You're welcome", context: "Multi-use polite word" },
      { phrase: "Rad vstreche", pronunciation: "Rahd fstrye-cheh", translation: "Glad to meet you", context: "Polite response" },
      { phrase: "Gde nakhoditsya metro?", pronunciation: "Gdeh nah-khaw-deet-syah mee-troh?", translation: "Where is the subway?", context: "Asking directions" },
      { phrase: "Otkuda vy?", pronunciation: "Aht-koo-dah vy?", translation: "Where are you from?", context: "Conversational question" },
      { phrase: "Skolko eto stoit?", pronunciation: "Skohl-kuh eh-tuh stoyt?", translation: "How much does this cost?", context: "Shopping context" },
      { phrase: "YA ne ponimayu", pronunciation: "Yah nee pah-nee-my-oo", translation: "I do not understand", context: "Language barrier" },
      { phrase: "Horoshego dnya!", pronunciation: "Hah-roh-shih-vuh dnyah", translation: "Have a good day!", context: "Friendly farewell" },
      { phrase: "Kak eto po-russki?", pronunciation: "Kahk eh-tuh pah roos-kee?", translation: "How is this in Russian?", context: "Vocabulary assistance" }
    ],
    pro: [
      {
        ruleName: "Six-Case Declension of Nouns",
        explanation: "Nouns alter word endings to signal grammar functions (Subject, Direct Object, Instrument, Place, etc.) across six cases.",
        structure: "Noun Root + Case Ending Suffix",
        examples: [
          { native: "Kniga na stole.", pronunciation: "Knee-gah nah stah-lyeh", translation: "The book is on the table. (Prepositional case ending '-e')" },
          { native: "Ya chitayu knigu.", pronunciation: "Yah chee-tah-yoo knee-goo", translation: "I am reading the book. (Accusative direct object ending '-u')" }
        ]
      },
      {
        ruleName: "Verbal Aspect (Perfective vs Imperfective)",
        explanation: "Actions are split into ongoing processes (Imperfective) or finalized, completed achievements (Perfective), swapping verb bases.",
        structure: "Verb Stem / Prefix Shift",
        examples: [
          { native: "Ya pisal pismo.", pronunciation: "Yah pee-sahl pees-moh", translation: "I was writing the letter. (Imperfective process)" },
          { native: "Ya napisal pismo.", pronunciation: "Yah nah-pee-sahl pees-moh", translation: "I wrote the letter. (Perfective, finalized accomplishment)" }
        ]
      },
      {
        ruleName: "Verbs of Motion and Prefixation",
        explanation: "Verbs of motion differentiate between uni-directional and multi-directional paths, and accept rich prefixes (like 'poyti' vs 'voshla') to show entry, exit, or initiation.",
        structure: "Prefix + Base Motion Verb",
        examples: [
          { native: "Ya idu v magazin.", pronunciation: "Yah ee-doo v mah-gah-zeen", translation: "I am actively walking to the store right now. (Uni-directional)" },
          { native: "Ona voshla v komnatu.", pronunciation: "Ah-nah vahsh-lah f kohm-nah-too", translation: "She entered the room. ('V-' prefix indicates entry)" }
        ]
      }
    ]
  }
];
