export interface LanguageBlueprint {
  id: string;
  name: string;
  difficulty: string;
  timeCommitment: string;
  bestDictionary: string;
  learningPath: string;
}

export const LANGUAGES_BLUEPRINTS: LanguageBlueprint[] = [
  {
    id: "kannada",
    name: "Kannada",
    difficulty: "Category III",
    timeCommitment: "1,100 hours",
    bestDictionary: "Shabdkosh Kannada",
    learningPath: "Begin with the complex Kannada script (Aksharamale) and basic household nouns. Pro-level mastery requires navigating formal versus informal verb endings and reading Classical Kannada literature."
  },
  {
    id: "hindi",
    name: "Hindi",
    difficulty: "Category III",
    timeCommitment: "1,100 hours",
    bestDictionary: "Glosbe Hindi",
    learningPath: "Master the Devanagari script and phonetic vowel markings. Transition from structural textbook Hindi to localized conversational variants (Hinglish) to achieve pro-level cultural fluency."
  },
  {
    id: "english",
    name: "English",
    difficulty: "Base reference language",
    timeCommitment: "Varied",
    bestDictionary: "Oxford English Dictionary",
    learningPath: "Start with basic phrasal structures and syntax patterns. Pro-level mastery requires commands over intricate idioms, variable regional accents, and specialized industry jargon."
  },
  {
    id: "spanish",
    name: "Spanish",
    difficulty: "Category I",
    timeCommitment: "600 hours",
    bestDictionary: "WordReference Spanish",
    learningPath: "Move rapidly through phonetic spelling rules and basic tense systems. Advanced paths focus on capturing distinct regional slangs across Latin America and Spain."
  },
  {
    id: "french",
    name: "French",
    difficulty: "Category I",
    timeCommitment: "600 hours",
    bestDictionary: "Larousse French",
    learningPath: "Balance early phonetics with silent letters. Reaching a pro level demands mastery of advanced conditional moods and high-speed listening comprehension."
  },
  {
    id: "german",
    name: "German",
    difficulty: "Category II",
    timeCommitment: "750 hours",
    bestDictionary: "Dict.cc German",
    learningPath: "Prioritize noun genders and case alterations early. Elite learners must conquer lengthy compound words and complex sentence structures that place verbs at the absolute end."
  },
  {
    id: "mandarin",
    name: "Mandarin Chinese",
    difficulty: "Category IV",
    timeCommitment: "2,200+ hours",
    bestDictionary: "Pleco Dictionary",
    learningPath: "Train extensively on the four spoken tones and radical-based character tracking. Pro status demands recognizing roughly 3,000 distinct Hanzi characters."
  },
  {
    id: "japanese",
    name: "Japanese",
    difficulty: "Category IV",
    timeCommitment: "2,200+ hours",
    bestDictionary: "Jisho Japanese",
    learningPath: "Transition swiftly from Hiragana and Katakana to multi-meaning Kanji. Pro-level requires flawlessly applying Keigo (honorific language) within corporate environments."
  },
  {
    id: "arabic",
    name: "Arabic",
    difficulty: "Category IV",
    timeCommitment: "2,200+ hours",
    bestDictionary: "Hans Wehr Arabic",
    learningPath: "Understand the root system logic alongside the script. Pro fluency involves bridging Modern Standard Arabic (MSA) with a spoken regional dialect like Levantine or Egyptian."
  },
  {
    id: "russian",
    name: "Russian",
    difficulty: "Category III",
    timeCommitment: "1,100 hours",
    bestDictionary: "Multitran Russian",
    learningPath: "Learn the Cyrillic alphabet followed by strict focus on noun cases. Pro level hinges on commanding verbs of motion and subtle prefix modifications."
  }
];
