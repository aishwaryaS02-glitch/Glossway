const fs = require('fs');
let code = fs.readFileSync('src/components/QuizView.tsx', 'utf8');

code = code.replace(
  'import { X, Award, HelpCircle, Gift, Sparkles, Trophy, Check, TrendingUp, Calendar } from "lucide-react";',
  'import { X, Award, HelpCircle, Gift, Sparkles, Trophy, Check, TrendingUp, Calendar, Bot, Loader2 } from "lucide-react";'
);

fs.writeFileSync('src/components/QuizView.tsx', code);
